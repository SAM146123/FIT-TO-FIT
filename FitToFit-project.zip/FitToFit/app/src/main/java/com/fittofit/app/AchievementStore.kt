package com.fittofit.app

import android.content.Context

/** Remembers which badges the user has earned, so they stay unlocked. */
object AchievementStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("badges", Context.MODE_PRIVATE)

    fun unlocked(ctx: Context): Set<String> = prefs(ctx).getStringSet("ids", emptySet()) ?: emptySet()

    /** Adds newly earned badges and returns everything unlocked so far. */
    fun update(ctx: Context, earnedNow: Set<String>): Set<String> {
        val old = unlocked(ctx)
        val all = old + earnedNow
        if (all.size != old.size) prefs(ctx).edit().putStringSet("ids", all).apply()
        return all
    }
}
