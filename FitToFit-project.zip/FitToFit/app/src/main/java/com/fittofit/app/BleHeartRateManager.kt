package com.fittofit.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class WatchDevice(val name: String, val address: String, val rssi: Int)

enum class WatchStatus { Idle, Scanning, Connecting, Connected, NoHeartRateService, Failed }

/**
 * Connects to any Bluetooth LE smartwatch / band that exposes the standard
 * GATT Heart Rate Service (0x180D). Once a watch is connected it is remembered ("paired"),
 * and the app reconnects to it automatically every time it starts or the watch comes back in range.
 */
@SuppressLint("MissingPermission") // permissions are requested in MainActivity before use
class BleHeartRateManager(context: Context) {

    companion object {
        val HR_SERVICE: UUID = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
        val HR_MEASUREMENT: UUID = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("watch", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var keepConnected = false

    private val _devices = MutableStateFlow<List<WatchDevice>>(emptyList())
    val devices: StateFlow<List<WatchDevice>> = _devices.asStateFlow()

    private val _heartRate = MutableStateFlow(0)
    val heartRate: StateFlow<Int> = _heartRate.asStateFlow()

    private val _history = MutableStateFlow<List<Int>>(emptyList())
    val history: StateFlow<List<Int>> = _history.asStateFlow()

    private val _status = MutableStateFlow(WatchStatus.Idle)
    val status: StateFlow<WatchStatus> = _status.asStateFlow()

    private val _connectedName = MutableStateFlow<String?>(null)
    val connectedName: StateFlow<String?> = _connectedName.asStateFlow()

    /** Name of the watch that is paired with this app (empty when none). */
    private val _pairedName = MutableStateFlow(prefs.getString("name", null))
    val pairedName: StateFlow<String?> = _pairedName.asStateFlow()

    val isBluetoothOn: Boolean get() = adapter?.isEnabled == true

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName ?: return
            val item = WatchDevice(name, result.device.address, result.rssi)
            _devices.update { list ->
                (list.filterNot { it.address == item.address } + item).sortedByDescending { it.rssi }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _status.value = WatchStatus.Failed
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: run { _status.value = WatchStatus.Failed; return }
        _devices.value = emptyList()
        _status.value = WatchStatus.Scanning
        scanner.startScan(scanCallback)
    }

    fun stopScan() {
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
        if (_status.value == WatchStatus.Scanning) _status.value = WatchStatus.Idle
    }

    /** Connects to a watch picked from the scan list and remembers it as the paired watch. */
    fun connect(device: WatchDevice) {
        stopScan()
        prefs.edit().putString("name", device.name).putString("address", device.address).apply()
        _pairedName.value = device.name
        open(device.name, device.address)
    }

    /** Reconnects to the paired watch (called when the app starts). */
    fun connectSaved() {
        val address = prefs.getString("address", null) ?: return
        val name = prefs.getString("name", null) ?: "Watch"
        val s = _status.value
        if (s == WatchStatus.Connected || s == WatchStatus.Connecting) return
        try {
            if (!isBluetoothOn) return
            open(name, address)
        } catch (e: Exception) {
            _status.value = WatchStatus.Failed
        }
    }

    private fun open(name: String, address: String) {
        _status.value = WatchStatus.Connecting
        keepConnected = true
        _connectedName.value = name
        gatt?.close()
        val remote: BluetoothDevice = adapter.getRemoteDevice(address)
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            remote.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            remote.connectGatt(appContext, false, gattCallback)
        }
    }

    /** The user chose to disconnect: forget the paired watch. */
    fun disconnect() {
        keepConnected = false
        handler.removeCallbacksAndMessages(null)
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        prefs.edit().remove("name").remove("address").apply()
        _pairedName.value = null
        _status.value = WatchStatus.Idle
        _connectedName.value = null
        _heartRate.value = 0
    }

    /** The app is closing: drop the connection but keep the watch paired. */
    fun release() {
        keepConnected = false
        handler.removeCallbacksAndMessages(null)
        gatt?.close()
        gatt = null
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                _heartRate.value = 0
                if (keepConnected) {
                    // watch went out of range or was switched off: keep trying quietly
                    _status.value = WatchStatus.Connecting
                    handler.postDelayed({ if (keepConnected) g.connect() }, 5000)
                } else {
                    _status.value = if (status == BluetoothGatt.GATT_SUCCESS) WatchStatus.Idle else WatchStatus.Failed
                    g.close()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val characteristic = g.getService(HR_SERVICE)?.getCharacteristic(HR_MEASUREMENT)
            if (characteristic == null) {
                _status.value = WatchStatus.NoHeartRateService
                return
            }
            g.setCharacteristicNotification(characteristic, true)
            val descriptor = characteristic.getDescriptor(CCCD) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                g.writeDescriptor(descriptor)
            }
            _status.value = WatchStatus.Connected
        }

        // Android 13+
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) = handle(characteristic.uuid, value)

        // Android 12 and below
        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            handle(characteristic.uuid, characteristic.value ?: return)
        }

        private fun handle(uuid: UUID, data: ByteArray) {
            if (uuid != HR_MEASUREMENT || data.isEmpty()) return
            val is16Bit = (data[0].toInt() and 0x01) != 0
            val bpm = if (is16Bit && data.size >= 3) {
                (data[1].toInt() and 0xFF) or ((data[2].toInt() and 0xFF) shl 8)
            } else if (data.size >= 2) {
                data[1].toInt() and 0xFF
            } else return
            _heartRate.value = bpm
            _history.update { (it + bpm).takeLast(40) }
        }
    }
}
