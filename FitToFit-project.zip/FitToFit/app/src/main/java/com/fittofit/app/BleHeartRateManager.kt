package com.fittofit.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class WatchDevice(val name: String, val address: String, val rssi: Int)

enum class WatchStatus { Idle, Scanning, Connecting, Connected, NoHeartRateService, Failed }

/**
 * Connects to any Bluetooth LE smartwatch / band that exposes the standard
 * GATT Heart Rate Service (0x180D). That is the standard every brand uses
 * for live heart rate (Polar, Garmin broadcast, Amazfit, Mi Band, Fitbit-compatible bands,
 * Wear OS watches with "heart-rate broadcast" etc.).
 */
@SuppressLint("MissingPermission") // permissions are requested in MainActivity before use
class BleHeartRateManager(context: Context) {

    companion object {
        val HR_SERVICE: UUID = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
        val HR_MEASUREMENT: UUID = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val appContext = context.applicationContext
    private var gatt: BluetoothGatt? = null

    private val _devices = MutableStateFlow<List<WatchDevice>>(emptyList())
    val devices: StateFlow<List<WatchDevice>> = _devices.asStateFlow()

    private val _heartRate = MutableStateFlow(0)
    val heartRate: StateFlow<Int> = _heartRate.asStateFlow()

    private val _history = MutableStateFlow<List<Int>>(emptyList())
    val history: StateFlow<List<Int>> = _history.asStateFlow()

    private val _status = MutableStateFlow(WatchStatus.Idle)
    val status: StateFlow<WatchStatus> = _status.asStateFlow()

    private val _connectedName = MutableStateFlow<String?>(null)
    val connectedName: StateFlow<String?> = _connectedName.asStateFlow()

    val isBluetoothOn: Boolean get() = adapter?.isEnabled == true

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName ?: return
            val item = WatchDevice(name, result.device.address, result.rssi)
            _devices.update { list ->
                (list.filterNot { it.address == item.address } + item).sortedByDescending { it.rssi }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _status.value = WatchStatus.Failed
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: run { _status.value = WatchStatus.Failed; return }
        _devices.value = emptyList()
        _status.value = WatchStatus.Scanning
        scanner.startScan(scanCallback)
    }

    fun stopScan() {
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
        if (_status.value == WatchStatus.Scanning) _status.value = WatchStatus.Idle
    }

    fun connect(device: WatchDevice) {
        stopScan()
        _status.value = WatchStatus.Connecting
        val remote: BluetoothDevice = adapter.getRemoteDevice(device.address)
        _connectedName.value = device.name
        gatt?.close()
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            remote.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            remote.connectGatt(appContext, false, gattCallback)
        }
    }

    fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        _status.value = WatchStatus.Idle
        _connectedName.value = null
        _heartRate.value = 0
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                _status.value = if (status == BluetoothGatt.GATT_SUCCESS) WatchStatus.Idle else WatchStatus.Failed
                _heartRate.value = 0
                g.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val characteristic = g.getService(HR_SERVICE)?.getCharacteristic(HR_MEASUREMENT)
            if (characteristic == null) {
                _status.value = WatchStatus.NoHeartRateService
                return
            }
            g.setCharacteristicNotification(characteristic, true)
            val descriptor = characteristic.getDescriptor(CCCD) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                g.writeDescriptor(descriptor)
            }
            _status.value = WatchStatus.Connected
        }

        // Android 13+
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) = handle(characteristic.uuid, value)

        // Android 12 and below
        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            handle(characteristic.uuid, characteristic.value ?: return)
        }

        private fun handle(uuid: UUID, data: ByteArray) {
            if (uuid != HR_MEASUREMENT || data.isEmpty()) return
            val is16Bit = (data[0].toInt() and 0x01) != 0
            val bpm = if (is16Bit && data.size >= 3) {
                (data[1].toInt() and 0xFF) or ((data[2].toInt() and 0xFF) shl 8)
            } else if (data.size >= 2) {
                data[1].toInt() and 0xFF
            } else return
            _heartRate.value = bpm
            _history.update { (it + bpm).takeLast(40) }
        }
    }
}
