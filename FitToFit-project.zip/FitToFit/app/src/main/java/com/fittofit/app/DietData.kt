package com.fittofit.app

/** One healthy home-style dish. Values are for one serving. No packaged foods, no added-sugar items. */
class Dish(
    val name: String,
    /** Wikipedia article title, used to fetch a photo */
    val wiki: String,
    /** true = vegetarian without eggs */
    val veg: Boolean,
    val kcal: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int,
    val fiber: Int,
    val serving: String
)

class Pool(
    val title: String,
    val breakfast: List<Dish>,
    val lunch: List<Dish>,
    val dinner: List<Dish>,
    val snack: List<Dish>,
    val pre: List<Dish>,
    val post: List<Dish>
)

private fun d(name: String, wiki: String, veg: Boolean, kcal: Int, p: Int, c: Int, f: Int, fiber: Int, serving: String) =
    Dish(name, wiki, veg, kcal, p, c, f, fiber, serving)

object DietData {

    // dishes used in several countries
    private val banana = d("Banana with a few almonds", "Banana", true, 170, 4, 30, 6, 4, "1 banana + 6 almonds")
    private val oats = d("Oatmeal with fruit and nuts (no sugar)", "Oatmeal", true, 300, 10, 48, 8, 6, "1 bowl")
    private val oatsLight = d("Light oatmeal with milk", "Oatmeal", true, 220, 9, 36, 5, 5, "1 small bowl")
    private val eggsFruit = d("Boiled eggs with fruit", "Boiled egg", false, 200, 13, 16, 9, 2, "2 eggs + 1 fruit")
    private val yogurtFruit = d("Plain yogurt with fruit and nuts", "Yogurt", true, 240, 14, 26, 8, 3, "1 cup yogurt + fruit")
    private val coconutWater = d("Coconut water with a banana", "Coconut water", true, 130, 2, 30, 0, 3, "1 glass + 1 banana")
    private val almonds = d("Handful of unsalted almonds", "Almond", true, 170, 6, 6, 15, 3, "25 g")
    private val fruit = d("Fresh seasonal fruit", "Fruit salad", true, 110, 2, 27, 1, 5, "1 big bowl")
    private val chickpeas = d("Roasted chickpeas (home made)", "Chickpea", true, 150, 8, 24, 3, 6, "1/3 cup")
    private val lentilSoup = d("Lentil and vegetable soup", "Lentil soup", true, 320, 17, 46, 6, 12, "1 large bowl")
    private val hummus = d("Hummus with vegetable sticks", "Hummus", true, 190, 7, 20, 9, 6, "1/3 cup + veg")

    private val india = Pool(
        "India",
        breakfast = listOf(
            d("Idli with sambar", "Idli", true, 300, 10, 55, 4, 6, "3 idli + 1 cup sambar"),
            d("Vegetable upma", "Upma", true, 280, 8, 45, 8, 5, "1.5 cups"),
            d("Ragi dosa with chutney", "Dosa", true, 260, 8, 44, 5, 6, "2 dosas"),
            d("Pesarattu (green gram dosa)", "Pesarattu", true, 250, 14, 36, 5, 7, "2 pesarattu"),
            d("Vegetable poha", "Poha", true, 270, 7, 46, 6, 4, "1.5 cups"),
            d("Egg bhurji with 1 roti", "Scrambled eggs", false, 320, 18, 28, 15, 3, "2-egg bhurji + 1 roti")
        ),
        lunch = listOf(
            d("Brown rice, sambar and vegetable poriyal", "Sambar (dish)", true, 480, 15, 80, 9, 9, "1 cup rice + 1 cup sambar + veg"),
            d("Chapati, dal and mixed vegetable sabzi", "Dal", true, 450, 18, 68, 10, 10, "2 chapati + 1 cup dal + sabzi"),
            d("Rajma with brown rice", "Rajma", true, 480, 19, 78, 8, 13, "1 cup rajma + 3/4 cup rice"),
            d("Grilled chicken with vegetables and roti", "Tandoori chicken", false, 480, 38, 40, 15, 6, "150 g chicken + 1 roti + veg"),
            d("Curd rice with vegetable salad", "Curd rice", true, 380, 12, 58, 10, 3, "1 bowl + salad"),
            d("Fish curry (low oil) with rice", "Fish curry", false, 500, 34, 58, 14, 3, "1 piece fish + 3/4 cup rice")
        ),
        dinner = listOf(
            d("Vegetable khichdi with curd", "Khichdi", true, 420, 15, 66, 9, 8, "1.5 cups + 1/2 cup curd"),
            d("Ragi roti with palak paneer", "Palak paneer", true, 440, 20, 42, 22, 7, "2 roti + 1 cup"),
            d("Chana masala with 2 chapati", "Chana masala", true, 450, 17, 70, 10, 13, "1 cup + 2 chapati"),
            d("Chicken and vegetable stew", "Chicken curry", false, 380, 34, 20, 17, 4, "1.5 cups"),
            d("Tomato rasam with millet and vegetables", "Rasam", true, 330, 10, 60, 5, 7, "1 cup rasam + 1 cup millet"),
            d("Vegetable soup with sprouts salad", "Sprouting", true, 250, 14, 38, 4, 9, "1 bowl + 1 cup salad")
        ),
        snack = listOf(
            chickpeas,
            d("Sprouts chaat", "Chaat", true, 180, 10, 28, 3, 8, "1 cup"),
            d("Fruit bowl (papaya, guava, apple)", "Fruit salad", true, 120, 2, 28, 1, 5, "1 bowl"),
            d("Buttermilk with a few almonds", "Buttermilk", true, 140, 6, 10, 9, 1, "1 glass + 6 almonds")
        ),
        pre = listOf(banana, oatsLight, d("2 dates and a handful of nuts", "Almond", true, 190, 4, 30, 7, 4, "2 dates + 8 nuts")),
        post = listOf(
            eggsFruit,
            d("Paneer cubes or sprouts salad", "Paneer", true, 260, 16, 14, 16, 3, "100 g paneer + salad"),
            d("Unsweetened lassi", "Lassi", true, 120, 7, 10, 5, 0, "1 glass"),
            coconutWater
        )
    )

    private val lanka = Pool(
        "Sri Lanka",
        breakfast = listOf(
            d("String hoppers with dhal and pol sambol", "String hoppers", true, 330, 10, 58, 6, 5, "8 string hoppers + dhal"),
            d("Kiribath (milk rice) with lunu miris", "Kiribath", true, 320, 6, 55, 8, 2, "2 pieces"),
            d("Pol roti with dhal", "Pol roti", true, 300, 9, 45, 10, 5, "2 roti + dhal"),
            d("Egg hopper (1) with vegetable sambol", "Appam", false, 260, 10, 36, 8, 2, "1 egg hopper + sambol")
        ),
        lunch = listOf(
            d("Rice and curry (dhal, vegetables, greens)", "Rice and curry", true, 520, 18, 85, 10, 10, "1 cup rice + 3 curries"),
            d("Red rice with fish ambul thiyal", "Ambul thiyal", false, 500, 34, 60, 12, 3, "3/4 cup rice + fish"),
            d("Vegetable kottu (less oil)", "Kottu", true, 520, 16, 75, 16, 6, "1 plate"),
            d("Chicken curry with red rice and gotukola sambol", "Chicken curry", false, 520, 36, 62, 14, 5, "1 cup rice + chicken")
        ),
        dinner = listOf(
            d("Parippu (dhal) curry with roti", "Dal", true, 420, 18, 60, 10, 9, "1 cup dhal + 2 roti"),
            d("Pittu with coconut sambol and vegetables", "Pittu", true, 380, 8, 64, 9, 5, "1 serving"),
            d("Grilled fish with mallum greens", "Fish as food", false, 340, 32, 12, 16, 5, "150 g fish + greens"),
            lentilSoup
        ),
        snack = listOf(
            d("Boiled kadala (chickpeas)", "Chickpea", true, 160, 9, 26, 3, 7, "1/2 cup"),
            d("Fresh papaya or banana", "Papaya", true, 110, 1, 27, 0, 4, "1 bowl"),
            d("King coconut water", "Coconut water", true, 60, 0, 14, 0, 0, "1 king coconut")
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, d("Kola kanda (herbal porridge)", "Kola kanda", true, 150, 3, 25, 3, 3, "1 bowl"), coconutWater)
    )

    private val sea = Pool(
        "South-East Asia",
        breakfast = listOf(
            oats,
            d("Wholemeal roti with dhal", "Dal", true, 330, 13, 52, 7, 7, "2 roti + 1/2 cup dhal"),
            d("Boiled eggs with wholemeal toast and cucumber", "Boiled egg", false, 320, 19, 28, 14, 4, "2 eggs + 2 toast"),
            d("Idli with sambar", "Idli", true, 300, 10, 55, 4, 6, "3 idli + sambar")
        ),
        lunch = listOf(
            d("Steamed chicken rice (skinless) with cucumber", "Hainanese chicken rice", false, 480, 32, 62, 10, 3, "3/4 cup rice + 120 g chicken"),
            d("Nasi lemak (less coconut) with egg and anchovies", "Nasi lemak", false, 520, 20, 70, 17, 5, "1 small plate"),
            d("Gado-gado with tempeh", "Gado-gado", true, 450, 20, 40, 22, 10, "1 plate"),
            d("Brown rice, grilled fish and stir-fried greens", "Ikan bakar", false, 470, 34, 55, 12, 6, "3/4 cup rice + fish + greens")
        ),
        dinner = listOf(
            d("Tempeh and vegetable stir-fry with rice", "Tempeh", true, 440, 22, 55, 14, 8, "1 plate"),
            d("Soto ayam (clear chicken soup)", "Soto (food)", false, 380, 30, 35, 12, 4, "1 large bowl"),
            d("Sayur lodeh with tofu", "Sayur lodeh", true, 340, 14, 30, 18, 7, "1 bowl"),
            d("Steamed fish with vegetables", "Steamed fish", false, 330, 34, 18, 12, 5, "150 g fish + veg")
        ),
        snack = listOf(
            d("Fresh papaya or guava", "Papaya", true, 110, 1, 27, 0, 4, "1 bowl"),
            d("Boiled peanuts or corn", "Boiled peanuts", true, 160, 7, 12, 10, 4, "1/2 cup"),
            d("Unsweetened soy milk", "Soy milk", true, 100, 7, 4, 4, 1, "1 glass")
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, d("Tofu or tempeh with rice", "Tofu", true, 280, 18, 30, 9, 4, "100 g + 1/2 cup rice"), coconutWater)
    )

    private val gulf = Pool(
        "Middle East",
        breakfast = listOf(
            d("Foul medames with whole-wheat bread", "Ful medames", true, 380, 20, 55, 8, 14, "1 cup + 1 bread"),
            d("Labneh, cucumber and wholemeal pita", "Labneh", true, 300, 14, 38, 10, 5, "3 tbsp + 1 pita"),
            d("Shakshuka with eggs", "Shakshouka", false, 320, 18, 20, 18, 5, "2 eggs in tomato sauce"),
            oats
        ),
        lunch = listOf(
            d("Grilled chicken with brown rice and tabbouleh", "Tabbouleh", false, 520, 40, 52, 16, 7, "150 g chicken + 3/4 cup rice"),
            lentilSoup,
            d("Grilled fish with vegetables and rice", "Grilled fish", false, 480, 36, 50, 14, 5, "150 g fish + 3/4 cup rice"),
            d("Chickpea and vegetable stew with whole-wheat bread", "Chickpea", true, 450, 18, 66, 12, 12, "1.5 cups + 1 bread")
        ),
        dinner = listOf(
            d("Chicken shish tawook with salad", "Shish taouk", false, 420, 40, 22, 18, 5, "150 g chicken + salad"),
            d("Vegetable tagine with chickpeas", "Tajine", true, 380, 14, 54, 12, 11, "1.5 cups"),
            d("Lean grilled kofta with fattoush", "Fattoush", false, 450, 32, 36, 20, 6, "2 kofta + salad"),
            d("Hummus with vegetable sticks and pita", "Hummus", true, 350, 13, 40, 16, 9, "1/2 cup + pita + veg")
        ),
        snack = listOf(
            fruit, chickpeas,
            d("Unsweetened laban (yogurt drink)", "Ayran", true, 90, 6, 7, 4, 0, "1 glass")
        ),
        pre = listOf(banana, d("2 dates with almonds", "Almond", true, 190, 4, 30, 7, 4, "2 dates + 8 almonds")),
        post = listOf(eggsFruit, d("Unsweetened laban with a fruit", "Ayran", true, 170, 7, 30, 4, 3, "1 glass + 1 fruit"))
    )

    private val usa = Pool(
        "North America and Oceania",
        breakfast = listOf(
            oats,
            d("Veggie omelette with whole-grain toast", "Omelette", false, 330, 20, 24, 16, 5, "2-egg omelette + 1 toast"),
            d("Greek yogurt parfait (plain) with fruit", "Yogurt", true, 260, 20, 28, 6, 4, "1 cup"),
            d("Avocado toast on whole grain with egg", "Avocado toast", false, 340, 14, 30, 19, 8, "1 toast + 1 egg")
        ),
        lunch = listOf(
            d("Grilled chicken salad with quinoa", "Quinoa", false, 450, 40, 38, 14, 8, "150 g chicken + 1/2 cup quinoa"),
            d("Turkey and veggie whole-wheat wrap", "Wrap (food)", false, 420, 30, 44, 12, 7, "1 wrap"),
            lentilSoup,
            d("Black bean and brown rice bowl", "Rice and beans", true, 480, 18, 80, 8, 15, "1 bowl")
        ),
        dinner = listOf(
            d("Baked salmon with roasted vegetables", "Salmon", false, 460, 36, 22, 24, 6, "150 g salmon + veg"),
            d("Stir-fried tofu and vegetables with brown rice", "Tofu", true, 430, 24, 52, 14, 8, "1 plate"),
            d("Chicken breast with sweet potato and broccoli", "Sweet potato", false, 440, 40, 42, 10, 8, "150 g chicken + 1 potato"),
            d("Vegetable minestrone with beans", "Minestrone", true, 340, 16, 52, 7, 12, "1 large bowl")
        ),
        snack = listOf(
            d("Apple with natural peanut butter", "Peanut butter", true, 190, 6, 22, 10, 5, "1 apple + 1 tbsp"),
            hummus, almonds
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(yogurtFruit, eggsFruit)
    )

    private val uk = Pool(
        "United Kingdom and Ireland",
        breakfast = listOf(
            d("Porridge with fruit and seeds", "Porridge", true, 300, 10, 50, 7, 6, "1 bowl"),
            d("Poached eggs on wholegrain toast", "Poached egg", false, 300, 17, 26, 14, 4, "2 eggs + 1 toast"),
            yogurtFruit,
            d("Wholegrain toast with baked beans (no added sugar)", "Baked beans", true, 320, 15, 52, 5, 12, "2 toast + 1/2 cup beans")
        ),
        lunch = listOf(
            lentilSoup,
            d("Grilled chicken salad with new potatoes", "Chicken salad", false, 430, 36, 36, 14, 6, "150 g chicken + potatoes"),
            d("Tuna and salad wholemeal sandwich", "Tuna fish sandwich", false, 400, 28, 42, 12, 6, "1 sandwich"),
            d("Jacket potato with beans and salad", "Baked potato", true, 400, 14, 76, 5, 12, "1 large potato")
        ),
        dinner = listOf(
            d("Baked cod with peas and potatoes", "Cod", false, 420, 38, 40, 10, 8, "150 g cod + sides"),
            d("Chicken and vegetable stew", "Stew", false, 400, 34, 32, 14, 7, "1.5 cups"),
            d("Vegetable curry with brown rice", "Curry", true, 430, 13, 70, 11, 10, "1 cup + 3/4 cup rice"),
            d("Shepherd's pie with lean mince or lentils", "Shepherd's pie", false, 450, 28, 48, 16, 8, "1 portion")
        ),
        snack = listOf(
            fruit,
            d("Oatcakes with cottage cheese", "Oatcake", true, 170, 10, 18, 6, 3, "2 oatcakes"),
            almonds
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(yogurtFruit, eggsFruit)
    )

    private val med = Pool(
        "Mediterranean",
        breakfast = listOf(
            d("Greek yogurt with walnuts and fruit", "Yogurt", true, 260, 15, 24, 11, 3, "1 cup"),
            d("Wholegrain toast with tomato and olive oil", "Pa amb tomàquet", true, 280, 8, 36, 12, 5, "2 toast"),
            d("Vegetable omelette (tortilla)", "Spanish omelette", false, 320, 16, 22, 18, 3, "1 portion"),
            oats
        ),
        lunch = listOf(
            d("Greek salad with chickpeas", "Greek salad", true, 380, 14, 32, 22, 9, "1 large bowl"),
            d("Grilled fish with lemon and vegetables", "Grilled fish", false, 400, 36, 22, 18, 6, "150 g fish + veg"),
            lentilSoup,
            d("Whole-wheat pasta with tomato and vegetables", "Pasta", true, 430, 15, 76, 8, 9, "1 plate")
        ),
        dinner = listOf(
            d("Grilled chicken with ratatouille", "Ratatouille", false, 400, 36, 24, 18, 7, "150 g chicken + 1 cup"),
            d("Minestrone soup with beans", "Minestrone", true, 340, 16, 52, 7, 12, "1 large bowl"),
            d("Baked fish with potatoes and greens", "Fish as food", false, 410, 35, 38, 12, 7, "150 g fish + potatoes"),
            d("Stuffed vegetables with rice (dolma)", "Dolma", true, 330, 8, 48, 12, 6, "4 pieces + salad")
        ),
        snack = listOf(fruit, hummus, d("A few olives and almonds", "Olive", true, 160, 4, 5, 14, 3, "6 olives + 10 almonds")),
        pre = listOf(banana, oatsLight),
        post = listOf(yogurtFruit, d("Boiled eggs with tomato salad", "Boiled egg", false, 210, 13, 10, 12, 3, "2 eggs + salad"))
    )

    private val eastAsia = Pool(
        "East Asia",
        breakfast = listOf(
            d("Miso soup with rice and grilled fish", "Miso soup", false, 380, 24, 48, 10, 4, "1 set"),
            d("Congee with egg and vegetables", "Congee", false, 280, 12, 46, 5, 2, "1 large bowl"),
            d("Tofu rice bowl with vegetables", "Tofu", true, 340, 18, 48, 8, 5, "1 bowl"),
            oats
        ),
        lunch = listOf(
            d("Chicken and vegetable stir-fry with brown rice", "Stir frying", false, 480, 36, 56, 12, 6, "1 plate"),
            d("Soba noodles with vegetables", "Soba", true, 420, 15, 78, 4, 6, "1 bowl"),
            d("Bibimbap (light oil)", "Bibimbap", false, 520, 22, 78, 12, 8, "1 bowl"),
            d("Steamed fish with bok choy and rice", "Steamed fish", false, 430, 34, 50, 9, 4, "150 g fish + 3/4 cup rice")
        ),
        dinner = listOf(
            d("Tofu and vegetable hot pot (nabe)", "Nabemono", true, 330, 20, 30, 12, 8, "1 pot"),
            d("Grilled salmon with greens", "Salmon", false, 430, 36, 20, 22, 5, "150 g + greens"),
            d("Mapo-style tofu with brown rice (light)", "Mapo doufu", true, 450, 20, 58, 14, 6, "1 plate"),
            d("Clear chicken and vegetable soup", "Chicken soup", false, 300, 28, 20, 10, 4, "1 large bowl")
        ),
        snack = listOf(
            d("Edamame", "Edamame", true, 150, 13, 12, 6, 5, "1 cup"),
            fruit,
            d("Unsweetened soy milk", "Soy milk", true, 100, 7, 4, 4, 1, "1 glass")
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, d("Tofu with rice", "Tofu", true, 280, 18, 30, 9, 4, "100 g + 1/2 cup rice"))
    )

    private val latam = Pool(
        "Latin America",
        breakfast = listOf(
            d("Scrambled eggs with beans and a corn tortilla", "Scrambled eggs", false, 380, 20, 36, 16, 8, "2 eggs + 1/2 cup beans"),
            oats,
            d("Fresh fruit with plain yogurt", "Yogurt", true, 230, 12, 32, 5, 4, "1 cup + fruit"),
            d("Black beans on corn tortilla with avocado", "Black beans", true, 360, 15, 52, 11, 14, "2 tortillas")
        ),
        lunch = listOf(
            d("Grilled chicken, rice and beans with salad", "Rice and beans", false, 520, 40, 64, 10, 12, "150 g chicken + 1 cup rice & beans"),
            d("Black beans with greens (lean feijoada style)", "Feijoada", false, 500, 30, 60, 14, 15, "1 plate"),
            d("Vegetable and bean burrito bowl", "Burrito", true, 480, 18, 74, 10, 14, "1 bowl"),
            d("Ceviche with corn and salad", "Ceviche", false, 330, 30, 36, 6, 5, "1 plate")
        ),
        dinner = listOf(
            d("Grilled fish with salsa and vegetables", "Grilled fish", false, 380, 34, 22, 16, 6, "150 g fish + veg"),
            d("Chicken with salad and lime", "Chicken as food", false, 400, 38, 24, 16, 6, "150 g chicken + salad"),
            d("Lentil and vegetable stew", "Lentil soup", true, 380, 20, 58, 6, 14, "1.5 cups"),
            d("Chicken pozole with cabbage", "Pozole", false, 400, 30, 48, 10, 6, "1 large bowl")
        ),
        snack = listOf(
            d("Fresh mango or papaya", "Mango", true, 110, 1, 28, 0, 3, "1 bowl"),
            d("Guacamole with vegetable sticks", "Guacamole", true, 150, 2, 10, 12, 6, "1/3 cup + veg"),
            d("Roasted peanuts (unsalted)", "Peanut", true, 170, 7, 5, 14, 3, "25 g")
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, yogurtFruit)
    )

    private val africa = Pool(
        "Africa",
        breakfast = listOf(
            d("Millet or oat porridge (no sugar)", "Porridge", true, 280, 9, 50, 5, 6, "1 bowl"),
            d("Boiled yam with egg and vegetable sauce", "Yam (vegetable)", false, 380, 14, 60, 9, 6, "1 portion"),
            d("Moi moi (steamed bean pudding)", "Moin moin", true, 300, 16, 34, 12, 7, "1 large piece"),
            yogurtFruit
        ),
        lunch = listOf(
            d("Jollof rice (less oil) with grilled chicken and salad", "Jollof rice", false, 520, 36, 66, 12, 5, "1 cup rice + 120 g chicken"),
            d("Brown beans with boiled plantain", "Plantain", true, 480, 18, 84, 7, 14, "1 cup beans + 1 plantain"),
            d("Vegetable soup (efo riro) with fish", "Efo riro", false, 470, 32, 50, 16, 8, "1 bowl + swallow"),
            d("Ugali with sukuma wiki and beans", "Ugali", true, 460, 16, 82, 6, 12, "1 portion")
        ),
        dinner = listOf(
            d("Grilled tilapia with vegetables and sweet potato", "Tilapia", false, 420, 38, 40, 10, 7, "150 g fish + 1 potato"),
            d("Groundnut soup with vegetables", "Groundnut soup", true, 430, 16, 28, 28, 6, "1 bowl"),
            d("Bean stew with greens", "Bean", true, 380, 18, 58, 6, 15, "1.5 cups"),
            d("Chicken pepper soup", "Pepper soup", false, 300, 30, 10, 14, 2, "1 large bowl")
        ),
        snack = listOf(
            d("Boiled groundnuts", "Boiled peanuts", true, 160, 7, 12, 10, 4, "1/2 cup"),
            d("Fresh fruit (orange, pawpaw)", "Papaya", true, 110, 1, 27, 0, 4, "1 bowl"),
            d("Roasted corn", "Maize", true, 140, 4, 28, 2, 4, "1 cob")
        ),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, yogurtFruit)
    )

    private val global = Pool(
        "Global",
        breakfast = listOf(
            oats, yogurtFruit,
            d("Vegetable omelette with whole-grain toast", "Omelette", false, 330, 20, 24, 16, 5, "2-egg omelette + toast"),
            d("Whole-grain toast with peanut butter and banana", "Peanut butter", true, 340, 12, 46, 12, 7, "2 toast + 1 banana")
        ),
        lunch = listOf(
            d("Grilled chicken salad with whole grains", "Chicken salad", false, 450, 38, 40, 14, 8, "1 large plate"),
            lentilSoup,
            d("Vegetable and bean rice bowl", "Rice and beans", true, 480, 18, 80, 8, 15, "1 bowl"),
            d("Grilled fish with vegetables and rice", "Grilled fish", false, 460, 34, 50, 12, 6, "150 g fish + 3/4 cup rice")
        ),
        dinner = listOf(
            d("Stir-fried vegetables and tofu with brown rice", "Tofu", true, 430, 24, 52, 14, 8, "1 plate"),
            d("Chicken and vegetable soup", "Chicken soup", false, 320, 28, 24, 10, 5, "1 large bowl"),
            d("Bean and vegetable stew", "Bean", true, 380, 18, 58, 6, 15, "1.5 cups"),
            d("Baked fish with roasted vegetables", "Fish as food", false, 400, 35, 24, 17, 6, "150 g fish + veg")
        ),
        snack = listOf(fruit, hummus, almonds),
        pre = listOf(banana, oatsLight),
        post = listOf(eggsFruit, yogurtFruit)
    )

    private val poolByCountry: Map<String, Pool> = buildMap {
        put("India", india); put("Sri Lanka", lanka); put("Nepal", india); put("Bangladesh", india); put("Pakistan", india)
        listOf("Malaysia", "Singapore", "Indonesia", "Philippines", "Thailand", "Vietnam").forEach { put(it, sea) }
        listOf("United Arab Emirates", "Saudi Arabia", "Qatar", "Kuwait", "Oman", "Bahrain", "Egypt", "Jordan").forEach { put(it, gulf) }
        listOf("United States", "Canada", "Australia", "New Zealand").forEach { put(it, usa) }
        listOf("United Kingdom", "Ireland", "Germany", "Netherlands", "Sweden").forEach { put(it, uk) }
        listOf("Italy", "Spain", "Greece", "Turkey", "France", "Portugal").forEach { put(it, med) }
        listOf("Japan", "China", "South Korea", "Taiwan", "Hong Kong").forEach { put(it, eastAsia) }
        listOf("Mexico", "Brazil", "Argentina", "Colombia", "Peru").forEach { put(it, latam) }
        listOf("Nigeria", "Ghana", "Kenya", "South Africa", "Ethiopia", "Uganda", "Tanzania").forEach { put(it, africa) }
    }

    val countries: List<String> = poolByCountry.keys.sorted() + "Other"

    fun poolFor(country: String): Pool = poolByCountry[country] ?: global
}
