package com.fittofit.app

import kotlin.math.roundToInt

class PlanMeal(
    /** B, L, D or S */
    val slot: String,
    val dish: Dish,
    val portion: Float,
    val kcal: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int,
    val fiber: Int
)

class DayPlan(val meals: List<PlanMeal>) {
    val kcal get() = meals.sumOf { it.kcal }
    val protein get() = meals.sumOf { it.protein }
    val carbs get() = meals.sumOf { it.carbs }
    val fat get() = meals.sumOf { it.fat }
    val fiber get() = meals.sumOf { it.fiber }
}

/** Builds a 7-day healthy eating plan from the person's country, body details and goal. */
object DietPlanner {

    fun targetKcal(p: Profile): Int {
        val w = if (p.weightKg > 0) p.weightKg else 65
        val h = if (p.heightCm > 0) p.heightCm else 165
        val a = if (p.age > 0) p.age else 30
        val sexAdj = when (p.sex) { "M" -> 5; "F" -> -161; else -> -78 }
        val bmr = 10.0 * w + 6.25 * h - 5.0 * a + sexAdj
        var t = bmr * 1.45
        t += when (p.goal) { "lose" -> -400.0; "gain" -> 350.0; else -> 0.0 }
        return ((t.coerceAtLeast(1300.0) / 50.0).roundToInt() * 50)
    }

    fun proteinTarget(p: Profile): Int {
        val w = if (p.weightKg > 0) p.weightKg else 65
        return (w * if (p.goal == "gain") 1.6 else 1.2).roundToInt()
    }

    private fun options(list: List<Dish>, veg: Boolean): List<Dish> {
        if (!veg) return list
        val v = list.filter { it.veg }
        return if (v.isEmpty()) list else v
    }

    private val shares = listOf("B" to 0.25, "L" to 0.32, "D" to 0.28, "S" to 0.15)

    private fun meal(slot: String, dish: Dish, kcalTarget: Double): PlanMeal {
        val raw = (kcalTarget / dish.kcal).coerceIn(0.6, 1.5)
        val portion = ((raw * 4).roundToInt() / 4f).coerceIn(0.5f, 1.5f)
        return PlanMeal(
            slot, dish, portion,
            (dish.kcal * portion).roundToInt(), (dish.protein * portion).roundToInt(),
            (dish.carbs * portion).roundToInt(), (dish.fat * portion).roundToInt(), (dish.fiber * portion).roundToInt()
        )
    }

    /** Seven days, Monday first. */
    fun week(p: Profile): List<DayPlan> {
        val pool = DietData.poolFor(p.country)
        val target = targetKcal(p).toDouble()
        val lists = mapOf(
            "B" to options(pool.breakfast, p.veg), "L" to options(pool.lunch, p.veg),
            "D" to options(pool.dinner, p.veg), "S" to options(pool.snack, p.veg)
        )
        return (0..6).map { day ->
            DayPlan(shares.mapIndexed { i, (slot, share) ->
                val l = lists.getValue(slot)
                meal(slot, l[(day + i) % l.size], target * share)
            })
        }
    }

    fun preWorkout(p: Profile): List<Dish> = options(DietData.poolFor(p.country).pre, p.veg).take(3)
    fun postWorkout(p: Profile): List<Dish> = options(DietData.poolFor(p.country).post, p.veg).take(3)
    fun regionName(p: Profile): String = DietData.poolFor(p.country).title

    fun slotName(slot: String) = when (slot) { "B" -> "Breakfast"; "L" -> "Lunch"; "D" -> "Dinner"; else -> "Snack" }
}
