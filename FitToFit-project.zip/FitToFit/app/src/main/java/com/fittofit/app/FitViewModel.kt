package com.fittofit.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FitUiState(
    val today: DaySummary = DaySummary(),
    val weeklySteps: List<Long> = List(7) { 0L },
    val healthConnected: Boolean = false,
    val healthAvailable: Boolean = true,
    val stepGoal: Int = 10_000,
    val userName: String = "Asha Hallon",
    val level: Int = 6,
    val streakDays: Int = 7
)

class FitViewModel(app: Application) : AndroidViewModel(app) {

    val health = HealthConnectManager(app)
    val ble = BleHeartRateManager(app)

    private val _state = MutableStateFlow(FitUiState())
    val state: StateFlow<FitUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            val available = health.isAvailable
            if (!available) {
                _state.value = _state.value.copy(healthAvailable = false, healthConnected = false)
                return@launch
            }
            val granted = health.hasAllPermissions()
            if (!granted) {
                _state.value = _state.value.copy(healthAvailable = true, healthConnected = false)
                return@launch
            }
            runCatching {
                val today = health.today()
                val week = health.weeklySteps()
                _state.value = _state.value.copy(
                    today = today, weeklySteps = week,
                    healthAvailable = true, healthConnected = true
                )
            }
        }
    }

    override fun onCleared() {
        ble.disconnect()
        super.onCleared()
    }
}
