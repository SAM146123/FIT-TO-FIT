package com.fittofit.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.max
import kotlinx.coroutines.flow.update
import kotlin.coroutines.cancellation.CancellationException
import com.fittofit.app.ui.activeMinutes
import java.time.DayOfWeek

data class WalkState(
    val running: Boolean = false,
    val seconds: Long = 0,
    val steps: Long = 0,
    val distanceKm: Double = 0.0,
    val kcal: Int = 0
)

data class FitUiState(
    /** Effective values for today (best of Health Connect / phone sensor). */
    val today: DaySummary = DaySummary(),
    val weeklySteps: List<Long> = List(7) { 0L },
    val weekDistanceKm: Double = 0.0,
    val healthConnected: Boolean = false,
    val healthAvailable: Boolean = true,
    val profile: Profile = Profile(),
    val level: Int = 1,
    val streakDays: Int = 0,
    val stepsSource: String = "",
    val sensorAvailable: Boolean = true,
    val walk: WalkState = WalkState(),
    // ---- extra health data ----
    val extras: HealthExtras = HealthExtras(),
    val waterMl: Int = 0,
    val foodKcal: Int = 0,
    val periodStarts: List<LocalDate> = emptyList(),
    val cycleLength: Int = 28,
    val periodLength: Int = 5,
    // ---- celebrations ----
    val showWelcome: Boolean = false,
    val showCelebration: Boolean = false
) {
    val stepGoal: Int get() = profile.stepGoal
}

class FitViewModel(app: Application) : AndroidViewModel(app) {

    val health = HealthConnectManager(app)
    val ble = BleHeartRateManager(app)
    val sensor = StepSensor(app)
    private val store = ProfileStore(app)
    private val logs = LogStore(app)

    // ---- friends & competition (Firebase) ----
    private val socialRepo: SocialRepository? = runCatching { SocialRepository() }.getOrNull()
    private val _social = MutableStateFlow(SocialState(signedIn = socialRepo?.signedIn == true))
    val social: StateFlow<SocialState> = _social.asStateFlow()
    private var lastPushAt = 0L
    private var lastPushed: Map<String, Any>? = null

    private var hcAvailable = true
    private var hcOk = false
    private var hcToday = DaySummary()
    private var hcWeek: List<Long> = List(7) { 0L }
    private var hcExtras = HealthExtras()

    private var walkRunning = false
    private var walkSeconds = 0L
    private var walkStartRaw = -1L
    private var walkJob: Job? = null

    private val _state = MutableStateFlow(
        FitUiState(profile = store.load(), sensorAvailable = sensor.available)
    )
    val state: StateFlow<FitUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { sensor.today.collect { recompute() } }
        viewModelScope.launch { sensor.raw.collect { if (walkRunning) recompute() } }
        // keep Google Fit / watch-app data fresh while the app is open
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                refresh()
                refreshFriendsSilently()
            }
        }
        refresh()
        if (socialRepo?.signedIn == true) {
            socialCall { r ->
                _social.update { it.copy(myCode = r.myCode()) }
                loadFriendsInternal(r)
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            hcAvailable = health.isAvailable
            hcOk = false
            if (hcAvailable && health.hasStepsPermission()) {
                hcToday = health.today()
                hcWeek = health.weeklySteps()
                hcExtras = health.extras()
                hcOk = true

                // fill height / weight from Google Fit when the user has not set them
                val p = store.load()
                if (p.heightCm == 0 || p.weightKg == 0) {
                    val (h, w) = health.bodyInfo()
                    store.save(
                        p.copy(
                            heightCm = if (p.heightCm == 0) h else p.heightCm,
                            weightKg = if (p.weightKg == 0) w else p.weightKg
                        )
                    )
                }
            }
            recompute()
        }
    }

    fun saveProfile(p: Profile) {
        store.save(p)
        recompute()
    }

    // ---- manual logs ----
    fun addWater(ml: Int) { logs.addWater(ml); recompute() }
    fun addFood(kcal: Int) { logs.addFood(kcal); recompute() }
    fun logPeriodToday() { logs.addPeriodStart(LocalDate.now()); recompute() }
    fun undoPeriod() { logs.removeLastPeriod(); recompute() }
    fun setCycle(cycleLength: Int, periodLength: Int) {
        logs.cycleLength = cycleLength
        logs.periodLength = periodLength
        recompute()
    }

    // ---- celebrations ----
    fun markWelcomed() { logs.welcomeDate = LocalDate.now().toString(); recompute() }
    fun markCelebrated() { logs.celebratedDate = LocalDate.now().toString(); recompute() }

    // ---- walking session ----
    fun startWalk() {
        if (!sensor.available) return
        walkRunning = true
        walkSeconds = 0
        walkStartRaw = sensor.raw.value // -1 until the first reading arrives
        walkJob?.cancel()
        walkJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                walkSeconds++
                recompute()
            }
        }
        recompute()
    }

    fun stopWalk() {
        walkRunning = false
        walkJob?.cancel()
        recompute()
    }

    private fun strideM(p: Profile): Double =
        if (p.heightCm > 0) p.heightCm * 0.415 / 100.0 else 0.72

    private fun weightOf(p: Profile): Int = if (p.weightKg > 0) p.weightKg else 65

    private fun walkNow(p: Profile): WalkState {
        val raw = sensor.raw.value
        if (walkStartRaw < 0 && raw >= 0) walkStartRaw = raw
        val steps = if (walkStartRaw >= 0 && raw >= walkStartRaw) raw - walkStartRaw else 0L
        val km = steps * strideM(p) / 1000.0
        val kcal = (0.53 * weightOf(p) * km).toInt()
        return WalkState(true, walkSeconds, steps, km, kcal)
    }

    private fun recompute() {
        val p = store.load()
        val live = sensor.today.value
        val hcSteps = if (hcOk) hcToday.steps else 0L
        val steps = max(live, hcSteps)

        val source = when {
            steps == 0L -> if (hcOk) "Google Fit / Health Connect" else ""
            hcOk && hcSteps >= live -> "Google Fit / Health Connect"
            else -> "Phone step sensor"
        }

        val stride = strideM(p)
        val estKm = steps * stride / 1000.0
        val km = max(if (hcOk) hcToday.distanceKm else 0.0, estKm)
        val kcal = max(if (hcOk) hcToday.calories else 0.0, 0.53 * weightOf(p) * estKm)

        val idx = LocalDate.now().dayOfWeek.value - 1
        val week = (if (hcOk) hcWeek else List(7) { 0L }).toMutableList()
        week[idx] = max(week[idx], steps)
        val weekSum = week.sum()

        val level = 1 + (weekSum / 30_000L).toInt().coerceAtMost(98)

        val threshold = p.stepGoal / 2
        var i = idx
        var streak = 0
        if (week[i] < threshold) i--
        while (i >= 0 && week[i] >= threshold) {
            streak++
            i--
        }

        val walk = if (walkRunning) walkNow(p) else _state.value.walk.copy(running = false)

        // cycle dates: manual logs + Health Connect
        val periods = (logs.periodStarts() + listOfNotNull(if (hcOk) hcExtras.lastPeriodStart else null))
            .distinct().sorted()

        val todayStr = LocalDate.now().toString()
        val showWelcome = p.name.isNotBlank() && logs.welcomeDate != todayStr
        val showCelebration = !showWelcome && steps > 0 && steps >= p.stepGoal && logs.celebratedDate != todayStr

        _state.value = FitUiState(
            today = DaySummary(steps, kcal, km, hcToday.lastHeartRate),
            weeklySteps = week,
            weekDistanceKm = weekSum * stride / 1000.0,
            healthConnected = hcOk,
            healthAvailable = hcAvailable,
            profile = p,
            level = level,
            streakDays = streak,
            stepsSource = source,
            sensorAvailable = sensor.available,
            walk = walk,
            extras = if (hcOk) hcExtras else HealthExtras(),
            waterMl = (if (hcOk) hcExtras.waterMl else 0) + logs.waterMl(),
            foodKcal = (if (hcOk) hcExtras.nutritionKcal.toInt() else 0) + logs.foodKcal(),
            periodStarts = periods,
            cycleLength = logs.cycleLength,
            periodLength = logs.periodLength,
            showWelcome = showWelcome,
            showCelebration = showCelebration
        )
        pushStatsThrottled(_state.value)
    }

    // ================= friends & competition =================

    private fun socialCall(block: suspend (SocialRepository) -> Unit) {
        val repo = socialRepo
        if (repo == null) {
            _social.update { it.copy(error = "Firebase is not set up in this build.") }
            return
        }
        viewModelScope.launch {
            _social.update { it.copy(loading = true, error = null, message = null) }
            try {
                block(repo)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _social.update { it.copy(error = friendlyError(e)) }
            }
            _social.update { it.copy(loading = false) }
        }
    }

    private suspend fun loadFriendsInternal(r: SocialRepository) {
        val (count, list) = r.loadFriends()
        _social.update { it.copy(friends = list, friendCount = count) }
    }

    private fun refreshFriendsSilently() {
        val r = socialRepo ?: return
        if (!r.signedIn) return
        viewModelScope.launch {
            try {
                loadFriendsInternal(r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // stay quiet; the next refresh will try again
            }
        }
    }

    fun signUp(name: String, email: String, password: String) = socialCall { r ->
        require(name.isNotBlank()) { "Please enter your name." }
        require(email.isNotBlank()) { "Please enter your email." }
        require(password.length >= 6) { "Password must be at least 6 characters." }
        val code = r.signUp(name.trim(), email.trim(), password)
        _social.update { it.copy(signedIn = true, myCode = code) }
        pushStatsNow(r)
        loadFriendsInternal(r)
    }

    fun signIn(email: String, password: String) = socialCall { r ->
        require(email.isNotBlank()) { "Please enter your email." }
        require(password.isNotEmpty()) { "Please enter your password." }
        r.signIn(email.trim(), password)
        val code = r.myCode()
        _social.update { it.copy(signedIn = true, myCode = code) }
        pushStatsNow(r)
        loadFriendsInternal(r)
    }

    fun signOut() {
        socialRepo?.signOut()
        lastPushed = null
        _social.value = SocialState()
    }

    fun refreshFriends() = socialCall { r ->
        if (r.signedIn) {
            pushStatsNow(r)
            loadFriendsInternal(r)
        }
    }

    fun addFriend(code: String) = socialCall { r ->
        val name = r.addFriendByCode(code, _social.value.friendCount)
        loadFriendsInternal(r)
        _social.update { it.copy(message = "$name is now your friend! 🎉") }
    }

    fun removeFriend(uid: String) = socialCall { r ->
        r.removeFriend(uid)
        loadFriendsInternal(r)
    }

    fun clearSocialNotice() {
        _social.update { it.copy(error = null, message = null) }
    }

    private fun statsMap(s: FitUiState): Map<String, Any> {
        val today = LocalDate.now()
        val map = mutableMapOf<String, Any>(
            "stepsDate" to today.toString(),
            "weekKey" to today.with(DayOfWeek.MONDAY).toString(),
            "steps" to s.today.steps,
            "weekSteps" to s.weeklySteps.sum(),
            "kcal" to s.today.calories.toInt(),
            "distanceKm" to Math.round(s.today.distanceKm * 100) / 100.0,
            "activeMin" to activeMinutes(s),
            "streak" to s.streakDays,
            "level" to s.level
        )
        if (s.profile.name.isNotBlank()) map["name"] = s.profile.name
        return map
    }

    private suspend fun pushStatsNow(r: SocialRepository) {
        val map = statsMap(_state.value)
        r.pushStats(map)
        lastPushed = map
        lastPushAt = System.currentTimeMillis()
    }

    /** Shares your numbers with friends at most once a minute, and only when they changed. */
    private fun pushStatsThrottled(s: FitUiState) {
        val r = socialRepo ?: return
        if (!r.signedIn) return
        val now = System.currentTimeMillis()
        if (now - lastPushAt < 60_000) return
        val map = statsMap(s)
        if (map == lastPushed) return
        lastPushAt = now
        viewModelScope.launch {
            try {
                r.pushStats(map)
                lastPushed = map
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // will retry on the next update
            }
        }
    }

    override fun onCleared() {
        ble.disconnect()
        sensor.stop()
        super.onCleared()
    }
}
