package com.fittofit.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.max

data class WalkState(
    val running: Boolean = false,
    val seconds: Long = 0,
    val steps: Long = 0,
    val distanceKm: Double = 0.0,
    val kcal: Int = 0
)

data class FitUiState(
    /** Effective values for today (best of Health Connect / phone sensor). */
    val today: DaySummary = DaySummary(),
    val weeklySteps: List<Long> = List(7) { 0L },
    val weekDistanceKm: Double = 0.0,
    val healthConnected: Boolean = false,
    val healthAvailable: Boolean = true,
    val profile: Profile = Profile(),
    val level: Int = 1,
    val streakDays: Int = 0,
    val stepsSource: String = "",
    val sensorAvailable: Boolean = true,
    val walk: WalkState = WalkState()
) {
    val stepGoal: Int get() = profile.stepGoal
}

class FitViewModel(app: Application) : AndroidViewModel(app) {

    val health = HealthConnectManager(app)
    val ble = BleHeartRateManager(app)
    val sensor = StepSensor(app)
    private val store = ProfileStore(app)

    private var hcAvailable = true
    private var hcOk = false
    private var hcToday = DaySummary()
    private var hcWeek: List<Long> = List(7) { 0L }

    private var walkRunning = false
    private var walkSeconds = 0L
    private var walkStartRaw = -1L
    private var walkJob: Job? = null

    private val _state = MutableStateFlow(
        FitUiState(profile = store.load(), sensorAvailable = sensor.available)
    )
    val state: StateFlow<FitUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { sensor.today.collect { recompute() } }
        viewModelScope.launch { sensor.raw.collect { if (walkRunning) recompute() } }
        // keep Google Fit / watch-app data fresh while the app is open
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                refresh()
            }
        }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            hcAvailable = health.isAvailable
            hcOk = false
            if (hcAvailable && health.hasStepsPermission()) {
                hcToday = health.today()
                hcWeek = health.weeklySteps()
                hcOk = true

                // fill height / weight from Google Fit when the user has not set them
                val p = store.load()
                if (p.heightCm == 0 || p.weightKg == 0) {
                    val (h, w) = health.bodyInfo()
                    store.save(
                        p.copy(
                            heightCm = if (p.heightCm == 0) h else p.heightCm,
                            weightKg = if (p.weightKg == 0) w else p.weightKg
                        )
                    )
                }
            }
            recompute()
        }
    }

    fun saveProfile(p: Profile) {
        store.save(p)
        recompute()
    }

    fun startWalk() {
        if (!sensor.available) return
        walkRunning = true
        walkSeconds = 0
        walkStartRaw = sensor.raw.value // -1 until the first reading arrives
        walkJob?.cancel()
        walkJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                walkSeconds++
                recompute()
            }
        }
        recompute()
    }

    fun stopWalk() {
        walkRunning = false
        walkJob?.cancel()
        recompute()
    }

    private fun strideM(p: Profile): Double =
        if (p.heightCm > 0) p.heightCm * 0.415 / 100.0 else 0.72

    private fun weightOf(p: Profile): Int = if (p.weightKg > 0) p.weightKg else 65

    private fun walkNow(p: Profile): WalkState {
        val raw = sensor.raw.value
        if (walkStartRaw < 0 && raw >= 0) walkStartRaw = raw
        val steps = if (walkStartRaw >= 0 && raw >= walkStartRaw) raw - walkStartRaw else 0L
        val km = steps * strideM(p) / 1000.0
        val kcal = (0.53 * weightOf(p) * km).toInt()
        return WalkState(true, walkSeconds, steps, km, kcal)
    }

    private fun recompute() {
        val p = store.load()
        val live = sensor.today.value
        val hcSteps = if (hcOk) hcToday.steps else 0L
        val steps = max(live, hcSteps)

        val source = when {
            steps == 0L -> if (hcOk) "Google Fit / Health Connect" else ""
            hcOk && hcSteps >= live -> "Google Fit / Health Connect"
            else -> "Phone step sensor"
        }

        val stride = strideM(p)
        val estKm = steps * stride / 1000.0
        val km = max(if (hcOk) hcToday.distanceKm else 0.0, estKm)
        val kcal = max(if (hcOk) hcToday.calories else 0.0, 0.53 * weightOf(p) * estKm)

        val idx = LocalDate.now().dayOfWeek.value - 1
        val week = (if (hcOk) hcWeek else List(7) { 0L }).toMutableList()
        week[idx] = max(week[idx], steps)
        val weekSum = week.sum()

        val level = 1 + (weekSum / 30_000L).toInt().coerceAtMost(98)

        val threshold = p.stepGoal / 2
        var i = idx
        var streak = 0
        if (week[i] < threshold) i--
        while (i >= 0 && week[i] >= threshold) {
            streak++
            i--
        }

        val walk = if (walkRunning) walkNow(p) else _state.value.walk.copy(running = false)

        _state.value = FitUiState(
            today = DaySummary(steps, kcal, km, hcToday.lastHeartRate),
            weeklySteps = week,
            weekDistanceKm = weekSum * stride / 1000.0,
            healthConnected = hcOk,
            healthAvailable = hcAvailable,
            profile = p,
            level = level,
            streakDays = streak,
            stepsSource = source,
            sensorAvailable = sensor.available,
            walk = walk
        )
    }

    override fun onCleared() {
        ble.disconnect()
        sensor.stop()
        super.onCleared()
    }
}
