package com.fittofit.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.max
import kotlinx.coroutines.flow.update
import kotlin.coroutines.cancellation.CancellationException
import com.fittofit.app.ui.activeMinutes
import java.time.DayOfWeek
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class WalkState(
    val running: Boolean = false,
    val seconds: Long = 0,
    val steps: Long = 0,
    val distanceKm: Double = 0.0,
    val kcal: Int = 0,
    val gps: Boolean = false
)

data class FitUiState(
    /** Effective values for today (best of Health Connect / phone sensor). */
    val today: DaySummary = DaySummary(),
    val weeklySteps: List<Long> = List(7) { 0L },
    val weekDistanceKm: Double = 0.0,
    val healthConnected: Boolean = false,
    val healthAvailable: Boolean = true,
    val profile: Profile = Profile(),
    val level: Int = 1,
    val streakDays: Int = 0,
    val stepsSource: String = "",
    val sensorAvailable: Boolean = true,
    val walk: WalkState = WalkState(),
    // ---- extra health data ----
    val extras: HealthExtras = HealthExtras(),
    val waterMl: Int = 0,
    val foodKcal: Int = 0,
    val periodStarts: List<LocalDate> = emptyList(),
    val cycleLength: Int = 28,
    val periodLength: Int = 5,
    // ---- celebrations ----
    val showWelcome: Boolean = false,
    val showCelebration: Boolean = false,
    // ---- photo, voice, watch, activity ----
    val photoB64: String = "",
    val voiceOn: Boolean = false,
    val voiceProblem: String? = null,
    val pairedWatch: String = "",
    val activity: List<ActivityItem> = emptyList()
) {
    val stepGoal: Int get() = profile.stepGoal
}

class FitViewModel(app: Application) : AndroidViewModel(app) {

    val health = HealthConnectManager(app)
    val ble = BleHeartRateManager(app)
    val sensor = StepSensor(app)
    private val store = ProfileStore(app)
    private val logs = LogStore(app)
    val voice = VoiceCoach(app)
    private val gps = GpsTracker(app)
    private var hcSessions: List<ActivityItem> = emptyList()
    private var photo: String = PhotoStore.thumbBase64(app)
    private var nextAnnounceKm = 0.5
    private val appCtx = app

    // ---- friends & competition (Firebase) ----
    private val socialRepo: SocialRepository? = runCatching { SocialRepository() }.getOrNull()
    private val _social = MutableStateFlow(SocialState(signedIn = socialRepo?.signedIn == true))
    val social: StateFlow<SocialState> = _social.asStateFlow()
    private var lastPushAt = 0L
    private var lastPushed: Map<String, Any>? = null

    private var hcAvailable = true
    private var hcOk = false
    private var hcToday = DaySummary()
    private var hcWeek: List<Long> = List(7) { 0L }
    private var hcExtras = HealthExtras()

    private var walkRunning = false
    private var walkSeconds = 0L
    private var walkStartRaw = -1L
    private var walkJob: Job? = null

    private val _state = MutableStateFlow(
        FitUiState(profile = store.load(), sensorAvailable = sensor.available)
    )
    val state: StateFlow<FitUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { sensor.today.collect { recompute() } }
        viewModelScope.launch { sensor.raw.collect { if (walkRunning) recompute() } }
        viewModelScope.launch { voice.enabled.collect { recompute() } }
        viewModelScope.launch { voice.problem.collect { recompute() } }
        viewModelScope.launch { ble.pairedName.collect { recompute() } }
        // keep Google Fit / watch-app data fresh while the app is open
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                refresh()
                refreshFriendsSilently()
            }
        }
        refresh()
        if (socialRepo?.signedIn == true) {
            socialCall { r ->
                _social.update { it.copy(myCode = r.myCode()) }
                loadFriendsInternal(r)
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            hcAvailable = health.isAvailable
            hcOk = false
            if (hcAvailable && health.hasStepsPermission()) {
                hcToday = health.today()
                hcWeek = health.weeklySteps()
                hcExtras = health.extras()
                hcSessions = health.recentSessions()
                hcOk = true

                // fill height / weight from Google Fit when the user has not set them
                val p = store.load()
                if (p.heightCm == 0 || p.weightKg == 0) {
                    val (h, w) = health.bodyInfo()
                    store.save(
                        p.copy(
                            heightCm = if (p.heightCm == 0) h else p.heightCm,
                            weightKg = if (p.weightKg == 0) w else p.weightKg
                        )
                    )
                }
            }
            recompute()
        }
    }

    fun saveProfile(p: Profile) {
        store.save(p)
        recompute()
    }

    // ---- manual logs ----
    fun addWater(ml: Int) { logs.addWater(ml); recompute() }
    fun addFood(kcal: Int) { logs.addFood(kcal); recompute() }
    fun logPeriodToday() { logs.addPeriodStart(LocalDate.now()); recompute() }
    fun undoPeriod() { logs.removeLastPeriod(); recompute() }
    fun setCycle(cycleLength: Int, periodLength: Int) {
        logs.cycleLength = cycleLength
        logs.periodLength = periodLength
        recompute()
    }

    // ---- celebrations ----
    fun markWelcomed() { logs.welcomeDate = LocalDate.now().toString(); recompute() }
    fun markCelebrated() { logs.celebratedDate = LocalDate.now().toString(); recompute() }

    // ---- photo & voice ----
    fun setPhoto(uri: Uri) {
        viewModelScope.launch {
            val b64 = withContext(Dispatchers.IO) {
                PhotoStore.saveFrom(appCtx, uri)
                PhotoStore.thumbBase64(appCtx)
            }
            photo = b64
            recompute()
        }
    }

    fun removePhoto() {
        PhotoStore.clear(appCtx)
        photo = ""
        recompute()
    }

    fun setVoice(on: Boolean) = voice.setEnabled(on)
    fun speak(text: String, interrupt: Boolean) = voice.speak(text, interrupt)
    fun stopSpeak() = voice.stop()

    /** Called when a Video Coach workout is finished. */
    fun finishWorkout(title: String, minutes: Int, kcal: Int) {
        logs.addSession(ActivityItem(title, System.currentTimeMillis() - minutes * 60_000L, minutes, 0.0, kcal, "FIT TO FIT"))
        recompute()
    }

    fun isWalking() = walkRunning

    // ---- walking session ----
    fun startWalk() {
        if (!sensor.available && !gps.hasPermission()) return
        walkRunning = true
        walkSeconds = 0
        walkStartRaw = sensor.raw.value // -1 until the first reading arrives
        nextAnnounceKm = 0.5
        gps.onUpdate = { recompute() }
        gps.start()
        WalkService.start(appCtx)
        voice.speak("Walk started. Let's go!", true)
        walkJob?.cancel()
        walkJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                walkSeconds++
                recompute()
            }
        }
        recompute()
    }

    fun stopWalk() {
        if (!walkRunning) return
        val w = walkNow(store.load())
        walkRunning = false
        walkJob?.cancel()
        gps.stop()
        WalkService.stop(appCtx)
        val mins = ((w.seconds + 30) / 60).toInt()
        voice.speak(
            "Walk finished. You covered ${"%.2f".format(w.distanceKm)} kilometres in $mins minutes. Great job!", true
        )
        if (w.seconds >= 30) {
            logs.addSession(ActivityItem("Walking", System.currentTimeMillis() - w.seconds * 1000, mins.coerceAtLeast(1), w.distanceKm, w.kcal, "FIT TO FIT"))
        }
        recompute()
    }

    private fun announce(w: WalkState) {
        while (w.distanceKm >= nextAnnounceKm) {
            val km = nextAnnounceKm
            nextAnnounceKm += 0.5
            val m = w.seconds / 60
            val sec = w.seconds % 60
            val paceSec = if (w.distanceKm > 0) (w.seconds / w.distanceKm).toLong() else 0L
            val kmText = if (km % 1.0 == 0.0) "${km.toInt()} kilometre${if (km.toInt() == 1) "" else "s"}" else "%.1f kilometres".format(km)
            voice.speak(
                "You have covered $kmText. Time $m minutes $sec seconds. " +
                    "Average pace ${paceSec / 60} minutes ${paceSec % 60} seconds per kilometre.",
                false
            )
        }
    }

    private fun strideM(p: Profile): Double =
        if (p.heightCm > 0) p.heightCm * 0.415 / 100.0 else 0.72

    private fun weightOf(p: Profile): Int = if (p.weightKg > 0) p.weightKg else 65

    private fun walkNow(p: Profile): WalkState {
        val raw = sensor.raw.value
        if (walkStartRaw < 0 && raw >= 0) walkStartRaw = raw
        val steps = if (walkStartRaw >= 0 && raw >= walkStartRaw) raw - walkStartRaw else 0L
        val useGps = gps.active && gps.meters > 0
        val km = if (useGps) gps.meters / 1000.0 else steps * strideM(p) / 1000.0
        val kcal = (0.53 * weightOf(p) * km).toInt()
        return WalkState(true, walkSeconds, steps, km, kcal, gps.active)
    }

    private fun recompute() {
        val p = store.load()
        val live = sensor.today.value
        val hcSteps = if (hcOk) hcToday.steps else 0L
        val steps = max(live, hcSteps)

        val source = when {
            steps == 0L -> if (hcOk) "Google Fit / Health Connect" else ""
            hcOk && hcSteps >= live -> "Google Fit / Health Connect"
            else -> "Phone step sensor"
        }

        val stride = strideM(p)
        val estKm = steps * stride / 1000.0
        val km = max(if (hcOk) hcToday.distanceKm else 0.0, estKm)
        val kcal = max(if (hcOk) hcToday.calories else 0.0, 0.53 * weightOf(p) * estKm)

        val idx = LocalDate.now().dayOfWeek.value - 1
        val week = (if (hcOk) hcWeek else List(7) { 0L }).toMutableList()
        week[idx] = max(week[idx], steps)
        val weekSum = week.sum()

        val level = 1 + (weekSum / 30_000L).toInt().coerceAtMost(98)

        val threshold = p.stepGoal / 2
        var i = idx
        var streak = 0
        if (week[i] < threshold) i--
        while (i >= 0 && week[i] >= threshold) {
            streak++
            i--
        }

        val walk = if (walkRunning) walkNow(p) else _state.value.walk.copy(running = false)
        if (walkRunning) announce(walk)

        val activity = (hcSessions + logs.sessions()).sortedByDescending { it.startMs }.take(15)

        // cycle dates: manual logs + Health Connect
        val periods = (logs.periodStarts() + listOfNotNull(if (hcOk) hcExtras.lastPeriodStart else null))
            .distinct().sorted()

        val todayStr = LocalDate.now().toString()
        val showWelcome = p.name.isNotBlank() && logs.welcomeDate != todayStr
        val showCelebration = !showWelcome && steps > 0 && steps >= p.stepGoal && logs.celebratedDate != todayStr

        _state.value = FitUiState(
            today = DaySummary(steps, kcal, km, hcToday.lastHeartRate),
            weeklySteps = week,
            weekDistanceKm = weekSum * stride / 1000.0,
            healthConnected = hcOk,
            healthAvailable = hcAvailable,
            profile = p,
            level = level,
            streakDays = streak,
            stepsSource = source,
            sensorAvailable = sensor.available,
            walk = walk,
            extras = if (hcOk) hcExtras else HealthExtras(),
            waterMl = (if (hcOk) hcExtras.waterMl else 0) + logs.waterMl(),
            foodKcal = (if (hcOk) hcExtras.nutritionKcal.toInt() else 0) + logs.foodKcal(),
            periodStarts = periods,
            cycleLength = logs.cycleLength,
            periodLength = logs.periodLength,
            showWelcome = showWelcome,
            showCelebration = showCelebration,
            photoB64 = photo,
            voiceOn = voice.enabled.value,
            voiceProblem = voice.problem.value,
            pairedWatch = ble.pairedName.value ?: "",
            activity = activity
        )
        pushStatsThrottled(_state.value)
    }

    // ================= friends & competition =================

    private fun socialCall(block: suspend (SocialRepository) -> Unit) {
        val repo = socialRepo
        if (repo == null) {
            _social.update { it.copy(error = "Firebase is not set up in this build.") }
            return
        }
        viewModelScope.launch {
            _social.update { it.copy(loading = true, error = null, message = null) }
            try {
                block(repo)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _social.update { it.copy(error = friendlyError(e)) }
            }
            _social.update { it.copy(loading = false) }
        }
    }

    private suspend fun loadFriendsInternal(r: SocialRepository) {
        val (count, list) = r.loadFriends()
        _social.update { it.copy(friends = list, friendCount = count) }
    }

    private fun refreshFriendsSilently() {
        val r = socialRepo ?: return
        if (!r.signedIn) return
        viewModelScope.launch {
            try {
                loadFriendsInternal(r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // stay quiet; the next refresh will try again
            }
        }
    }

    fun signUp(name: String, email: String, password: String) = socialCall { r ->
        require(name.isNotBlank()) { "Please enter your name." }
        require(email.isNotBlank()) { "Please enter your email." }
        require(password.length >= 6) { "Password must be at least 6 characters." }
        val code = r.signUp(name.trim(), email.trim(), password)
        _social.update { it.copy(signedIn = true, myCode = code) }
        pushStatsNow(r)
        loadFriendsInternal(r)
    }

    fun signIn(email: String, password: String) = socialCall { r ->
        require(email.isNotBlank()) { "Please enter your email." }
        require(password.isNotEmpty()) { "Please enter your password." }
        r.signIn(email.trim(), password)
        val code = r.myCode()
        _social.update { it.copy(signedIn = true, myCode = code) }
        pushStatsNow(r)
        loadFriendsInternal(r)
    }

    fun signOut() {
        socialRepo?.signOut()
        lastPushed = null
        _social.value = SocialState()
    }

    fun refreshFriends() = socialCall { r ->
        if (r.signedIn) {
            pushStatsNow(r)
            loadFriendsInternal(r)
        }
    }

    fun addFriend(code: String) = socialCall { r ->
        val name = r.addFriendByCode(code, _social.value.friendCount)
        loadFriendsInternal(r)
        _social.update { it.copy(message = "$name is now your friend! 🎉") }
    }

    fun removeFriend(uid: String) = socialCall { r ->
        r.removeFriend(uid)
        loadFriendsInternal(r)
    }

    fun clearSocialNotice() {
        _social.update { it.copy(error = null, message = null) }
    }

    private fun statsMap(s: FitUiState): Map<String, Any> {
        val today = LocalDate.now()
        val map = mutableMapOf<String, Any>(
            "stepsDate" to today.toString(),
            "weekKey" to today.with(DayOfWeek.MONDAY).toString(),
            "steps" to s.today.steps,
            "weekSteps" to s.weeklySteps.sum(),
            "kcal" to s.today.calories.toInt(),
            "distanceKm" to Math.round(s.today.distanceKm * 100) / 100.0,
            "activeMin" to activeMinutes(s),
            "streak" to s.streakDays,
            "level" to s.level
        )
        if (s.profile.name.isNotBlank()) map["name"] = s.profile.name
        map["photo"] = s.photoB64
        return map
    }

    private suspend fun pushStatsNow(r: SocialRepository) {
        val map = statsMap(_state.value)
        r.pushStats(map)
        lastPushed = map
        lastPushAt = System.currentTimeMillis()
    }

    /** Shares your numbers with friends at most once a minute, and only when they changed. */
    private fun pushStatsThrottled(s: FitUiState) {
        val r = socialRepo ?: return
        if (!r.signedIn) return
        val now = System.currentTimeMillis()
        if (now - lastPushAt < 60_000) return
        val map = statsMap(s)
        if (map == lastPushed) return
        lastPushAt = now
        viewModelScope.launch {
            try {
                r.pushStats(map)
                lastPushed = map
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // will retry on the next update
            }
        }
    }

    override fun onCleared() {
        ble.release()
        gps.stop()
        voice.shutdown()
        sensor.stop()
        super.onCleared()
    }
}
