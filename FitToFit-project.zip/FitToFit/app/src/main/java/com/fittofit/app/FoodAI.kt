package com.fittofit.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

data class FoodItem(
    val name: String,
    val grams: Double,
    val kcal: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val fiber: Double
)

data class FoodResult(val items: List<FoodItem>, val note: String)

class FoodAiException(message: String) : Exception(message)

/** Reads a food photo with Google's Gemini AI and returns an estimate of the nutrition. */
object FoodAI {

    private val models = listOf("gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash")

    private const val PROMPT =
        "You are a nutrition expert. Look at this photo of a meal. Identify each separate food item " +
            "(think about common Indian and international dishes). Estimate the portion size in grams from visual " +
            "clues such as plate, bowl, spoon or hand size, then give nutrition for that portion. " +
            "Reply ONLY with JSON in this exact shape: " +
            "{\"is_food\":true,\"items\":[{\"name\":\"\",\"grams\":0,\"kcal\":0,\"protein_g\":0,\"carbs_g\":0,\"fat_g\":0,\"fiber_g\":0}]," +
            "\"note\":\"one short sentence about how sure you are\"}. " +
            "If the photo has no food, reply {\"is_food\":false,\"items\":[],\"note\":\"No food found\"}."

    // ---- key storage ----
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ai", Context.MODE_PRIVATE)
    fun key(ctx: Context): String = prefs(ctx).getString("key", "") ?: ""
    fun saveKey(ctx: Context, k: String) = prefs(ctx).edit().putString("key", k.trim()).apply()

    // ---- pictures ----
    /** Loads a picture, shrinks it to at most 1024 px and returns it. */
    fun loadBitmap(ctx: Context, uri: Uri): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        bmp?.let { shrink(it, 1024) }
    } catch (e: Exception) {
        null
    }

    private fun shrink(b: Bitmap, maxSide: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= maxSide) return b
        val f = maxSide.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    // ---- analysis (call from a background thread) ----
    fun analyze(apiKey: String, bitmap: Bitmap): FoodResult {
        if (apiKey.isBlank()) throw FoodAiException("Please add your Gemini key first.")
        val out = ByteArrayOutputStream()
        shrink(bitmap, 1024).compress(Bitmap.CompressFormat.JPEG, 85, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

        val body = JSONObject().apply {
            put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray()
                .put(JSONObject().put("text", PROMPT))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))))))
            put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
        }.toString()

        var lastError = "Could not reach the AI service."
        for (model in models) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20_000
                conn.readTimeout = 60_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey)
                conn.outputStream.use { it.write(body.toByteArray()) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                when {
                    code in 200..299 -> return parse(text)
                    code == 400 || code == 403 -> throw FoodAiException("The Gemini key was not accepted. Check that you pasted it fully.")
                    code == 429 -> throw FoodAiException("Free limit reached for now. Please try again in a minute.")
                    code == 404 -> lastError = "AI model not found."
                    else -> lastError = "AI service error ($code)."
                }
            } catch (e: FoodAiException) {
                throw e
            } catch (e: java.io.IOException) {
                throw FoodAiException("No internet connection.")
            } finally {
                conn.disconnect()
            }
        }
        throw FoodAiException(lastError)
    }

    private fun parse(response: String): FoodResult {
        try {
            val parts = JSONObject(response).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            var text = ""
            for (i in 0 until parts.length()) text += parts.getJSONObject(i).optString("text")
            text = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val j = JSONObject(text)
            if (!j.optBoolean("is_food", true)) throw FoodAiException("No food found in this photo. Try another one.")
            val arr = j.getJSONArray("items")
            val items = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                FoodItem(
                    o.optString("name", "Food"), o.optDouble("grams", 0.0), o.optDouble("kcal", 0.0),
                    o.optDouble("protein_g", 0.0), o.optDouble("carbs_g", 0.0),
                    o.optDouble("fat_g", 0.0), o.optDouble("fiber_g", 0.0)
                )
            }
            if (items.isEmpty()) throw FoodAiException("No food found in this photo. Try another one.")
            return FoodResult(items, j.optString("note", ""))
        } catch (e: FoodAiException) {
            throw e
        } catch (e: Exception) {
            throw FoodAiException("Could not read the AI answer. Please try again.")
        }
    }
}
