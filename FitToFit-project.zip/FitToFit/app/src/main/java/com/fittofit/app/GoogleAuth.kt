package com.fittofit.app

import android.app.Activity
import android.graphics.BitmapFactory
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class GoogleAccount(val idToken: String, val name: String, val email: String, val photoUrl: String)

/** "Sign in with Google": gives the name, e-mail and photo of the person's Google account. */
object GoogleAuth {

    /** Returns null when the person closes the Google window. */
    suspend fun signIn(activity: Activity): GoogleAccount? {
        val id = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
        if (id == 0) {
            throw IllegalArgumentException(
                "Google sign-in is not set up yet. In Firebase turn on Google sign-in, add the SHA-1 key, and upload the new google-services.json."
            )
        }
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(activity.getString(id))
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            val result = CredentialManager.create(activity).getCredential(activity, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                GoogleAccount(g.idToken, g.displayName ?: "", g.id, g.profilePictureUri?.toString() ?: "")
            } else {
                throw IllegalArgumentException("Google sign-in did not return an account.")
            }
        } catch (e: GetCredentialCancellationException) {
            null
        }
    }

    /** Downloads the Google account photo. */
    suspend fun downloadPhoto(url: String) = withContext(Dispatchers.IO) {
        try {
            val big = url.replace(Regex("=s\\d+-c"), "=s256-c")
            val c = URL(big).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }
}
