package com.fittofit.app

import android.app.Activity
import android.graphics.BitmapFactory
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class GoogleAccount(val idToken: String, val name: String, val email: String, val photoUrl: String)

/** "Sign in with Google": gives the name, e-mail and photo of the person's Google account. */
object GoogleAuth {

    private fun prefs(ctx: android.content.Context) = ctx.getSharedPreferences("google_auth", android.content.Context.MODE_PRIVATE)

    fun saveClientId(ctx: android.content.Context, id: String) {
        prefs(ctx).edit().putString("web_client_id", id.trim()).apply()
    }

    /** The Web client ID: typed in the app, or (when google-services.json has it) built into the app. */
    fun clientId(ctx: android.content.Context): String {
        val typed = prefs(ctx).getString("web_client_id", "") ?: ""
        if (typed.isNotBlank()) return typed
        val id = ctx.resources.getIdentifier("default_web_client_id", "string", ctx.packageName)
        return if (id != 0) ctx.getString(id) else ""
    }

    /** Returns null when the person closes the Google window. */
    suspend fun signIn(activity: Activity): GoogleAccount? {
        val clientId = clientId(activity)
        if (clientId.isBlank()) {
            throw IllegalArgumentException(
                "Google sign-in needs the Web client ID. Tap \"Google setup\" below and paste it (from Firebase > Authentication > Sign-in method > Google)."
            )
        }
        // the "Sign in with Google" button flow: always shows the account chooser
        val option = com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption.Builder(clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            val result = CredentialManager.create(activity).getCredential(activity, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                GoogleAccount(g.idToken, g.displayName ?: "", g.id, g.profilePictureUri?.toString() ?: "")
            } else {
                throw IllegalArgumentException("Google sign-in did not return an account.")
            }
        } catch (e: GetCredentialCancellationException) {
            null
        } catch (e: androidx.credentials.exceptions.GetCredentialException) {
            throw IllegalArgumentException(
                "Google sign-in failed (${e.javaClass.simpleName}). Check: 1) a Google account is added on this phone, " +
                    "2) the SHA-1 key is saved in Firebase > Project settings, 3) the Web client ID is correct. ${e.message ?: ""}"
            )
        }
    }

    /** Downloads the Google account photo. */
    suspend fun downloadPhoto(url: String) = withContext(Dispatchers.IO) {
        try {
            val big = url.replace(Regex("=s\\d+-c"), "=s256-c")
            val c = URL(big).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }
}
