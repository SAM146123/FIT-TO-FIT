package com.fittofit.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.AggregateGroupByPeriodRequest
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId

data class DaySummary(
    val steps: Long = 0,
    val calories: Double = 0.0,
    val distanceKm: Double = 0.0,
    val lastHeartRate: Int = 0
)

/**
 * Reads the data that Google Fit (and most Android fitness apps / watches) sync into
 * Health Connect. Google is retiring the old Google Fit Android API, and Health Connect is
 * the official replacement, so this is the supported way to get Google Fit data.
 */
class HealthConnectManager(private val context: Context) {

    val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class)
    )

    val sdkStatus: Int get() = HealthConnectClient.getSdkStatus(context)
    val isAvailable: Boolean get() = sdkStatus == HealthConnectClient.SDK_AVAILABLE

    private val client by lazy { HealthConnectClient.getOrCreate(context) }

    suspend fun hasAllPermissions(): Boolean =
        isAvailable && client.permissionController.getGrantedPermissions().containsAll(permissions)

    suspend fun today(): DaySummary {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now().atStartOfDay(zone).toInstant()
        val now = Instant.now()

        val agg = client.aggregate(
            AggregateRequest(
                metrics = setOf(
                    StepsRecord.COUNT_TOTAL,
                    DistanceRecord.DISTANCE_TOTAL,
                    TotalCaloriesBurnedRecord.ENERGY_TOTAL
                ),
                timeRangeFilter = TimeRangeFilter.between(start, now)
            )
        )

        val hr = client.readRecords(
            ReadRecordsRequest(
                recordType = HeartRateRecord::class,
                timeRangeFilter = TimeRangeFilter.between(start, now),
                ascendingOrder = false,
                pageSize = 1
            )
        ).records.firstOrNull()?.samples?.lastOrNull()?.beatsPerMinute?.toInt() ?: 0

        return DaySummary(
            steps = agg[StepsRecord.COUNT_TOTAL] ?: 0L,
            calories = agg[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0,
            distanceKm = (agg[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0) / 1000.0,
            lastHeartRate = hr
        )
    }

    /** Steps for Monday..Sunday of the current week (0 for future days). */
    suspend fun weeklySteps(): List<Long> {
        val monday = LocalDate.now().with(DayOfWeek.MONDAY)
        val rows = client.aggregateGroupByPeriod(
            AggregateGroupByPeriodRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(
                    monday.atStartOfDay(),
                    monday.plusDays(7).atStartOfDay()
                ),
                timeRangeSlicer = Period.ofDays(1)
            )
        )
        val byDate = rows.associate { it.startTime.toLocalDate() to (it.result[StepsRecord.COUNT_TOTAL] ?: 0L) }
        return (0..6).map { byDate[monday.plusDays(it.toLong())] ?: 0L }
    }
}
