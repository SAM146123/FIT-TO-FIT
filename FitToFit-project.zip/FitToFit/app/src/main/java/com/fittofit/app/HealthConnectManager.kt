package com.fittofit.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.BodyFatRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.HeightRecord
import androidx.health.connect.client.records.HydrationRecord
import androidx.health.connect.client.records.LeanBodyMassRecord
import androidx.health.connect.client.records.MenstruationPeriodRecord
import androidx.health.connect.client.records.NutritionRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.RespiratoryRateRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateGroupByPeriodRequest
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import kotlin.coroutines.cancellation.CancellationException
import kotlin.reflect.KClass

/** One workout shown in the "Recent activity" list. */
data class ActivityItem(
    val title: String,
    val startMs: Long,
    val minutes: Int,
    val km: Double = 0.0,
    val kcal: Int = 0,
    val source: String = "",
    val route: Boolean = false
)

private fun exerciseName(type: Int): String = when (type) {
    ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Walking"
    ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "Running"
    ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Cycling"
    ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Hiking"
    ExerciseSessionRecord.EXERCISE_TYPE_YOGA -> "Yoga"
    ExerciseSessionRecord.EXERCISE_TYPE_PILATES -> "Pilates"
    ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "Strength training"
    ExerciseSessionRecord.EXERCISE_TYPE_HIGH_INTENSITY_INTERVAL_TRAINING -> "HIIT"
    ExerciseSessionRecord.EXERCISE_TYPE_DANCING -> "Dancing"
    ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL -> "Swimming"
    ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "Swimming"
    ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Elliptical"
    else -> "Workout"
}

data class DaySummary(
    val steps: Long = 0,
    val calories: Double = 0.0,
    val distanceKm: Double = 0.0,
    val lastHeartRate: Int = 0
)

/** Extra health data that watches / Google Fit / other apps sync into Health Connect. 0 = unknown. */
data class HealthExtras(
    val sleepMinutes: Int = 0,
    val deepMinutes: Int = 0,
    val remMinutes: Int = 0,
    val lightMinutes: Int = 0,
    val restingHr: Int = 0,
    val respRate: Double = 0.0,
    val spo2: Double = 0.0,
    val hrvMs: Double = 0.0,
    val bodyFatPct: Double = 0.0,
    val leanMassKg: Double = 0.0,
    val nutritionKcal: Double = 0.0,
    val proteinG: Double = 0.0,
    val carbsG: Double = 0.0,
    val fatG: Double = 0.0,
    val waterMl: Int = 0,
    val exerciseMinutes: Int = 0,
    val lastPeriodStart: LocalDate? = null
)

/**
 * Reads the data that Google Fit (and most Android fitness apps / watch apps) sync into
 * Health Connect. Google is retiring the old Google Fit Android API and Health Connect is
 * the official replacement, so this is the supported way to get Google Fit data.
 */
class HealthConnectManager(private val context: Context) {

    val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(LeanBodyMassRecord::class),
        HealthPermission.getReadPermission(NutritionRecord::class),
        HealthPermission.getReadPermission(HydrationRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(MenstruationPeriodRecord::class)
    )

    val sdkStatus: Int get() = HealthConnectClient.getSdkStatus(context)
    val isAvailable: Boolean get() = sdkStatus == HealthConnectClient.SDK_AVAILABLE

    private val client by lazy { HealthConnectClient.getOrCreate(context) }

    private suspend fun <T> safe(default: T, block: suspend () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            default
        }

    /** True when the user allowed at least the steps permission. */
    suspend fun hasStepsPermission(): Boolean =
        isAvailable && safe(false) {
            client.permissionController.getGrantedPermissions()
                .contains(HealthPermission.getReadPermission(StepsRecord::class))
        }

    suspend fun today(): DaySummary {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now().atStartOfDay(zone).toInstant()
        val now = Instant.now()
        val filter = TimeRangeFilter.between(start, now)

        val steps = safe(0L) {
            client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), filter))[StepsRecord.COUNT_TOTAL] ?: 0L
        }
        val meters = safe(0.0) {
            client.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL), filter))[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
        }
        val kcal = safe(0.0) {
            client.aggregate(AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), filter))[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
        }
        val hr = safe(0) {
            client.readRecords(
                ReadRecordsRequest(
                    recordType = HeartRateRecord::class,
                    timeRangeFilter = filter,
                    ascendingOrder = false,
                    pageSize = 1
                )
            ).records.firstOrNull()?.samples?.lastOrNull()?.beatsPerMinute?.toInt() ?: 0
        }

        return DaySummary(steps = steps, calories = kcal, distanceKm = meters / 1000.0, lastHeartRate = hr)
    }

    /** Steps for Monday..Sunday of the current week (0 for future days). */
    suspend fun weeklySteps(): List<Long> = safe(List(7) { 0L }) {
        val monday = LocalDate.now().with(DayOfWeek.MONDAY)
        val rows = client.aggregateGroupByPeriod(
            AggregateGroupByPeriodRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(
                    monday.atStartOfDay(),
                    monday.plusDays(7).atStartOfDay()
                ),
                timeRangeSlicer = Period.ofDays(1)
            )
        )
        val byDate = rows.associate { it.startTime.toLocalDate() to (it.result[StepsRecord.COUNT_TOTAL] ?: 0L) }
        (0..6).map { byDate[monday.plusDays(it.toLong())] ?: 0L }
    }

    /** Latest height (cm) and weight (kg) saved in Health Connect / Google Fit; 0 when unknown. */
    suspend fun bodyInfo(): Pair<Int, Int> {
        val height = safe(0) {
            val r = latest(HeightRecord::class, 3650)
            ((r?.height?.inMeters ?: 0.0) * 100).toInt()
        }
        val weight = safe(0) {
            val r = latest(WeightRecord::class, 3650)
            (r?.weight?.inKilograms ?: 0.0).toInt()
        }
        return height to weight
    }

    private suspend fun <T : Record> latest(type: KClass<T>, days: Long): T? =
        safe<T?>(null) {
            val now = Instant.now()
            client.readRecords(
                ReadRecordsRequest(
                    recordType = type,
                    timeRangeFilter = TimeRangeFilter.between(now.minus(Duration.ofDays(days)), now),
                    ascendingOrder = false,
                    pageSize = 1
                )
            ).records.firstOrNull()
        }

    /** Workouts recorded by your watch / other apps in the last 7 days. */
    suspend fun recentSessions(): List<ActivityItem> = safe(emptyList<ActivityItem>()) {
        val now = Instant.now()
        client.readRecords(
            ReadRecordsRequest(
                recordType = ExerciseSessionRecord::class,
                timeRangeFilter = TimeRangeFilter.between(now.minus(Duration.ofDays(7)), now),
                ascendingOrder = false,
                pageSize = 30
            )
        ).records.map { r ->
            val custom = r.title
            ActivityItem(
                title = if (!custom.isNullOrBlank()) custom else exerciseName(r.exerciseType),
                startMs = r.startTime.toEpochMilli(),
                minutes = Duration.between(r.startTime, r.endTime).toMinutes().toInt(),
                source = r.metadata.dataOrigin.packageName
            )
        }
    }

    /** Sleep, heart/respiratory, body composition, nutrition, exercise and cycle data. */
    suspend fun extras(): HealthExtras {
        val zone = ZoneId.systemDefault()
        val startOfDay = LocalDate.now().atStartOfDay(zone).toInstant()
        val now = Instant.now()
        val todayFilter = TimeRangeFilter.between(startOfDay, now)

        // ---- sleep (last ~36 hours) ----
        var sleepTotal = 0
        var deep = 0
        var rem = 0
        var light = 0
        safe(Unit) {
            val sessions = client.readRecords(
                ReadRecordsRequest(
                    recordType = SleepSessionRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(now.minus(Duration.ofHours(36)), now)
                )
            ).records
            val rec = sessions.maxByOrNull { Duration.between(it.startTime, it.endTime).toMinutes() }
            if (rec != null) {
                var d = 0L
                var r = 0L
                var l = 0L
                rec.stages.forEach { st ->
                    val m = Duration.between(st.startTime, st.endTime).toMinutes()
                    when (st.stage) {
                        SleepSessionRecord.STAGE_TYPE_DEEP -> d += m
                        SleepSessionRecord.STAGE_TYPE_REM -> r += m
                        SleepSessionRecord.STAGE_TYPE_LIGHT -> l += m
                        SleepSessionRecord.STAGE_TYPE_SLEEPING -> l += m
                    }
                }
                deep = d.toInt()
                rem = r.toInt()
                light = l.toInt()
                sleepTotal = if (rec.stages.isEmpty()) {
                    Duration.between(rec.startTime, rec.endTime).toMinutes().toInt()
                } else (d + r + l).toInt()
            }
            Unit
        }

        // ---- vitals ----
        val resting = safe(0) { latest(RestingHeartRateRecord::class, 7)?.beatsPerMinute?.toInt() ?: 0 }
        val resp = safe(0.0) { latest(RespiratoryRateRecord::class, 7)?.rate ?: 0.0 }
        val spo2 = safe(0.0) { latest(OxygenSaturationRecord::class, 7)?.percentage?.value ?: 0.0 }
        val hrv = safe(0.0) { latest(HeartRateVariabilityRmssdRecord::class, 7)?.heartRateVariabilityMillis ?: 0.0 }

        // ---- body composition ----
        val fat = safe(0.0) { latest(BodyFatRecord::class, 365)?.percentage?.value ?: 0.0 }
        val lean = safe(0.0) { latest(LeanBodyMassRecord::class, 365)?.mass?.inKilograms ?: 0.0 }

        // ---- nutrition today ----
        var kcal = 0.0
        var protein = 0.0
        var carbs = 0.0
        var fatG = 0.0
        safe(Unit) {
            client.readRecords(
                ReadRecordsRequest(recordType = NutritionRecord::class, timeRangeFilter = todayFilter)
            ).records.forEach {
                kcal += it.energy?.inKilocalories ?: 0.0
                protein += it.protein?.inGrams ?: 0.0
                carbs += it.totalCarbohydrate?.inGrams ?: 0.0
                fatG += it.totalFat?.inGrams ?: 0.0
            }
        }
        val water = safe(0.0) {
            client.readRecords(
                ReadRecordsRequest(recordType = HydrationRecord::class, timeRangeFilter = todayFilter)
            ).records.sumOf { it.volume.inLiters } * 1000.0
        }

        // ---- exercise minutes today ----
        val exercise = safe(0L) {
            client.readRecords(
                ReadRecordsRequest(recordType = ExerciseSessionRecord::class, timeRangeFilter = todayFilter)
            ).records.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
        }

        // ---- cycle ----
        val period = safe<LocalDate?>(null) {
            latest(MenstruationPeriodRecord::class, 120)?.startTime?.atZone(zone)?.toLocalDate()
        }

        return HealthExtras(
            sleepMinutes = sleepTotal,
            deepMinutes = deep,
            remMinutes = rem,
            lightMinutes = light,
            restingHr = resting,
            respRate = resp,
            spo2 = spo2,
            hrvMs = hrv,
            bodyFatPct = fat,
            leanMassKg = lean,
            nutritionKcal = kcal,
            proteinG = protein,
            carbsG = carbs,
            fatG = fatG,
            waterMl = water.toInt(),
            exerciseMinutes = exercise.toInt(),
            lastPeriodStart = period
        )
    }
}
