package com.fittofit.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeightRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateGroupByPeriodRequest
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import kotlin.coroutines.cancellation.CancellationException

data class DaySummary(
    val steps: Long = 0,
    val calories: Double = 0.0,
    val distanceKm: Double = 0.0,
    val lastHeartRate: Int = 0
)

/**
 * Reads the data that Google Fit (and most Android fitness apps / watch apps) sync into
 * Health Connect. Google is retiring the old Google Fit Android API and Health Connect is
 * the official replacement, so this is the supported way to get Google Fit data.
 */
class HealthConnectManager(private val context: Context) {

    val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class)
    )

    val sdkStatus: Int get() = HealthConnectClient.getSdkStatus(context)
    val isAvailable: Boolean get() = sdkStatus == HealthConnectClient.SDK_AVAILABLE

    private val client by lazy { HealthConnectClient.getOrCreate(context) }

    private suspend fun <T> safe(default: T, block: suspend () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            default
        }

    /** True when the user allowed at least the steps permission. */
    suspend fun hasStepsPermission(): Boolean =
        isAvailable && safe(false) {
            client.permissionController.getGrantedPermissions()
                .contains(HealthPermission.getReadPermission(StepsRecord::class))
        }

    suspend fun today(): DaySummary {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now().atStartOfDay(zone).toInstant()
        val now = Instant.now()
        val filter = TimeRangeFilter.between(start, now)

        val steps = safe(0L) {
            client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), filter))[StepsRecord.COUNT_TOTAL] ?: 0L
        }
        val meters = safe(0.0) {
            client.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL), filter))[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
        }
        val kcal = safe(0.0) {
            client.aggregate(AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), filter))[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
        }
        val hr = safe(0) {
            client.readRecords(
                ReadRecordsRequest(
                    recordType = HeartRateRecord::class,
                    timeRangeFilter = filter,
                    ascendingOrder = false,
                    pageSize = 1
                )
            ).records.firstOrNull()?.samples?.lastOrNull()?.beatsPerMinute?.toInt() ?: 0
        }

        return DaySummary(steps = steps, calories = kcal, distanceKm = meters / 1000.0, lastHeartRate = hr)
    }

    /** Steps for Monday..Sunday of the current week (0 for future days). */
    suspend fun weeklySteps(): List<Long> = safe(List(7) { 0L }) {
        val monday = LocalDate.now().with(DayOfWeek.MONDAY)
        val rows = client.aggregateGroupByPeriod(
            AggregateGroupByPeriodRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(
                    monday.atStartOfDay(),
                    monday.plusDays(7).atStartOfDay()
                ),
                timeRangeSlicer = Period.ofDays(1)
            )
        )
        val byDate = rows.associate { it.startTime.toLocalDate() to (it.result[StepsRecord.COUNT_TOTAL] ?: 0L) }
        (0..6).map { byDate[monday.plusDays(it.toLong())] ?: 0L }
    }

    /** Latest height (cm) and weight (kg) saved in Health Connect / Google Fit; 0 when unknown. */
    suspend fun bodyInfo(): Pair<Int, Int> {
        val height = safe(0) {
            val r = client.readRecords(
                ReadRecordsRequest(
                    recordType = HeightRecord::class,
                    timeRangeFilter = TimeRangeFilter.before(Instant.now()),
                    ascendingOrder = false,
                    pageSize = 1
                )
            ).records.firstOrNull()
            ((r?.height?.inMeters ?: 0.0) * 100).toInt()
        }
        val weight = safe(0) {
            val r = client.readRecords(
                ReadRecordsRequest(
                    recordType = WeightRecord::class,
                    timeRangeFilter = TimeRangeFilter.before(Instant.now()),
                    ascendingOrder = false,
                    pageSize = 1
                )
            ).records.firstOrNull()
            (r?.weight?.inKilograms ?: 0.0).toInt()
        }
        return height to weight
    }
}
