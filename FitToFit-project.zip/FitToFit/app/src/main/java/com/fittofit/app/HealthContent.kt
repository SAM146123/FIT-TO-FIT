package com.fittofit.app

/** Text in English and Tamil. Hindi users see English. */
class L(val en: String, val ta: String) {
    fun t(): String = if (Settings.lang == "ta") ta else en
}

class Condition(
    val id: String,
    val emoji: String,
    val title: L,
    val intro: L,
    val eat: List<L>,
    val nonVeg: List<L>,
    val avoid: List<L>,
    val meals: List<Pair<L, L>>,
    val lifestyle: List<L>,
    val home: List<L>
)

class FirstAid(val emoji: String, val title: L, val steps: List<L>, val hospital: L)

class HomeTip(val emoji: String, val title: L, val text: L)

object HealthContent {

    const val DISCLAIMER_EN = "This is general health information, not a medical diagnosis. Never stop or change your medicines without asking your doctor. If you feel very unwell, see a doctor."
    const val DISCLAIMER_TA = "இது பொதுவான ஆரோக்கியத் தகவல் மட்டுமே; மருத்துவ ஆலோசனை அல்ல. மருத்துவரைக் கேட்காமல் மருந்துகளை நிறுத்தவோ மாற்றவோ வேண்டாம். மிகவும் உடல்நிலை சரியில்லை என்றால் உடனே மருத்துவரைப் பாருங்கள்."
    val disclaimer: L get() = L(DISCLAIMER_EN, DISCLAIMER_TA)

    val emergency = L(
        "Emergency? Call your local emergency number now (India: 108 ambulance / 112).",
        "அவசரமா? உடனே அவசர எண்ணை அழையுங்கள் (இந்தியா: 108 ஆம்புலன்ஸ் / 112)."
    )

    fun has(p: Profile, id: String) = p.conditions.split(",").contains(id)

    fun toggle(p: Profile, id: String): Profile {
        val list = p.conditions.split(",").filter { it.isNotBlank() }.toMutableList()
        if (list.contains(id)) list.remove(id) else list.add(id)
        return p.copy(conditions = list.joinToString(","))
    }

    val conditions: List<Condition> = listOf(
        Condition(
            "diabetes", "🩸", L("Diabetes (sugar)", "நீரிழிவு (சர்க்கரை)"),
            L(
                "Goal: keep blood sugar steady. Choose slow-digesting foods, small portions and regular meal times.",
                "இலக்கு: இரத்தச் சர்க்கரையை சீராக வைத்திருப்பது. மெதுவாக செரிக்கும் உணவு, சிறிய அளவு, சரியான நேரத்தில் சாப்பாடு."
            ),
            eat = listOf(
                L("Millets (ragi, kambu, thinai, varagu) instead of polished white rice", "வெள்ளை அரிசிக்குப் பதிலாக சிறுதானியங்கள் (கேழ்வரகு, கம்பு, தினை, வரகு)"),
                L("Plenty of vegetables, keerai, bitter gourd, okra, beans", "நிறைய காய்கறிகள், கீரை, பாகற்காய், வெண்டைக்காய், பீன்ஸ்"),
                L("Dal, sprouts, roasted chana (protein + fibre)", "பருப்பு, முளைகட்டிய பயறு, வறுத்த கடலை (புரதம் + நார்ச்சத்து)"),
                L("Guava, apple, papaya, berries - one small portion at a time", "கொய்யா, ஆப்பிள், பப்பாளி, பெர்ரி - ஒரு நேரத்தில் சிறிய அளவு"),
                L("Fenugreek (methi) seeds soaked overnight, a handful of nuts", "இரவு ஊறவைத்த வெந்தயம், ஒரு கைப்பிடி கொட்டைகள்")
            ),
            nonVeg = listOf(L("Boiled egg, steamed or grilled fish / chicken (not fried)", "வேகவைத்த முட்டை, ஆவியில் வேகவைத்த / சுட்ட மீன் அல்லது கோழி (பொரிக்க வேண்டாம்)")),
            avoid = listOf(
                L("Sugar, sweets, cold drinks, packaged fruit juice", "சர்க்கரை, இனிப்புகள், குளிர்பானங்கள், பாக்கெட் பழச்சாறு"),
                L("Big portions of white rice, maida, parotta, bakery items", "அதிக வெள்ளை அரிசி, மைதா, பரோட்டா, பேக்கரி உணவுகள்"),
                L("Fried snacks and sweets made with jaggery or honey in large amounts", "பொரித்த தின்பண்டங்கள்; அதிக வெல்லம் / தேன் இனிப்புகள்"),
                L("Large amounts of banana, mango, grapes, jackfruit", "அதிக வாழைப்பழம், மாம்பழம், திராட்சை, பலாப்பழம்"),
                L("Skipping meals and then overeating", "சாப்பாட்டைத் தவிர்த்துவிட்டு பிறகு அதிகம் சாப்பிடுவது")
            ),
            meals = listOf(
                L("Early morning", "அதிகாலை") to L("Warm water with soaked methi seeds", "வெதுவெதுப்பான நீர் + ஊறவைத்த வெந்தயம்"),
                L("Breakfast", "காலை உணவு") to L("2 ragi dosa or idli with sambar and chutney, no sugar", "2 கேழ்வரகு தோசை / இட்லி + சாம்பார், சட்னி; சர்க்கரை இல்லாமல்"),
                L("Lunch", "மதிய உணவு") to L("1 cup rice or millet + big bowl of vegetables + dal + curd", "1 கப் சாதம் / சிறுதானியம் + பெரிய கிண்ணம் காய்கறி + பருப்பு + தயிர்"),
                L("Snack", "சிற்றுண்டி") to L("Sprouts salad, roasted chana or one guava", "முளைகட்டிய பயறு சாலட், வறுத்த கடலை அல்லது ஒரு கொய்யா"),
                L("Dinner", "இரவு உணவு") to L("2 chapati or millet dosa + vegetable curry. Light, 2-3 hours before sleep", "2 சப்பாத்தி / சிறுதானிய தோசை + காய்கறி கூட்டு. லேசாக, தூங்கும் 2-3 மணி நேரம் முன்")
            ),
            lifestyle = listOf(
                L("Walk 10-15 minutes after every meal", "ஒவ்வொரு சாப்பாட்டிற்குப் பிறகும் 10-15 நிமிடம் நடங்கள்"),
                L("Check sugar as your doctor advises. Check your feet daily for cuts", "மருத்துவர் சொன்னபடி சர்க்கரை பரிசோதியுங்கள். தினமும் பாதங்களில் புண் உள்ளதா எனப் பாருங்கள்"),
                L("Never stop tablets or insulin on your own. Home foods do not replace medicine", "மாத்திரை / இன்சுலினை நீங்களாக நிறுத்த வேண்டாம். வீட்டு உணவு மருந்துக்கு மாற்று அல்ல")
            ),
            home = emptyList()
        ),
        Condition(
            "tb", "🫁", L("TB (tuberculosis)", "காசநோய் (டிபி)"),
            L(
                "TB tablets must be taken every day for the full course. Food helps recovery but never replaces medicine. The body needs extra protein and energy.",
                "காசநோய் மாத்திரைகளை முழு காலமும் தினமும் சாப்பிட வேண்டும். உணவு குணமாக உதவும்; மருந்துக்கு மாற்று அல்ல. உடலுக்கு கூடுதல் புரதமும் சக்தியும் தேவை."
            ),
            eat = listOf(
                L("Milk, curd, paneer, buttermilk", "பால், தயிர், பனீர், மோர்"),
                L("Dal, pulses, sprouts, soya", "பருப்பு, பயறு வகைகள், முளைகட்டிய தானியம், சோயா"),
                L("Groundnuts, nuts, dates, a little jaggery", "நிலக்கடலை, கொட்டைகள், பேரீச்சை, சிறிது வெல்லம்"),
                L("Vitamin C fruits: orange, amla, guava, lemon", "வைட்டமின் C பழங்கள்: ஆரஞ்சு, நெல்லிக்காய், கொய்யா, எலுமிச்சை"),
                L("Green leafy vegetables, carrot, beetroot, ragi porridge", "கீரை, கேரட், பீட்ரூட், கேழ்வரகு கூழ்")
            ),
            nonVeg = listOf(L("Eggs, fish, chicken - good protein for recovery", "முட்டை, மீன், கோழி - குணமாக நல்ல புரதம்")),
            avoid = listOf(
                L("Smoking and alcohol - strictly avoid", "புகைப்பிடித்தல், மது - முற்றிலும் தவிர்க்கவும்"),
                L("Junk food and very oily snacks", "ஜங்க் உணவு, மிகவும் எண்ணெய் பலகாரங்கள்"),
                L("Skipping meals or staying hungry", "சாப்பாட்டைத் தவிர்ப்பது, பட்டினி")
            ),
            meals = listOf(
                L("Early morning", "அதிகாலை") to L("Warm milk or ragi malt", "வெதுவெதுப்பான பால் அல்லது கேழ்வரகு மால்ட்"),
                L("Breakfast", "காலை உணவு") to L("Idli / dosa / upma with dal or egg, plus a glass of milk", "இட்லி / தோசை / உப்புமா + பருப்பு அல்லது முட்டை + ஒரு டம்ளர் பால்"),
                L("Mid-morning", "முற்பகல்") to L("One fruit and a handful of nuts", "ஒரு பழம் + ஒரு கைப்பிடி கொட்டைகள்"),
                L("Lunch", "மதிய உணவு") to L("Rice + dal + 2 vegetables + curd (+ fish or chicken)", "சாதம் + பருப்பு + 2 காய்கறி + தயிர் (+ மீன் / கோழி)"),
                L("Evening", "மாலை") to L("Sundal or groundnut chikki + a fruit", "சுண்டல் அல்லது கடலை மிட்டாய் + ஒரு பழம்"),
                L("Dinner", "இரவு உணவு") to L("Chapati or dosa + dal / egg curry / vegetables", "சப்பாத்தி / தோசை + பருப்பு / முட்டை கறி / காய்கறி")
            ),
            lifestyle = listOf(
                L("Take every dose on time. Do not stop even when you feel better", "ஒவ்வொரு டோஸையும் நேரத்தில் எடுங்கள். நன்றாக உணர்ந்தாலும் நிறுத்தாதீர்கள்"),
                L("15 minutes of morning sunlight; keep rooms airy", "காலை வெயிலில் 15 நிமிடம்; அறையில் காற்றோட்டம்"),
                L("Cover your mouth when coughing. Only light walking until your doctor allows more", "இருமும்போது வாயை மூடுங்கள். மருத்துவர் அனுமதிக்கும் வரை லேசான நடை மட்டும்")
            ),
            home = emptyList()
        ),
        Condition(
            "bp", "❤️", L("High BP", "உயர் இரத்த அழுத்தம் (BP)"),
            L(
                "Goal: less salt and more potassium. Keep total salt under 1 teaspoon (5 g) a day, including pickles and packed food.",
                "இலக்கு: உப்பு குறைவு, பொட்டாசியம் அதிகம். ஊறுகாய், பாக்கெட் உணவு உட்பட மொத்த உப்பு நாளுக்கு 1 தேக்கரண்டிக்குள் (5 கிராம்)."
            ),
            eat = listOf(
                L("Banana, tender coconut water, tomato, spinach (potassium)", "வாழைப்பழம், இளநீர், தக்காளி, கீரை (பொட்டாசியம்)"),
                L("5 portions of fruit and vegetables every day", "தினமும் 5 அளவு பழம் மற்றும் காய்கறி"),
                L("Oats, millets, whole grains", "ஓட்ஸ், சிறுதானியம், முழு தானியம்"),
                L("Garlic, onion, beetroot", "பூண்டு, வெங்காயம், பீட்ரூட்"),
                L("Unsalted buttermilk, a handful of unsalted nuts", "உப்பில்லாத மோர், உப்பு சேர்க்காத கொட்டைகள் ஒரு கைப்பிடி")
            ),
            nonVeg = listOf(L("Steamed or grilled fish 2 times a week (not salted or dry fish)", "வாரம் 2 முறை ஆவியில் வேகவைத்த / சுட்ட மீன் (கருவாடு, உப்பு மீன் வேண்டாம்)")),
            avoid = listOf(
                L("Pickles, papad, dry fish, chips, instant noodles, sauces", "ஊறுகாய், அப்பளம், கருவாடு, சிப்ஸ், இன்ஸ்டன்ட் நூடுல்ஸ், சாஸ்"),
                L("Extra salt on the plate", "தட்டில் கூடுதல் உப்பு"),
                L("Fast food and processed meat", "பாஸ்ட் புட், பதப்படுத்திய இறைச்சி"),
                L("Too much tea / coffee, alcohol, smoking", "அதிக டீ / காபி, மது, புகை")
            ),
            meals = listOf(
                L("Breakfast", "காலை உணவு") to L("Oats or ragi porridge with fruit, or idli with low-salt sambar", "ஓட்ஸ் / கேழ்வரகு கஞ்சி + பழம், அல்லது குறைந்த உப்பு சாம்பாருடன் இட்லி"),
                L("Mid-morning", "முற்பகல்") to L("Tender coconut water or a banana", "இளநீர் அல்லது ஒரு வாழைப்பழம்"),
                L("Lunch", "மதிய உணவு") to L("Rice / millet + keerai + vegetable + dal, little salt, unsalted buttermilk", "சாதம் / சிறுதானியம் + கீரை + காய்கறி + பருப்பு, குறைந்த உப்பு, உப்பில்லா மோர்"),
                L("Snack", "சிற்றுண்டி") to L("Fruit or unsalted roasted nuts", "பழம் அல்லது உப்பில்லாத வறுத்த கொட்டைகள்"),
                L("Dinner", "இரவு உணவு") to L("2 chapati + vegetable curry + salad", "2 சப்பாத்தி + காய்கறி கறி + சாலட்")
            ),
            lifestyle = listOf(
                L("Walk 30 minutes on most days. Slow deep breathing for 5 minutes", "பெரும்பாலான நாட்கள் 30 நிமிடம் நடை. 5 நிமிடம் மெதுவான ஆழ்ந்த சுவாசம்"),
                L("Check your BP regularly. Sleep 7 hours", "BP-ஐ அடிக்கடி பரிசோதியுங்கள். 7 மணி நேரம் தூக்கம்"),
                L("Never stop BP tablets suddenly", "BP மாத்திரைகளை திடீரென நிறுத்த வேண்டாம்")
            ),
            home = emptyList()
        ),
        Condition(
            "cholesterol", "🧈", L("High cholesterol", "கொலஸ்ட்ரால்"),
            L(
                "Goal: more fibre and healthy fats, less fried and fatty food.",
                "இலக்கு: நார்ச்சத்து, நல்ல கொழுப்பு அதிகம்; பொரித்த, கொழுப்பு உணவு குறைவு."
            ),
            eat = listOf(
                L("Oats, ragi, barley, whole grains", "ஓட்ஸ், கேழ்வரகு, பார்லி, முழு தானியம்"),
                L("Beans, dal, chana, sprouts", "அவரை, பருப்பு, கொண்டைக்கடலை, முளைகட்டிய பயறு"),
                L("Almonds, walnuts, flax seeds", "பாதாம், வால்நட், ஆளி விதை"),
                L("Garlic, onion, methi; apple, guava, orange, papaya", "பூண்டு, வெங்காயம், வெந்தயம்; ஆப்பிள், கொய்யா, ஆரஞ்சு, பப்பாளி"),
                L("Lots of vegetables and salad", "நிறைய காய்கறி, சாலட்")
            ),
            nonVeg = listOf(L("Fatty fish (sardine, mackerel) steamed or grilled 2 times a week", "கொழுப்பு மீன் (மத்தி, அயிலை) வாரம் 2 முறை ஆவியில் / சுட்டு")),
            avoid = listOf(
                L("Fried food: vada, bajji, samosa, chips", "பொரித்த உணவு: வடை, பஜ்ஜி, சமோசா, சிப்ஸ்"),
                L("Ghee, butter, vanaspati, palm oil", "நெய், வெண்ணெய், வனஸ்பதி, பாமாயில்"),
                L("Bakery biscuits, cakes, cream sweets", "பேக்கரி பிஸ்கட், கேக், கிரீம் இனிப்புகள்"),
                L("Fatty red meat, organ meat; too much coconut", "கொழுப்பு இறைச்சி, ஈரல் போன்றவை; அதிக தேங்காய்")
            ),
            meals = listOf(
                L("Breakfast", "காலை உணவு") to L("Oats upma / ragi dosa / idli with vegetable sambar", "ஓட்ஸ் உப்புமா / கேழ்வரகு தோசை / காய்கறி சாம்பாருடன் இட்லி"),
                L("Mid-morning", "முற்பகல்") to L("An apple or guava + 5 almonds", "ஒரு ஆப்பிள் அல்லது கொய்யா + 5 பாதாம்"),
                L("Lunch", "மதிய உணவு") to L("Half plate vegetables and salad, 1 cup rice or millet, dal", "தட்டில் பாதி காய்கறி, சாலட்; 1 கப் சாதம் / சிறுதானியம்; பருப்பு"),
                L("Snack", "சிற்றுண்டி") to L("Sundal or roasted chana, green tea", "சுண்டல் அல்லது வறுத்த கடலை, க்ரீன் டீ"),
                L("Dinner", "இரவு உணவு") to L("2 chapati + vegetable curry, no fried side dish", "2 சப்பாத்தி + காய்கறி கறி; பொரியல் வேண்டாம்")
            ),
            lifestyle = listOf(
                L("Walk 30-45 minutes daily", "தினமும் 30-45 நிமிடம் நடை"),
                L("Use little oil; steam, boil or grill instead of frying", "குறைந்த எண்ணெய்; பொரிப்பதற்குப் பதில் ஆவி, வேகவை, சுடுதல்"),
                L("Get a lipid profile blood test as your doctor advises", "மருத்துவர் சொன்னபடி லிப்பிட் இரத்தப் பரிசோதனை செய்யுங்கள்")
            ),
            home = emptyList()
        ),
        Condition(
            "thyroid", "🦋", L("Thyroid", "தைராய்டு"),
            L(
                "Most common is an underactive thyroid. Take your thyroid tablet on an empty stomach with water, 30-60 minutes before food, exactly as your doctor said. Keep a 4-hour gap from calcium and iron tablets.",
                "பொதுவாக தைராய்டு குறைவாகச் சுரக்கும் (Hypothyroid). தைராய்டு மாத்திரையை வெறும் வயிற்றில், சாப்பாட்டிற்கு 30-60 நிமிடம் முன், மருத்துவர் சொன்னபடி சாப்பிடுங்கள். கால்சியம், இரும்பு மாத்திரைகளுக்கு 4 மணி நேர இடைவெளி விடுங்கள்."
            ),
            eat = listOf(
                L("Iodised salt in small amount", "அயோடின் உப்பு சிறிய அளவில்"),
                L("Selenium and zinc: sunflower and pumpkin seeds, chickpeas, curd", "செலினியம், ஜிங்க்: சூரியகாந்தி, பூசணி விதை, கொண்டைக்கடலை, தயிர்"),
                L("Fruits and vegetables, whole grains for fibre", "பழம், காய்கறி, நார்ச்சத்துக்கு முழு தானியம்"),
                L("Enough protein: dal, milk, sprouts", "போதுமான புரதம்: பருப்பு, பால், முளைகட்டிய பயறு")
            ),
            nonVeg = listOf(L("Eggs and fish are good for selenium and iodine", "முட்டை, மீன் - செலினியம், அயோடினுக்கு நல்லது")),
            avoid = listOf(
                L("Large amounts of raw cabbage, cauliflower, broccoli, knol-khol (cooked is fine)", "பச்சை முட்டைகோஸ், காலிஃபிளவர், புரோக்கோலி, நூல்கோல் அதிகம் வேண்டாம் (வேகவைத்தால் பரவாயில்லை)"),
                L("Too much soya products", "அதிக சோயா பொருட்கள்"),
                L("Junk food, crash diets", "ஜங்க் உணவு, கடுமையான டயட்")
            ),
            meals = listOf(
                L("Early morning", "அதிகாலை") to L("Thyroid tablet with water, then wait 30-60 minutes", "தைராய்டு மாத்திரை + தண்ணீர்; பிறகு 30-60 நிமிடம் காத்திருக்கவும்"),
                L("Breakfast", "காலை உணவு") to L("Idli / dosa / upma with dal, or eggs", "இட்லி / தோசை / உப்புமா + பருப்பு, அல்லது முட்டை"),
                L("Lunch", "மதிய உணவு") to L("Rice or millet + dal + cooked vegetables + curd", "சாதம் / சிறுதானியம் + பருப்பு + வேகவைத்த காய்கறி + தயிர்"),
                L("Snack", "சிற்றுண்டி") to L("Fruit and sunflower seeds", "பழம் + சூரியகாந்தி விதை"),
                L("Dinner", "இரவு உணவு") to L("Chapati + vegetable curry + dal", "சப்பாத்தி + காய்கறி கறி + பருப்பு")
            ),
            lifestyle = listOf(
                L("Walk or exercise 30 minutes most days - it helps weight and energy", "பெரும்பாலான நாட்கள் 30 நிமிடம் நடை / உடற்பயிற்சி - எடை, சக்திக்கு உதவும்"),
                L("Do the TSH test when your doctor asks", "மருத்துவர் சொல்லும்போது TSH பரிசோதனை செய்யுங்கள்"),
                L("If you have an overactive thyroid, your diet differs - follow your doctor", "தைராய்டு அதிகமாக இருந்தால் உணவு வேறு - மருத்துவர் சொல்வதைப் பின்பற்றுங்கள்")
            ),
            home = emptyList()
        ),
        Condition(
            "joint", "🦴", L("Joint / knee pain", "மூட்டு வலி"),
            L(
                "Goal: calcium, vitamin D and omega-3, less inflammation, and a healthy weight. Every 1 kg you lose takes about 4 kg of load off your knees.",
                "இலக்கு: கால்சியம், வைட்டமின் D, ஒமேகா-3; வீக்கம் குறைவு; ஆரோக்கிய எடை. 1 கிலோ எடை குறைந்தால் முழங்காலுக்கு சுமார் 4 கிலோ சுமை குறையும்."
            ),
            eat = listOf(
                L("Turmeric in food or turmeric milk with a pinch of pepper", "உணவில் மஞ்சள் அல்லது சிறிது மிளகுடன் மஞ்சள் பால்"),
                L("Ginger and garlic", "இஞ்சி, பூண்டு"),
                L("Ragi, milk, curd, sesame (calcium)", "கேழ்வரகு, பால், தயிர், எள் (கால்சியம்)"),
                L("Walnuts and flax seeds (omega-3)", "வால்நட், ஆளி விதை (ஒமேகா-3)"),
                L("Vitamin C fruits and green leafy vegetables", "வைட்டமின் C பழங்கள், கீரை வகைகள்")
            ),
            nonVeg = listOf(L("Fatty fish like sardine or mackerel 2 times a week", "மத்தி, அயிலை போன்ற கொழுப்பு மீன் வாரம் 2 முறை")),
            avoid = listOf(
                L("Sugar, sweets, soft drinks", "சர்க்கரை, இனிப்பு, குளிர்பானம்"),
                L("Fried and processed food", "பொரித்த, பதப்படுத்திய உணவு"),
                L("Too much salt and too much red meat", "அதிக உப்பு, அதிக சிவப்பு இறைச்சி"),
                L("Being overweight", "அதிக உடல் எடை")
            ),
            meals = listOf(
                L("Early morning", "அதிகாலை") to L("10-15 minutes of morning sunlight (vitamin D)", "10-15 நிமிடம் காலை வெயில் (வைட்டமின் D)"),
                L("Breakfast", "காலை உணவு") to L("Ragi dosa or porridge + a glass of milk", "கேழ்வரகு தோசை / கூழ் + ஒரு டம்ளர் பால்"),
                L("Lunch", "மதிய உணவு") to L("Rice + keerai + dal + vegetable + curd", "சாதம் + கீரை + பருப்பு + காய்கறி + தயிர்"),
                L("Snack", "சிற்றுண்டி") to L("Walnuts or sesame ladoo (small)", "வால்நட் அல்லது எள் உருண்டை (சிறியது)"),
                L("Bedtime", "படுக்கும் முன்") to L("Warm turmeric milk", "வெதுவெதுப்பான மஞ்சள் பால்")
            ),
            lifestyle = listOf(
                L("Gentle walking, swimming, cycling are best. Avoid deep squats and lunges if your knee hurts. Glute Bridges are knee-friendly", "மெதுவான நடை, நீச்சல், சைக்கிள் சிறந்தவை. முழங்கால் வலித்தால் ஆழமான squat, lunge வேண்டாம். Glute Bridge முழங்காலுக்கு நல்லது"),
                L("Warm compress for stiffness; cold pack (wrapped, 15 minutes) for fresh swelling", "விறைப்புக்கு சூடான ஒத்தடம்; புதிய வீக்கத்துக்கு குளிர் ஒத்தடம் (துணியில் சுற்றி, 15 நிமிடம்)"),
                L("Sudden swelling, redness, fever or you cannot walk: see a doctor", "திடீர் வீக்கம், சிவப்பு, காய்ச்சல் அல்லது நடக்க முடியவில்லை: மருத்துவரைப் பாருங்கள்")
            ),
            home = listOf(
                L("Gentle massage with slightly warm sesame (gingelly) oil, then a warm bath", "சிறிது சூடான நல்லெண்ணெயில் மெதுவாக மசாஜ், பிறகு வெந்நீர் குளியல்"),
                L("Warm water with dry ginger (sukku) in the morning", "காலையில் சுக்கு போட்ட வெதுவெதுப்பான நீர்")
            )
        ),
        Condition(
            "hair", "💇", L("Hair loss", "முடி உதிர்தல்"),
            L(
                "Hair needs protein, iron, zinc and vitamins. Crash diets and stress make hair fall worse.",
                "முடிக்கு புரதம், இரும்பு, ஜிங்க், வைட்டமின்கள் தேவை. கடுமையான டயட்டும் மன அழுத்தமும் முடி உதிர்வை அதிகரிக்கும்."
            ),
            eat = listOf(
                L("Protein at every meal: dal, sprouts, milk, curd, paneer", "ஒவ்வொரு வேளையும் புரதம்: பருப்பு, முளைகட்டிய பயறு, பால், தயிர், பனீர்"),
                L("Iron: keerai, beetroot, dates, pomegranate, a little jaggery", "இரும்பு: கீரை, பீட்ரூட், பேரீச்சை, மாதுளை, சிறிது வெல்லம்"),
                L("Curry leaves and amla (vitamin C)", "கறிவேப்பிலை, நெல்லிக்காய் (வைட்டமின் C)"),
                L("Nuts and seeds: almonds, walnuts, flax, pumpkin seeds", "கொட்டைகள், விதைகள்: பாதாம், வால்நட், ஆளி, பூசணி விதை")
            ),
            nonVeg = listOf(L("Eggs and fish (protein, biotin, omega-3)", "முட்டை, மீன் (புரதம், பயோட்டின், ஒமேகா-3)")),
            avoid = listOf(
                L("Crash diets and skipping meals", "கடுமையான டயட், சாப்பாட்டைத் தவிர்ப்பது"),
                L("Too much sugar and junk food", "அதிக சர்க்கரை, ஜங்க் உணவு"),
                L("Smoking, very hot water on the scalp, tight hairstyles", "புகை, தலையில் மிக சூடான நீர், இறுக்கமான கொண்டை")
            ),
            meals = listOf(
                L("Breakfast", "காலை உணவு") to L("Egg or dal dosa, a glass of milk, a fruit", "முட்டை அல்லது பருப்பு தோசை, ஒரு டம்ளர் பால், ஒரு பழம்"),
                L("Lunch", "மதிய உணவு") to L("Rice + keerai + dal + vegetable + curd", "சாதம் + கீரை + பருப்பு + காய்கறி + தயிர்"),
                L("Snack", "சிற்றுண்டி") to L("Dates and a handful of nuts, or amla", "பேரீச்சை + ஒரு கைப்பிடி கொட்டைகள், அல்லது நெல்லிக்காய்"),
                L("Dinner", "இரவு உணவு") to L("Chapati + dal + beetroot or carrot curry", "சப்பாத்தி + பருப்பு + பீட்ரூட் / கேரட் கறி")
            ),
            lifestyle = listOf(
                L("Sleep 7-8 hours; manage stress with walks and slow breathing", "7-8 மணி நேரம் தூக்கம்; நடை, ஆழ்ந்த சுவாசத்தால் மன அழுத்தம் குறைக்கவும்"),
                L("Sudden heavy hair fall or bald patches: see a doctor (thyroid, anaemia, vitamin D checks)", "திடீர் அதிக முடி உதிர்வு அல்லது வழுக்கைத் திட்டுகள்: மருத்துவரைப் பாருங்கள் (தைராய்டு, இரத்தசோகை, வைட்டமின் D பரிசோதனை)")
            ),
            home = listOf(
                L("Warm coconut oil with a few curry leaves; massage the scalp gently for 5 minutes; wash after 1 hour", "சிறிது கறிவேப்பிலை போட்ட வெதுவெதுப்பான தேங்காய் எண்ணெய்; 5 நிமிடம் மெதுவாக மசாஜ்; 1 மணி நேரம் கழித்து அலசவும்"),
                L("Fenugreek (methi) seeds soaked overnight, ground to paste, on the scalp for 30 minutes, then wash", "இரவு ஊறவைத்த வெந்தயத்தை அரைத்து தலையில் 30 நிமிடம் தடவி அலசவும்"),
                L("Fresh aloe vera gel on the scalp for 30 minutes, then wash", "புதிய கற்றாழை ஜெல்லை தலையில் 30 நிமிடம் தடவி அலசவும்"),
                L("Safety: do a patch test first - dab a little on your inner forearm and wait 24 hours. Stop if there is itching or redness. Keep everything away from your eyes. Onion juice can irritate, so test it first", "பாதுகாப்பு: முதலில் patch test - உள் கையில் சிறிது தடவி 24 மணி நேரம் பாருங்கள். அரிப்பு, சிவப்பு வந்தால் நிறுத்துங்கள். கண்ணில் படாமல் பார்த்துக்கொள்ளுங்கள். வெங்காயச் சாறு எரிச்சல் தரலாம்; முதலில் சோதியுங்கள்")
            )
        ),
        Condition(
            "skin", "✨", L("Skin care", "சரும பராமரிப்பு"),
            L(
                "Healthy skin comes from water, good food, sleep and sun protection.",
                "ஆரோக்கிய சருமம் தண்ணீர், நல்ல உணவு, தூக்கம், வெயில் பாதுகாப்பால் கிடைக்கும்."
            ),
            eat = listOf(
                L("2-3 litres of water every day", "தினமும் 2-3 லிட்டர் தண்ணீர்"),
                L("Papaya, orange, watermelon, tomato, carrot", "பப்பாளி, ஆரஞ்சு, தர்பூசணி, தக்காளி, கேரட்"),
                L("Nuts and seeds (vitamin E), curd or buttermilk", "கொட்டைகள், விதைகள் (வைட்டமின் E), தயிர் அல்லது மோர்")
            ),
            nonVeg = listOf(L("Fish (omega-3) 2 times a week", "மீன் (ஒமேகா-3) வாரம் 2 முறை")),
            avoid = listOf(
                L("Too much sugar, fried and junk food", "அதிக சர்க்கரை, பொரித்த, ஜங்க் உணவு"),
                L("Smoking and alcohol", "புகை, மது"),
                L("Harsh soaps, picking pimples, staying long in strong sun", "கடுமையான சோப்பு, பருவைக் கிள்ளுவது, கடும் வெயிலில் நீண்ட நேரம்")
            ),
            meals = listOf(
                L("Morning", "காலை") to L("Warm water, then a fruit", "வெதுவெதுப்பான நீர், பிறகு ஒரு பழம்"),
                L("Lunch", "மதிய உணவு") to L("Colourful vegetables, dal, curd", "பல வண்ண காய்கறிகள், பருப்பு, தயிர்"),
                L("Snack", "சிற்றுண்டி") to L("Cucumber, carrot sticks or papaya", "வெள்ளரி, கேரட் அல்லது பப்பாளி")
            ),
            lifestyle = listOf(
                L("Use sunscreen SPF 30 or a cap / umbrella in strong sun", "கடும் வெயிலில் SPF 30 சன்ஸ்கிரீன் அல்லது தொப்பி / குடை"),
                L("Wash your face twice a day with a mild cleanser; sleep 7-8 hours", "முகத்தை நாளுக்கு 2 முறை மென்மையான கிளென்சரால் கழுவுங்கள்; 7-8 மணி நேரம் தூக்கம்"),
                L("Long-lasting acne, rash, or a mole that changes: see a skin doctor", "நீண்ட நாள் பரு, தடிப்பு அல்லது மாறும் மச்சம்: தோல் மருத்துவரைப் பாருங்கள்")
            ),
            home = listOf(
                L("Fresh aloe vera gel: soothing for dry or sun-tired skin", "புதிய கற்றாழை ஜெல்: வறண்ட / வெயிலால் சோர்ந்த சருமத்துக்கு இதமானது"),
                L("Honey face pack for 10 minutes, then wash with cool water", "தேன் முகப்பூச்சு 10 நிமிடம், பிறகு குளிர்ந்த நீரில் கழுவுங்கள்"),
                L("Cucumber slices or juice: cooling for tired skin", "வெள்ளரி துண்டு / சாறு: சோர்ந்த சருமத்துக்கு குளிர்ச்சி"),
                L("Oily skin: multani mitti with rose water for 10 minutes, only 1-2 times a week", "எண்ணெய் சருமம்: முல்தானி மிட்டி + பன்னீர் 10 நிமிடம், வாரம் 1-2 முறை மட்டும்"),
                L("Dry body skin: a little coconut oil after bath", "வறண்ட சருமம்: குளித்த பின் சிறிது தேங்காய் எண்ணெய்"),
                L("Do NOT put lemon juice or toothpaste on skin - they can burn or darken it. Always patch test on your inner forearm for 24 hours and stop if you see redness or itching", "எலுமிச்சைச் சாறு, பற்பசையை சருமத்தில் தடவாதீர்கள் - எரிச்சல், கருமை வரலாம். எப்போதும் உள் கையில் 24 மணி நேரம் patch test செய்யுங்கள்; சிவப்பு, அரிப்பு வந்தால் நிறுத்துங்கள்")
            )
        ),
        Condition(
            "eye", "👁️", L("Eye care", "கண் பராமரிப்பு"),
            L(
                "Vitamin A, vitamin C and omega-3 protect the eyes. Screens tire the eyes, so give them breaks.",
                "வைட்டமின் A, C, ஒமேகா-3 கண்ணைப் பாதுகாக்கும். திரை பார்ப்பது கண்ணை சோர்வடையச் செய்யும்; இடைவெளி கொடுங்கள்."
            ),
            eat = listOf(
                L("Carrot, papaya, mango, pumpkin (vitamin A)", "கேரட், பப்பாளி, மாம்பழம், பூசணி (வைட்டமின் A)"),
                L("Keerai and drumstick leaves (lutein)", "கீரை, முருங்கை இலை (லூட்டின்)"),
                L("Orange, amla, guava (vitamin C)", "ஆரஞ்சு, நெல்லிக்காய், கொய்யா (வைட்டமின் C)"),
                L("Almonds, walnuts, plenty of water", "பாதாம், வால்நட், நிறைய தண்ணீர்")
            ),
            nonVeg = listOf(L("Eggs and fish", "முட்டை, மீன்")),
            avoid = listOf(
                L("Smoking", "புகைப்பிடித்தல்"),
                L("Looking at a screen for hours without a break", "இடைவெளி இல்லாமல் மணிக்கணக்கில் திரை"),
                L("Rubbing your eyes with dirty hands; too little sleep", "அழுக்குக் கையால் கண்ணைத் தேய்ப்பது; குறைவான தூக்கம்")
            ),
            meals = listOf(
                L("Breakfast", "காலை உணவு") to L("Papaya or orange + milk / egg", "பப்பாளி / ஆரஞ்சு + பால் / முட்டை"),
                L("Lunch", "மதிய உணவு") to L("Keerai + carrot + dal + rice", "கீரை + கேரட் + பருப்பு + சாதம்"),
                L("Snack", "சிற்றுண்டி") to L("Carrot sticks and almonds", "கேரட் துண்டுகள் + பாதாம்")
            ),
            lifestyle = listOf(
                L("20-20-20 rule: every 20 minutes look at something 20 feet away for 20 seconds. Blink often", "20-20-20 விதி: ஒவ்வொரு 20 நிமிடத்துக்கும் 20 அடி தூரப் பொருளை 20 வினாடி பாருங்கள். அடிக்கடி இமையுங்கள்"),
                L("Wear UV sunglasses outside. Get your eyes checked once a year (people with diabetes must)", "வெளியே UV கண்ணாடி அணியுங்கள். வருடம் ஒரு முறை கண் பரிசோதனை (நீரிழிவு உள்ளவர்கள் கட்டாயம்)"),
                L("Sudden vision loss, strong eye pain or flashes of light: go to a doctor at once", "திடீர் பார்வை இழப்பு, கடும் கண் வலி, ஒளிக்கீற்று: உடனே மருத்துவரிடம் செல்லுங்கள்")
            ),
            home = listOf(
                L("Rinse closed eyes gently with clean cool water", "மூடிய கண்களை சுத்தமான குளிர்ந்த நீரால் மெதுவாகக் கழுவுங்கள்"),
                L("Clean, cold cucumber slices or a clean cold cloth on closed eyes for 10 minutes", "சுத்தமான குளிர்ந்த வெள்ளரித் துண்டுகள் / குளிர்ந்த துணியை மூடிய கண்ணில் 10 நிமிடம் வையுங்கள்"),
                L("Palming: rub your hands warm and rest them over closed eyes for 1 minute", "Palming: கைகளைத் தேய்த்து சூடாக்கி, மூடிய கண்கள் மேல் 1 நிமிடம் வையுங்கள்"),
                L("Do NOT put lemon, honey, oil or any home drops inside your eyes", "எலுமிச்சை, தேன், எண்ணெய் அல்லது எந்த வீட்டு சொட்டு மருந்தையும் கண்ணுக்குள் விடாதீர்கள்")
            )
        )
    )

    val firstAid: List<FirstAid> = listOf(
        FirstAid(
            "🔥", L("Burns", "தீக்காயம்"),
            listOf(
                L("Hold the burn under cool running tap water for 10-20 minutes", "காயத்தை குளிர்ந்த ஓடும் நீரில் 10-20 நிமிடம் காட்டுங்கள்"),
                L("Take off rings, watches and tight clothes before it swells", "வீங்கும் முன் மோதிரம், கடிகாரம், இறுக்கமான துணியை அகற்றுங்கள்"),
                L("Cover loosely with a clean, non-fluffy cloth or cling film", "சுத்தமான துணி அல்லது cling film-ஆல் தளர்வாக மூடுங்கள்"),
                L("Do NOT apply toothpaste, butter, oil or ice. Do not burst blisters", "பற்பசை, வெண்ணெய், எண்ணெய், ஐஸ் வேண்டாம். கொப்புளத்தை உடைக்காதீர்கள்")
            ),
            L("Go to hospital if the burn is large, deep, on the face, hands or genitals, or in a child.", "காயம் பெரியது, ஆழமானது, முகம் / கை மீது அல்லது குழந்தைக்கு என்றால் மருத்துவமனைக்குச் செல்லுங்கள்.")
        ),
        FirstAid(
            "🩹", L("Cuts and bleeding", "வெட்டு, இரத்தக் கசிவு"),
            listOf(
                L("Wash your hands. Press firmly on the cut with a clean cloth for 10 minutes without lifting", "கையைக் கழுவுங்கள். சுத்தமான துணியால் 10 நிமிடம் எடுக்காமல் அழுத்திப் பிடியுங்கள்"),
                L("Raise the injured part above the heart if you can", "முடிந்தால் காயமான பகுதியை இதயத்தை விட உயரத்தில் வையுங்கள்"),
                L("When bleeding stops, rinse with clean running water and cover with a clean bandage", "இரத்தம் நின்றதும் சுத்தமான ஓடும் நீரில் கழுவி, சுத்தமான கட்டுப் போடுங்கள்")
            ),
            L("Go to hospital if bleeding does not stop after 10 minutes, the cut is deep, or it has dirt or a rusty object in it.", "10 நிமிடத்தில் இரத்தம் நிற்கவில்லை, வெட்டு ஆழம், அழுக்கு / துருப்பிடித்த பொருள் இருந்தால் மருத்துவமனைக்குச் செல்லுங்கள்.")
        ),
        FirstAid(
            "👃", L("Nosebleed", "மூக்கில் இரத்தம்"),
            listOf(
                L("Sit down and lean FORWARD (not back)", "உட்கார்ந்து முன்னோக்கி சாயுங்கள் (பின்னால் அல்ல)"),
                L("Pinch the soft part of the nose for 10 minutes and breathe through your mouth", "மூக்கின் மென்மையான பகுதியை 10 நிமிடம் அழுத்திப் பிடித்து, வாயால் சுவாசியுங்கள்"),
                L("A cold cloth on the nose can help", "மூக்கில் குளிர்ந்த துணி வைக்கலாம்")
            ),
            L("Go to hospital if it lasts more than 20 minutes or follows a head injury.", "20 நிமிடத்துக்கு மேல் நீடித்தால் அல்லது தலையில் அடிபட்ட பின் என்றால் மருத்துவமனை செல்லுங்கள்.")
        ),
        FirstAid(
            "😮‍💨", L("Choking (adult)", "தொண்டையில் அடைப்பு (பெரியவர்)"),
            listOf(
                L("Ask: Can you cough? If they can cough or speak, encourage them to keep coughing", "கேளுங்கள்: இருமமுடிகிறதா? இருமினால் தொடர்ந்து இருமச் சொல்லுங்கள்"),
                L("If they cannot, give 5 firm back blows between the shoulder blades", "இருமமுடியாவிட்டால் தோள்பட்டைகளுக்கு நடுவே 5 முறை பலமாகத் தட்டுங்கள்"),
                L("Then 5 abdominal thrusts: stand behind, fist above the belly button, pull in and up sharply", "பிறகு 5 முறை வயிற்று அழுத்தம்: பின்னால் நின்று, தொப்புளுக்கு மேல் கை முஷ்டி வைத்து உள்ளும் மேலும் வேகமாக இழுங்கள்"),
                L("Repeat 5 and 5 and call emergency help", "5 தட்டு + 5 அழுத்தம் மீண்டும் செய்து, அவசர உதவிக்கு அழையுங்கள்")
            ),
            L("Call emergency help at once. If the person becomes unresponsive, start CPR.", "உடனே அவசர உதவிக்கு அழையுங்கள். பதில் இல்லாமல் போனால் CPR தொடங்குங்கள்.")
        ),
        FirstAid(
            "😵", L("Fainting", "மயக்கம்"),
            listOf(
                L("Lay the person flat and raise their legs about 30 cm", "படுக்க வைத்து கால்களை சுமார் 30 செ.மீ உயர்த்துங்கள்"),
                L("Loosen tight clothes and give fresh air", "இறுக்கமான உடையைத் தளர்த்தி, காற்றோட்டம் தாருங்கள்"),
                L("Give water only after they are fully awake", "முழு நினைவு வந்த பிறகே தண்ணீர் கொடுங்கள்")
            ),
            L("If they do not wake up within 1 minute, or are not breathing, call emergency help.", "1 நிமிடத்தில் நினைவு வராவிட்டால் அல்லது சுவாசம் இல்லையென்றால் அவசர உதவிக்கு அழையுங்கள்.")
        ),
        FirstAid(
            "🦶", L("Sprain or muscle strain (PRICE)", "சுளுக்கு (PRICE)"),
            listOf(
                L("Protect and Rest the injured part", "காயமான பகுதியைப் பாதுகாத்து ஓய்வு கொடுங்கள்"),
                L("Ice: a cold pack wrapped in a cloth for 15 minutes, every 2-3 hours", "ஐஸ்: துணியில் சுற்றிய குளிர் பை 15 நிமிடம், 2-3 மணி நேரத்துக்கு ஒரு முறை"),
                L("Compression with an elastic bandage, not too tight", "மிக இறுக்கமில்லாமல் எலாஸ்டிக் கட்டு"),
                L("Elevate the limb above heart level. Do not massage fresh swelling", "காலை இதயத்தை விட உயரத்தில் வையுங்கள். புதிய வீக்கத்தை மசாஜ் செய்யாதீர்கள்")
            ),
            L("Go to hospital if you cannot put weight on it, it looks bent, or the pain is severe.", "எடை வைக்க முடியாவிட்டால், வளைந்து தெரிந்தால், கடும் வலி இருந்தால் மருத்துவமனை செல்லுங்கள்.")
        ),
        FirstAid(
            "💔", L("Heart attack warning signs", "மாரடைப்பு அறிகுறிகள்"),
            listOf(
                L("Signs: chest pain or pressure, pain in the left arm, jaw or back, sweating, breathlessness, nausea", "அறிகுறிகள்: நெஞ்சு வலி / அழுத்தம், இடது கை, தாடை, முதுகு வலி, வியர்வை, மூச்சுத் திணறல், குமட்டல்"),
                L("Call the emergency number immediately (India 108 / 112). Do not drive yourself", "உடனே அவசர எண்ணை அழையுங்கள் (இந்தியா 108 / 112). நீங்களே வண்டி ஓட்டிச் செல்ல வேண்டாம்"),
                L("Sit the person down, keep them calm, loosen clothes", "அமர வைத்து, அமைதிப்படுத்தி, உடையைத் தளர்த்துங்கள்"),
                L("If not allergic and a doctor never forbade it, chewing one 300 mg aspirin is often advised while waiting for help", "ஒவ்வாமை இல்லை, மருத்துவர் தடை செய்யவில்லை என்றால், உதவி வரும் வரை ஒரு 300 mg ஆஸ்பிரின் மாத்திரையை மென்று சாப்பிடச் சொல்வது வழக்கம்")
            ),
            L("This is always an emergency. Every minute matters.", "இது எப்போதும் அவசரம். ஒவ்வொரு நிமிடமும் முக்கியம்.")
        ),
        FirstAid(
            "🫀", L("CPR (not breathing, not responding)", "CPR (சுவாசம் இல்லை, பதில் இல்லை)"),
            listOf(
                L("Shout for help and call the emergency number", "உதவிக்குக் கத்தி, அவசர எண்ணை அழையுங்கள்"),
                L("Place the heel of your hand in the centre of the chest, other hand on top", "மார்பின் நடுவில் உள்ளங்கை அடிப்பகுதியை வைத்து, மேலே மறு கையை வையுங்கள்"),
                L("Push hard and fast, 5-6 cm deep, 100-120 times a minute, without stopping, until help arrives", "5-6 செ.மீ ஆழம், நிமிடத்துக்கு 100-120 முறை, நிறுத்தாமல் பலமாக அழுத்துங்கள்; உதவி வரும் வரை")
            ),
            L("Anyone can do hands-only CPR. Doing something is better than doing nothing.", "யார் வேண்டுமானாலும் கை மட்டும் CPR செய்யலாம். ஒன்றும் செய்யாமல் இருப்பதை விட செய்வது நல்லது.")
        ),
        FirstAid(
            "🐍", L("Snake bite", "பாம்புக்கடி"),
            listOf(
                L("Keep the person calm and still. Take off rings and tight things near the bite", "அமைதியாக, அசையாமல் இருக்கச் செய்யுங்கள். கடித்த இடத்தருகே மோதிரம், இறுக்கமானவற்றை அகற்றுங்கள்"),
                L("Keep the bitten limb still, at or below heart level", "கடிபட்ட உறுப்பை அசைக்காமல், இதய மட்டத்தில் அல்லது கீழே வையுங்கள்"),
                L("Go to the nearest hospital at once - anti-venom is the treatment", "உடனே அருகிலுள்ள மருத்துவமனைக்குச் செல்லுங்கள் - முறிவு மருந்து (anti-venom) தான் சிகிச்சை"),
                L("Do NOT cut, suck, tie tightly, or apply herbs or oil", "வெட்டுவது, உறிஞ்சுவது, இறுக்கிக் கட்டுவது, மூலிகை / எண்ணெய் தடவுவது வேண்டாம்")
            ),
            L("Always go to hospital, even if the person feels fine.", "நன்றாக இருப்பதாகத் தோன்றினாலும் எப்போதும் மருத்துவமனை செல்லுங்கள்.")
        ),
        FirstAid(
            "🥵", L("Heat stroke", "வெப்பத் தாக்கம்"),
            listOf(
                L("Move to a shaded, cool place and lie down", "நிழலான குளிர்ச்சியான இடத்துக்குச் சென்று படுங்கள்"),
                L("Cool with a wet cloth and a fan; loosen clothes", "ஈரத் துணி, விசிறியால் குளிர்வியுங்கள்; உடையைத் தளர்த்துங்கள்"),
                L("If awake, give small sips of water or ORS", "நினைவு இருந்தால் சிறு சிறு மடக்கு தண்ணீர் அல்லது ORS கொடுங்கள்")
            ),
            L("Go to hospital if the person is confused, vomiting or very drowsy.", "குழப்பம், வாந்தி, அதிக மயக்கம் இருந்தால் மருத்துவமனை செல்லுங்கள்.")
        ),
        FirstAid(
            "🦴", L("Suspected broken bone", "எலும்பு முறிவு சந்தேகம்"),
            listOf(
                L("Do not move the person or the injured part more than needed", "தேவைக்கு மேல் நபரையோ காயமான பகுதியையோ அசைக்காதீர்கள்"),
                L("Support the limb with a splint or folded cloth, in the position you found it", "கண்ட நிலையிலேயே குச்சி / மடித்த துணியால் தாங்கிப் பிடியுங்கள்"),
                L("A cold pack wrapped in cloth can reduce swelling", "துணியில் சுற்றிய குளிர் பை வீக்கத்தைக் குறைக்கும்")
            ),
            L("Go to hospital. Do not try to straighten the bone.", "மருத்துவமனை செல்லுங்கள். எலும்பை நேராக்க முயலாதீர்கள்.")
        ),
        FirstAid(
            "🐝", L("Bee or insect sting", "தேனீ / பூச்சிக் கடி"),
            listOf(
                L("Scrape the sting out sideways with a card or nail. Do not squeeze it", "அட்டை அல்லது நகத்தால் கொடுக்கை பக்கவாட்டில் சுரண்டி எடுங்கள்; பிழியாதீர்கள்"),
                L("Wash with water and put a cold pack on it", "தண்ணீரில் கழுவி, குளிர் பை வையுங்கள்")
            ),
            L("Emergency if there is swelling of face or lips, trouble breathing, or dizziness.", "முகம், உதடு வீக்கம், மூச்சுத் திணறல், தலைச்சுற்றல் இருந்தால் அவசரம்.")
        ),
        FirstAid(
            "⚡", L("Seizure (fits)", "வலிப்பு"),
            listOf(
                L("Move hard objects away and put something soft under the head", "கடினமான பொருட்களை அகற்றி, தலைக்குக் கீழ் மென்மையானதை வையுங்கள்"),
                L("Do NOT hold the person down or put anything in the mouth (no key, no spoon)", "பிடித்து அழுத்தாதீர்கள்; வாயில் எதுவும் (சாவி, கரண்டி) வைக்காதீர்கள்"),
                L("When it stops, turn them onto their side. Note how long it lasted", "நின்றதும் ஒரு பக்கமாகத் திருப்புங்கள். எவ்வளவு நேரம் நீடித்தது என்று குறித்துக்கொள்ளுங்கள்")
            ),
            L("Call emergency help if it lasts more than 5 minutes, repeats, or it is the first time.", "5 நிமிடத்துக்கு மேல், மீண்டும் மீண்டும், அல்லது முதல் முறை என்றால் அவசர உதவிக்கு அழையுங்கள்.")
        ),
        FirstAid(
            "💧", L("Chemical or dust in the eye", "கண்ணில் ரசாயனம் / தூசி"),
            listOf(
                L("Rinse the eye with clean running water for 15 minutes, keeping the eyelid open", "கண் இமையைத் திறந்து வைத்து சுத்தமான ஓடும் நீரில் 15 நிமிடம் கழுவுங்கள்"),
                L("Do not rub the eye", "கண்ணைத் தேய்க்காதீர்கள்")
            ),
            L("Go to hospital after a chemical splash, or if pain or blurry vision continues.", "ரசாயனம் பட்டால், அல்லது வலி / மங்கல் தொடர்ந்தால் மருத்துவமனை செல்லுங்கள்.")
        ),
        FirstAid(
            "🤢", L("Loose motion and dehydration", "வயிற்றுப்போக்கு, நீர்வறட்சி"),
            listOf(
                L("Home ORS: 1 litre clean water + 6 level teaspoons sugar + half teaspoon salt. Sip often", "வீட்டு ORS: 1 லிட்டர் சுத்தமான நீர் + 6 தேக்கரண்டி சர்க்கரை + அரை தேக்கரண்டி உப்பு. அடிக்கடி சிறிது சிறிதாகக் குடியுங்கள்"),
                L("Rice kanji, buttermilk, banana are gentle foods", "அரிசிக் கஞ்சி, மோர், வாழைப்பழம் லேசான உணவுகள்")
            ),
            L("See a doctor for blood in stool, high fever, very weak or drowsy person, a baby or an old person.", "மலத்தில் இரத்தம், அதிக காய்ச்சல், மிகவும் சோர்வு, குழந்தை அல்லது முதியவர் என்றால் மருத்துவரைப் பாருங்கள்.")
        ),
        FirstAid(
            "🍬", L("Low blood sugar (diabetes)", "குறைந்த சர்க்கரை (நீரிழிவு)"),
            listOf(
                L("Signs: shaking, sweating, hunger, confusion", "அறிகுறிகள்: நடுக்கம், வியர்வை, பசி, குழப்பம்"),
                L("If awake: give 3 teaspoons sugar in water, glucose, or half a glass of juice", "நினைவு இருந்தால்: 3 தேக்கரண்டி சர்க்கரை நீரில், குளுக்கோஸ் அல்லது அரை டம்ளர் பழச்சாறு கொடுங்கள்"),
                L("Check again after 15 minutes; if still low, repeat, then eat a snack", "15 நிமிடம் கழித்து மீண்டும் பாருங்கள்; குறைவாக இருந்தால் மீண்டும் கொடுத்து, பிறகு சிற்றுண்டி சாப்பிடுங்கள்")
            ),
            L("If the person is unconscious, give nothing by mouth and call emergency help.", "நினைவில்லாவிட்டால் வாயில் எதுவும் கொடுக்காமல் அவசர உதவிக்கு அழையுங்கள்.")
        )
    )

    val homeTips: List<HomeTip> = listOf(
        HomeTip("🤧", L("Cold and cough", "சளி, இருமல்"), L("Sip warm water with ginger, tulsi, pepper and honey (no honey for babies under 1 year). Inhale steam once or twice a day. Rest well.", "இஞ்சி, துளசி, மிளகு, தேன் போட்ட வெதுவெதுப்பான நீர் குடியுங்கள் (1 வயதுக்குட்பட்ட குழந்தைக்கு தேன் வேண்டாம்). நாளுக்கு 1-2 முறை ஆவி பிடியுங்கள். நன்றாக ஓய்வெடுங்கள்.")),
        HomeTip("🗣️", L("Sore throat", "தொண்டை வலி"), L("Gargle with warm salt water 3-4 times a day. Drink warm turmeric milk at night.", "வெதுவெதுப்பான உப்பு நீரில் நாளுக்கு 3-4 முறை கொப்பளியுங்கள். இரவு மஞ்சள் பால் குடியுங்கள்.")),
        HomeTip("🫄", L("Gas and indigestion", "வாயு, அஜீரணம்"), L("Jeera (cumin) water, or ajwain with a pinch of salt. Buttermilk with ginger. Walk 10 minutes after eating.", "சீரகத் தண்ணீர், அல்லது ஓமம் + சிறிது உப்பு. இஞ்சி போட்ட மோர். சாப்பிட்ட பின் 10 நிமிடம் நடங்கள்.")),
        HomeTip("🔥", L("Acidity", "நெஞ்செரிச்சல்"), L("Eat on time in small meals. Do not lie down for 2 hours after eating. Avoid very spicy food and tea on an empty stomach. Cold buttermilk or a banana can soothe.", "நேரத்துக்கு சிறிய அளவில் சாப்பிடுங்கள். சாப்பிட்ட 2 மணி நேரம் படுக்காதீர்கள். மிகவும் காரம், வெறும் வயிற்றில் டீ வேண்டாம். குளிர்ந்த மோர் அல்லது வாழைப்பழம் இதமாக இருக்கும்.")),
        HomeTip("🚽", L("Constipation", "மலச்சிக்கல்"), L("2-3 litres of water, fruits like papaya, vegetables and whole grains. Warm water in the morning. A little time on the toilet at the same time daily.", "2-3 லிட்டர் தண்ணீர், பப்பாளி போன்ற பழங்கள், காய்கறி, முழு தானியம். காலையில் வெதுவெதுப்பான நீர். தினமும் ஒரே நேரத்தில் கழிப்பறை செல்லும் பழக்கம்.")),
        HomeTip("🤕", L("Headache", "தலைவலி"), L("Drink water, rest in a quiet dark room, put a cold or warm cloth on the forehead, gentle neck massage. Ginger tea helps some people. See a doctor for sudden, severe or repeated headaches.", "தண்ணீர் குடியுங்கள், அமைதியான இருட்டு அறையில் ஓய்வெடுங்கள், நெற்றியில் குளிர்ந்த / சூடான துணி, கழுத்தை மெதுவாக மசாஜ். சிலருக்கு இஞ்சி டீ உதவும். திடீர், கடும் அல்லது அடிக்கடி வரும் தலைவலிக்கு மருத்துவரைப் பாருங்கள்.")),
        HomeTip("🌡️", L("Mild fever", "லேசான காய்ச்சல்"), L("Rest, drink plenty of fluids and ORS, wear light cotton clothes, wipe with a lukewarm cloth. See a doctor if fever lasts more than 3 days, is above 39 C (102 F), or a child or old person has it.", "ஓய்வு, நிறைய திரவம், ORS, மெல்லிய பருத்தி உடை, வெதுவெதுப்பான துணியால் துடைக்கவும். 3 நாளுக்கு மேல், 39 C (102 F) மேல், அல்லது குழந்தை / முதியவருக்கு என்றால் மருத்துவரைப் பாருங்கள்.")),
        HomeTip("💪", L("Muscle pain after workout", "உடற்பயிற்சிக்குப் பின் தசை வலி"), L("Warm bath, light stretching, enough protein and sleep, turmeric milk. Rest that muscle for a day.", "வெந்நீர் குளியல், லேசான stretching, போதுமான புரதம், தூக்கம், மஞ்சள் பால். அந்த தசைக்கு ஒரு நாள் ஓய்வு கொடுங்கள்.")),
        HomeTip("🦵", L("Leg cramps", "கால் பிடிப்பு"), L("Stretch the muscle gently, massage, drink water, eat a banana. Do not skip salt and water on very hot days.", "தசையை மெதுவாக நீட்டி, மசாஜ் செய்யுங்கள், தண்ணீர் குடியுங்கள், வாழைப்பழம் சாப்பிடுங்கள்.")),
        HomeTip("😴", L("Better sleep", "நல்ல தூக்கம்"), L("Sleep and wake at the same time. No phone or TV for 1 hour before bed. A glass of warm milk. No tea or coffee after 4 PM.", "ஒரே நேரத்தில் தூங்கி எழுங்கள். படுக்கும் முன் 1 மணி நேரம் ஃபோன் / டிவி வேண்டாம். ஒரு டம்ளர் வெதுவெதுப்பான பால். மாலை 4 மணிக்குப் பிறகு டீ, காபி வேண்டாம்.")),
        HomeTip("👄", L("Mouth ulcer", "வாய்ப்புண்"), L("Rinse with warm salt water, eat curd or buttermilk, drink plenty of water, avoid very spicy food. Eat vitamin B foods: milk, dal, eggs, greens. See a doctor if it lasts more than 2 weeks.", "வெதுவெதுப்பான உப்பு நீரில் கொப்பளியுங்கள், தயிர் / மோர், நிறைய தண்ணீர், காரம் வேண்டாம். வைட்டமின் B உணவுகள்: பால், பருப்பு, முட்டை, கீரை. 2 வாரத்துக்கு மேல் இருந்தால் மருத்துவரைப் பாருங்கள்.")),
        HomeTip("😟", L("Stress and worry", "மன அழுத்தம்"), L("Breathe in for 4 counts, hold 4, breathe out for 6, for 5 minutes. Take a walk. Talk to someone you trust. If sadness lasts many days, speak to a doctor.", "4 எண்ணிக்கை உள்ளிழுத்து, 4 நிறுத்தி, 6 எண்ணிக்கை வெளிவிடுங்கள்; 5 நிமிடம். நடந்து வாருங்கள். நம்பிக்கையானவரிடம் பேசுங்கள். பல நாள் சோகம் நீடித்தால் மருத்துவரிடம் பேசுங்கள்."))
    )

    val workoutTips: List<L> = listOf(
        L("Aim for 150 minutes of moderate exercise a week, for example 30 minutes of brisk walking, 5 days a week.", "வாரம் 150 நிமிடம் மிதமான உடற்பயிற்சி இலக்கு, உதாரணம்: வாரம் 5 நாள், 30 நிமிட வேகநடை."),
        L("Mix cardio (walking, jacks), strength (squats, push-ups) and stretching in your week.", "வாரத்தில் cardio (நடை, jacks), strength (squat, push-up), stretching ஆகியவற்றைக் கலந்து செய்யுங்கள்."),
        L("Warm up for 5 minutes before and cool down for 5 minutes after exercise.", "உடற்பயிற்சிக்கு முன் 5 நிமிடம் warm-up, பின் 5 நிமிடம் cool-down செய்யுங்கள்."),
        L("Good form is better than speed. Increase time or reps slowly.", "வேகத்தை விட சரியான முறை முக்கியம். நேரம் / எண்ணிக்கையை மெதுவாக அதிகரியுங்கள்."),
        L("Rest 1-2 days a week. Muscles grow while you rest and sleep.", "வாரம் 1-2 நாள் ஓய்வு. ஓய்விலும் தூக்கத்திலும்தான் தசை வளரும்."),
        L("Walk 10 minutes after meals. Stand up and move for 2 minutes every hour if you sit a lot.", "சாப்பிட்ட பின் 10 நிமிடம் நடங்கள். அதிக நேரம் உட்கார்ந்தால் ஒவ்வொரு மணி நேரமும் 2 நிமிடம் எழுந்து நடங்கள்."),
        L("Drink a glass of water before and after exercise.", "உடற்பயிற்சிக்கு முன்னும் பின்னும் ஒரு டம்ளர் தண்ணீர் குடியுங்கள்."),
        L("Sleep 7-8 hours. Poor sleep lowers energy and slows recovery.", "7-8 மணி நேரம் தூங்குங்கள். குறைவான தூக்கம் சக்தியையும் மீட்சியையும் குறைக்கும்."),
        L("Stop and rest if you feel chest pain, dizziness or sharp pain.", "நெஞ்சு வலி, தலைச்சுற்றல், கூர்மையான வலி வந்தால் நிறுத்தி ஓய்வெடுங்கள்.")
    )

    val foodTips: List<L> = listOf(
        L("Fill half your plate with vegetables, a quarter with protein, a quarter with grains.", "தட்டில் பாதி காய்கறி, கால் பங்கு புரதம், கால் பங்கு தானியம்."),
        L("Choose millets and whole grains more often than polished white rice and maida.", "பாலிஷ் அரிசி, மைதாவை விட சிறுதானியம், முழு தானியத்தை அதிகம் தேர்ந்தெடுங்கள்."),
        L("Have some protein in every meal: dal, sprouts, curd, egg, fish.", "ஒவ்வொரு வேளையும் புரதம்: பருப்பு, முளைகட்டிய பயறு, தயிர், முட்டை, மீன்."),
        L("Drink 2-3 litres of water a day. Choose whole fruit instead of juice.", "நாளுக்கு 2-3 லிட்டர் தண்ணீர். பழச்சாறுக்குப் பதில் முழுப் பழம்."),
        L("Cut down sugar, salt and fried food. Cook at home when you can.", "சர்க்கரை, உப்பு, பொரித்த உணவைக் குறையுங்கள். முடிந்தவரை வீட்டில் சமையுங்கள்."),
        L("Eat slowly and stop when you are about 80 percent full.", "மெதுவாகச் சாப்பிட்டு, சுமார் 80 சதவீதம் வயிறு நிறைந்ததும் நிறுத்துங்கள்."),
        L("Do not skip breakfast. Keep dinner light and 2-3 hours before sleep.", "காலை உணவைத் தவிர்க்காதீர்கள். இரவு உணவு லேசாக, தூங்கும் 2-3 மணி நேரம் முன்."),
        L("Eat colourful food: green, red, yellow and orange vegetables and fruits.", "பல வண்ண உணவு: பச்சை, சிவப்பு, மஞ்சள், ஆரஞ்சு காய்கறி, பழங்கள்."),
        L("Eat 1 seasonal local fruit and a handful of nuts daily.", "தினமும் ஒரு பருவகால உள்ளூர் பழம், ஒரு கைப்பிடி கொட்டைகள்.")
    )

    /** One short tip per day for the home screen. */
    fun tipOfTheDay(dayOfYear: Int): L {
        val all = workoutTips + foodTips
        return all[dayOfYear % all.size]
    }
}

/** What a finished workout does for the body. */
object Benefits {

    fun forExercise(category: String): List<L> = when (category) {
        "Cardio" -> listOf(
            L("Your heart and lungs got stronger, so you get less breathless on stairs and walks.", "இதயமும் நுரையீரலும் வலுப்பெற்றன; படிகளிலும் நடையிலும் மூச்சு வாங்குவது குறையும்."),
            L("It burns calories and helps weight control.", "கலோரி எரிந்து எடை கட்டுப்பாட்டுக்கு உதவுகிறது."),
            L("It lifts your mood (feel-good hormones) and lowers stress.", "மனநிலையை உயர்த்தி (மகிழ்ச்சி ஹார்மோன்கள்) மன அழுத்தத்தைக் குறைக்கிறது."),
            L("Regular cardio helps keep BP and blood sugar in a healthy range.", "தொடர்ந்து செய்தால் BP, இரத்தச் சர்க்கரை ஆரோக்கிய அளவில் இருக்க உதவும்.")
        )
        "Legs" -> listOf(
            L("Strong thighs and calves protect your knees and make climbing stairs easier.", "வலிமையான தொடை, கெண்டைக்கால் முழங்காலைப் பாதுகாத்து படி ஏறுவதை எளிதாக்கும்."),
            L("Big leg muscles burn many calories, even after you finish.", "பெரிய கால் தசைகள் முடித்த பிறகும் நிறைய கலோரி எரிக்கும்."),
            L("It improves balance and helps keep bones strong as you age.", "சமநிலையை மேம்படுத்தி, வயதானாலும் எலும்பை வலுவாக வைக்க உதவும்.")
        )
        "Glutes" -> listOf(
            L("Strong hips and glutes support your lower back and can ease back pain.", "வலிமையான இடுப்பு, பிட்டத் தசைகள் கீழ் முதுகை தாங்கி முதுகு வலியைக் குறைக்கும்."),
            L("It improves posture, walking and running power.", "உடல் நிமிர்வு, நடை, ஓடும் சக்தி மேம்படும்."),
            L("It is gentle on the knees.", "முழங்காலுக்கு மென்மையானது.")
        )
        "Upper Body" -> listOf(
            L("Stronger chest, shoulders and arms make daily jobs like lifting and carrying easier.", "வலிமையான மார்பு, தோள், கைகள் தூக்குவது, சுமப்பது போன்ற அன்றாட வேலைகளை எளிதாக்கும்."),
            L("It helps posture and protects shoulders and bones.", "உடல் நிமிர்வுக்கு உதவி, தோள்பட்டை, எலும்புகளைப் பாதுகாக்கும்."),
            L("More muscle means your body burns more energy at rest.", "அதிக தசை என்றால் ஓய்விலும் அதிக சக்தி எரியும்.")
        )
        "Core" -> listOf(
            L("A strong core protects your back and keeps your posture upright.", "வலிமையான core முதுகைப் பாதுகாத்து உடலை நிமிர்ந்து வைக்கும்."),
            L("It improves balance and helps every other exercise.", "சமநிலையை மேம்படுத்தி மற்ற எல்லா பயிற்சிகளுக்கும் உதவும்."),
            L("It tones the belly muscles. Fat loss still needs food and cardio.", "வயிற்றுத் தசைகளை உறுதியாக்கும். கொழுப்பு குறைய உணவும் cardio-வும் தேவை.")
        )
        else -> listOf(
            L("Regular exercise strengthens your heart, muscles and bones.", "தொடர்ந்த உடற்பயிற்சி இதயம், தசை, எலும்பை வலுவாக்கும்.")
        )
    }

    fun forWalk(type: String): List<L> = when (type) {
        "Running" -> listOf(
            L("Running builds a strong heart and lungs and improves stamina.", "ஓட்டம் இதயம், நுரையீரலை வலுவாக்கி தாங்கும் திறனை அதிகரிக்கும்."),
            L("It burns more calories than walking and strengthens bones.", "நடையை விட அதிக கலோரி எரித்து எலும்பை வலுவாக்கும்."),
            L("Cool down with a slow walk and stretch your legs.", "மெதுவாக நடந்து cool-down செய்து கால்களை stretch செய்யுங்கள்.")
        )
        "Cycling" -> listOf(
            L("Cycling strengthens your legs and heart with little stress on the knees.", "சைக்கிள் ஓட்டுவது முழங்காலுக்கு அழுத்தம் குறைவாக கால்களையும் இதயத்தையும் வலுவாக்கும்."),
            L("It improves stamina and helps weight control.", "தாங்கும் திறனை அதிகரித்து எடை கட்டுப்பாட்டுக்கு உதவும்.")
        )
        "Hiking" -> listOf(
            L("Hiking strengthens legs and balance, and fresh air lowers stress.", "மலை நடை கால்கள், சமநிலையை வலுவாக்கும்; புதிய காற்று மன அழுத்தத்தைக் குறைக்கும்."),
            L("Going uphill burns extra calories and works your heart.", "மேடு ஏறுவது கூடுதல் கலோரி எரித்து இதயத்தைப் பலப்படுத்தும்.")
        )
        else -> listOf(
            L("Walking is gentle on the joints and good for your heart.", "நடை மூட்டுகளுக்கு மென்மையானது, இதயத்துக்கு நல்லது."),
            L("It helps digestion, lowers blood sugar and lifts your mood.", "செரிமானத்துக்கு உதவி, இரத்தச் சர்க்கரையைக் குறைத்து, மனநிலையை உயர்த்தும்."),
            L("It helps you sleep better and keeps weight in check.", "நல்ல தூக்கத்துக்கு உதவி, எடையை கட்டுக்குள் வைக்கும்.")
        )
    }

    /** One small thing to do right after the workout. */
    fun afterTip(): L = L(
        "Now: drink water, stretch for 2 minutes, and eat some protein within an hour.",
        "இப்போது: தண்ணீர் குடியுங்கள், 2 நிமிடம் stretch செய்யுங்கள், 1 மணி நேரத்துக்குள் புரதம் சாப்பிடுங்கள்."
    )
}
