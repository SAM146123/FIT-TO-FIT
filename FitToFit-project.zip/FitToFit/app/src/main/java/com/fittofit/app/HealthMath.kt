package com.fittofit.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.min

data class CycleInfo(
    val cycleDay: Int,
    val nextPeriod: LocalDate,
    val daysToNext: Long,
    val fertileStart: LocalDate,
    val fertileEnd: LocalDate,
    val inPeriod: Boolean,
    val avgCycle: Int
)

/** Simple health calculations. These are general estimates, not medical advice. */
object HealthMath {

    fun bmi(heightCm: Int, weightKg: Int): Double {
        if (heightCm <= 0 || weightKg <= 0) return 0.0
        val m = heightCm / 100.0
        return weightKg / (m * m)
    }

    fun bmiLabel(b: Double): String = when {
        b <= 0.0 -> "—"
        b < 18.5 -> "Underweight"
        b < 25.0 -> "Healthy"
        b < 30.0 -> "Overweight"
        else -> "Obese"
    }

    /** Resting energy use (Mifflin-St Jeor). 0 when details are missing. */
    fun bmr(p: Profile): Double {
        if (p.heightCm <= 0 || p.weightKg <= 0 || p.age <= 0) return 0.0
        val base = 10.0 * p.weightKg + 6.25 * p.heightCm - 5.0 * p.age
        return when (p.sex) {
            "M" -> base + 5
            "F" -> base - 161
            else -> base - 78
        }
    }

    /** Body-fat estimate from BMI, age and sex (Deurenberg). Only an estimate. */
    fun bodyFatEstimate(p: Profile): Double {
        val b = bmi(p.heightCm, p.weightKg)
        if (b <= 0.0 || p.age <= 0) return 0.0
        val male = when (p.sex) {
            "M" -> 1.0
            "F" -> 0.0
            else -> 0.5
        }
        return (1.20 * b + 0.23 * p.age - 10.8 * male - 5.4).coerceIn(3.0, 60.0)
    }

    fun sleepScore(totalMin: Int, deepMin: Int, remMin: Int): Int {
        if (totalMin <= 0) return 0
        val duration = min(totalMin, 480) / 480.0 * 70
        val quality = if (deepMin + remMin > 0) {
            min((deepMin + remMin).toDouble() / totalMin / 0.4, 1.0) * 30
        } else 20.0
        return (duration + quality).toInt().coerceIn(0, 100)
    }

    /** 0..100, or -1 when there is no data. Estimated from HRV / resting heart rate. */
    fun stressLevel(hrv: Double, restingHr: Int): Int = when {
        hrv > 0 -> when {
            hrv >= 50 -> 20
            hrv >= 30 -> 50
            else -> 80
        }
        restingHr > 0 -> when {
            restingHr < 65 -> 25
            restingHr <= 80 -> 45
            else -> 70
        }
        else -> -1
    }

    fun stressLabel(level: Int): String = when {
        level < 0 -> "No data"
        level < 35 -> "Low"
        level < 65 -> "Moderate"
        else -> "High"
    }

    fun cycle(
        starts: List<LocalDate>,
        fallbackCycle: Int,
        periodLen: Int,
        today: LocalDate = LocalDate.now()
    ): CycleInfo? {
        val last = starts.lastOrNull() ?: return null
        val gaps = starts.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }
            .filter { it in 18..45 }
        val avg = if (gaps.size >= 2) gaps.takeLast(6).average().toInt() else fallbackCycle
        var next = last.plusDays(avg.toLong())
        while (next.isBefore(today)) next = next.plusDays(avg.toLong())
        val cycleStart = next.minusDays(avg.toLong())
        val day = (ChronoUnit.DAYS.between(cycleStart, today) + 1).toInt()
        val ovulation = next.minusDays(14)
        return CycleInfo(
            cycleDay = day,
            nextPeriod = next,
            daysToNext = ChronoUnit.DAYS.between(today, next),
            fertileStart = ovulation.minusDays(5),
            fertileEnd = ovulation.plusDays(1),
            inPeriod = day <= periodLen,
            avgCycle = avg
        )
    }
}
