package com.fittofit.app

import android.content.Context
import java.time.LocalDate

/** Things the user logs by hand. Stored only on this phone. */
class LogStore(context: Context) {
    private val p = context.getSharedPreferences("logs", Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()

    fun waterMl(): Int = if (p.getString("water_date", "") == today()) p.getInt("water", 0) else 0

    fun addWater(ml: Int) {
        p.edit().putString("water_date", today()).putInt("water", waterMl() + ml).apply()
    }

    fun foodKcal(): Int = if (p.getString("food_date", "") == today()) p.getInt("food", 0) else 0

    fun addFood(kcal: Int) {
        p.edit().putString("food_date", today()).putInt("food", foodKcal() + kcal).apply()
    }

    fun periodStarts(): List<LocalDate> =
        (p.getString("periods", "") ?: "")
            .split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .distinct()
            .sorted()

    private fun savePeriods(list: List<LocalDate>) {
        p.edit().putString("periods", list.joinToString(",") { it.toString() }).apply()
    }

    fun addPeriodStart(d: LocalDate) = savePeriods((periodStarts() + d).distinct().sorted())

    fun removeLastPeriod() = savePeriods(periodStarts().dropLast(1))

    var cycleLength: Int
        get() = p.getInt("cycle", 28)
        set(v) { p.edit().putInt("cycle", v).apply() }

    var periodLength: Int
        get() = p.getInt("period_len", 5)
        set(v) { p.edit().putInt("period_len", v).apply() }

    var celebratedDate: String
        get() = p.getString("celebrated", "") ?: ""
        set(v) { p.edit().putString("celebrated", v).apply() }

    var welcomeDate: String
        get() = p.getString("welcome", "") ?: ""
        set(v) { p.edit().putString("welcome", v).apply() }
}
