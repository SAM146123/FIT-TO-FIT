package com.fittofit.app

import android.content.Context
import java.time.LocalDate

/** Things the user logs by hand. Stored only on this phone. */
class LogStore(context: Context) {
    private val p = context.getSharedPreferences("logs", Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()

    fun waterMl(): Int = if (p.getString("water_date", "") == today()) p.getInt("water", 0) else 0

    fun addWater(ml: Int) {
        p.edit().putString("water_date", today()).putInt("water", waterMl() + ml).apply()
    }

    fun foodKcal(): Int = if (p.getString("food_date", "") == today()) p.getInt("food", 0) else 0

    fun addFood(kcal: Int) {
        p.edit().putString("food_date", today()).putInt("food", (foodKcal() + kcal).coerceAtLeast(0)).apply()
    }

    fun macros(): Triple<Int, Int, Int> =
        if (p.getString("macro_date", "") == today()) Triple(p.getInt("m_p", 0), p.getInt("m_c", 0), p.getInt("m_f", 0))
        else Triple(0, 0, 0)

    fun addMacros(protein: Int, carbs: Int, fat: Int) {
        val (a, b, c) = macros()
        p.edit().putString("macro_date", today())
            .putInt("m_p", (a + protein).coerceAtLeast(0))
            .putInt("m_c", (b + carbs).coerceAtLeast(0))
            .putInt("m_f", (c + fat).coerceAtLeast(0)).apply()
    }

    /** Meals from the diet plan marked as eaten today (B, L, D, S). */
    fun eatenSlots(): Set<String> =
        if (p.getString("slots_date", "") == today()) (p.getStringSet("slots", emptySet()) ?: emptySet()) else emptySet()

    fun setEaten(slot: String, on: Boolean) {
        val cur = eatenSlots().toMutableSet()
        if (on) cur.add(slot) else cur.remove(slot)
        p.edit().putString("slots_date", today()).putStringSet("slots", cur).apply()
    }

    /** Extra food typed in by the person today, each as "name|kcal|protein|carbs|fat". */
    fun eatenItems(): List<String> =
        if (p.getString("items_date", "") == today()) (p.getString("items", "") ?: "").split("\n").filter { it.isNotBlank() } else emptyList()

    fun addEatenItem(name: String, k: Int, pr: Int, c: Int, f: Int) {
        val cur = eatenItems() + "${name.replace("|", " ").replace("\n", " ")}|$k|$pr|$c|$f"
        p.edit().putString("items_date", today()).putString("items", cur.joinToString("\n")).apply()
    }

    fun removeEatenItem(index: Int): List<Int>? {
        val cur = eatenItems().toMutableList()
        if (index !in cur.indices) return null
        val parts = cur.removeAt(index).split("|")
        p.edit().putString("items_date", today()).putString("items", cur.joinToString("\n")).apply()
        return parts.drop(1).map { it.toIntOrNull() ?: 0 }
    }

    fun periodStarts(): List<LocalDate> =
        (p.getString("periods", "") ?: "")
            .split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            .distinct()
            .sorted()

    private fun savePeriods(list: List<LocalDate>) {
        p.edit().putString("periods", list.joinToString(",") { it.toString() }).apply()
    }

    fun addPeriodStart(d: LocalDate) = savePeriods((periodStarts() + d).distinct().sorted())

    fun removeLastPeriod() = savePeriods(periodStarts().dropLast(1))

    var cycleLength: Int
        get() = p.getInt("cycle", 28)
        set(v) { p.edit().putInt("cycle", v).apply() }

    var periodLength: Int
        get() = p.getInt("period_len", 5)
        set(v) { p.edit().putInt("period_len", v).apply() }

    fun sessions(): List<ActivityItem> =
        (p.getString("sessions", "") ?: "")
            .split("\n")
            .filter { it.isNotBlank() }
            .mapNotNull { line ->
                val f = line.split("|")
                if (f.size < 5) null else ActivityItem(
                    title = f[0],
                    startMs = f[1].toLongOrNull() ?: return@mapNotNull null,
                    minutes = f[2].toIntOrNull() ?: 0,
                    km = f[3].toDoubleOrNull() ?: 0.0,
                    kcal = f[4].toIntOrNull() ?: 0,
                    source = "FIT TO FIT",
                    route = f.getOrNull(5) == "1"
                )
            }

    fun addSession(item: ActivityItem) {
        val line = listOf(item.title.replace("|", " "), item.startMs, item.minutes, item.km, item.kcal, if (item.route) "1" else "0").joinToString("|")
        val all = (listOf(line) + (p.getString("sessions", "") ?: "").split("\n").filter { it.isNotBlank() }).take(50)
        p.edit().putString("sessions", all.joinToString("\n")).apply()
    }

    var celebratedDate: String
        get() = p.getString("celebrated", "") ?: ""
        set(v) { p.edit().putString("celebrated", v).apply() }

    var welcomeDate: String
        get() = p.getString("welcome", "") ?: ""
        set(v) { p.edit().putString("welcome", v).apply() }
}
