package com.fittofit.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.health.connect.client.PermissionController
import com.fittofit.app.ui.ExtraActions
import com.fittofit.app.ui.FitApp
import com.fittofit.app.ui.FitTheme
import com.fittofit.app.ui.HealthActions
import com.fittofit.app.ui.SocialActions

class MainActivity : ComponentActivity() {

    private val vm: FitViewModel by viewModels()

    // Step counter (Android 10+) and notification (Android 13+) permissions, asked together
    private val startupPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.sensor.start()
            vm.ble.connectSaved()
        }

    // Profile photo picker
    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) vm.setPhoto(uri)
        }

    // Location permission (GPS distance for walks). The walk starts either way.
    private val locationForWalk =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.startWalk()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // daily motivation notifications (8:00 and 19:00)
        Notifier.schedule(applicationContext)

        setContent {
            FitTheme {
                val state by vm.state.collectAsState()
                val bpm by vm.ble.heartRate.collectAsState()
                val history by vm.ble.history.collectAsState()
                val status by vm.ble.status.collectAsState()
                val name by vm.ble.connectedName.collectAsState()
                val devices by vm.ble.devices.collectAsState()
                val social by vm.social.collectAsState()

                // Health Connect (Google Fit data) permission dialog
                val healthLauncher = rememberLauncherForActivityResult(
                    PermissionController.createRequestPermissionResultContract()
                ) { vm.refresh() }

                // Bluetooth runtime permissions
                val blePermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                val bleLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { result -> if (result.values.all { it }) vm.ble.startScan() }

                val actions = remember {
                    HealthActions(
                        addWater = { vm.addWater(it) },
                        addFood = { vm.addFood(it) },
                        logPeriod = { vm.logPeriodToday() },
                        undoPeriod = { vm.undoPeriod() },
                        setCycle = { cycle, period -> vm.setCycle(cycle, period) }
                    )
                }

                val extraActions = remember {
                    ExtraActions(
                        setVoice = { vm.setVoice(it) },
                        speak = { t, i -> vm.speak(t, i) },
                        stopSpeak = { vm.stopSpeak() },
                        pickPhoto = {
                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        removePhoto = { vm.removePhoto() },
                        finishWorkout = { t, m, k -> vm.finishWorkout(t, m, k) }
                    )
                }

                val socialActions = remember {
                    SocialActions(
                        signUp = { n, e, p -> vm.signUp(n, e, p) },
                        signIn = { e, p -> vm.signIn(e, p) },
                        signOut = { vm.signOut() },
                        refresh = { vm.refreshFriends() },
                        addFriend = { vm.addFriend(it) },
                        removeFriend = { vm.removeFriend(it) },
                        clearNotice = { vm.clearSocialNotice() }
                    )
                }

                FitApp(
                    state = state,
                    bpm = bpm,
                    history = history,
                    watchStatus = status,
                    watchName = name,
                    devices = devices,
                    onConnectHealth = {
                        if (vm.health.isAvailable) {
                            healthLauncher.launch(vm.health.permissions)
                        } else {
                            // Offer to install / update Health Connect from Play Store
                            startActivity(
                                Intent(Intent.ACTION_VIEW).setPackage("com.android.vending").setData(
                                    Uri.parse("market://details?id=com.google.android.apps.healthdata")
                                )
                            )
                        }
                    },
                    onScan = { bleLauncher.launch(blePermissions) },
                    onStopScan = { vm.ble.stopScan() },
                    onPickDevice = { vm.ble.connect(it) },
                    onDisconnect = { vm.ble.disconnect() },
                    onRefresh = { vm.refresh() },
                    onStartWalk = {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                            vm.startWalk()
                        } else {
                            locationForWalk.launch(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            )
                        }
                    },
                    onStopWalk = { vm.stopWalk() },
                    onSaveProfile = { vm.saveProfile(it) },
                    actions = actions,
                    onWelcomed = { vm.markWelcomed() },
                    onCelebrated = { vm.markCelebrated() },
                    social = social,
                    socialActions = socialActions,
                    extra = extraActions
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        startStepSensor()
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }

    override fun onStop() {
        if (!vm.isWalking()) vm.sensor.stop()
        super.onStop()
    }

    private fun startStepSensor() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.POST_NOTIFICATIONS)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.BLUETOOTH_CONNECT)

        if (needed.isEmpty()) { vm.sensor.start(); vm.ble.connectSaved() } else startupPermissions.launch(needed.toTypedArray())
    }
}
