package com.fittofit.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import com.fittofit.app.ui.FitApp
import com.fittofit.app.ui.FitTheme

class MainActivity : ComponentActivity() {

    private val vm: FitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FitTheme {
                val state by vm.state.collectAsState()
                val bpm by vm.ble.heartRate.collectAsState()
                val history by vm.ble.history.collectAsState()
                val status by vm.ble.status.collectAsState()
                val name by vm.ble.connectedName.collectAsState()
                val devices by vm.ble.devices.collectAsState()

                // Health Connect (Google Fit data) permission dialog
                val healthLauncher = rememberLauncherForActivityResult(
                    PermissionController.createRequestPermissionResultContract()
                ) { vm.refresh() }

                // Bluetooth runtime permissions
                val blePermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                val bleLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { result -> if (result.values.all { it }) vm.ble.startScan() }

                FitApp(
                    state = state,
                    bpm = bpm,
                    history = history,
                    watchStatus = status,
                    watchName = name,
                    devices = devices,
                    onConnectHealth = {
                        if (vm.health.isAvailable) {
                            healthLauncher.launch(vm.health.permissions)
                        } else {
                            // Offer to install / update Health Connect from Play Store
                            startActivity(
                                Intent(Intent.ACTION_VIEW).setPackage("com.android.vending").setData(
                                    Uri.parse("market://details?id=com.google.android.apps.healthdata")
                                )
                            )
                        }
                    },
                    onScan = { bleLauncher.launch(blePermissions) },
                    onStopScan = { vm.ble.stopScan() },
                    onPickDevice = { vm.ble.connect(it) },
                    onDisconnect = { vm.ble.disconnect() },
                    onRefresh = { vm.refresh() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}
