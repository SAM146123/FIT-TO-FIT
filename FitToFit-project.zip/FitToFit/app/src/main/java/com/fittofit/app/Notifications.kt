package com.fittofit.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "daily_motivation"

    val morningMessages = listOf(
        "காலை வணக்கம்! இன்று உங்கள் இலக்கை அடைய ஒரு அடியே போதும் — தொடங்குங்கள்! 💪",
        "ஒவ்வொரு அடியும் ஆரோக்கியத்தை நோக்கிய முன்னேற்றம். இன்றைய நடையைத் தொடங்குவோமா? 🚶",
        "சிறிய முயற்சிகள்தான் பெரிய மாற்றத்தை உருவாக்கும். இன்று 10 நிமிடம் நடங்கள்! 🌟",
        "தண்ணீர் குடியுங்கள், நடக்கத் தொடங்குங்கள் — இந்த நாள் உங்களுடையது! 💧",
        "நேற்றைவிட இன்று இன்னும் கொஞ்சம் சிறப்பாக! உங்களால் முடியும்! 🔥",
        "உங்கள் உடல் உங்களுக்கு நன்றி சொல்லும் — இன்று நகருங்கள்! ❤️",
        "இன்றைய இலக்கு தயார். நீங்கள் தயாரா? 🎯"
    )

    val eveningMessages = listOf(
        "மாலை வணக்கம்! இன்றைய இலக்கை முடித்துவிட்டீர்களா? இன்னும் நேரம் இருக்கிறது! 🌇",
        "ஒரு சிறிய நடை இன்றைய நாளை வெற்றியாக்கும். வாருங்கள்! 🚶‍♀️",
        "தூங்கும் முன் சில அடிகள் — உங்கள் streak-ஐ காப்பாற்றுங்கள்! 🔥",
        "இன்று நீங்கள் செய்தவை பெருமைக்குரியவை. கடைசி முயற்சி செய்வோமா? 🌙",
        "இலக்குக்கு அருகில் இருக்கிறீர்கள்! இன்னும் கொஞ்சம் நடங்கள்! 🏁"
    )

    const val GOAL_DONE_MESSAGE = "இன்றைய இலக்கை முடித்துவிட்டீர்கள்! வாழ்த்துகள் 🎉 நாளையும் தொடருங்கள்!"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Daily motivation", NotificationManager.IMPORTANCE_DEFAULT)
            ch.description = "Daily reminders to keep you moving"
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    /** Schedules a morning (8:00) and an evening (19:00) motivational notification, every day. */
    fun schedule(ctx: Context) {
        createChannel(ctx)
        enqueue(ctx, "morning", 8)
        enqueue(ctx, "evening", 19)
    }

    private fun enqueue(ctx: Context, kind: String, hour: Int) {
        val now = LocalDateTime.now()
        var first = now.toLocalDate().atTime(hour, 0)
        if (!first.isAfter(now)) first = first.plusDays(1)
        val delay = Duration.between(now, first).toMillis()

        val request = PeriodicWorkRequestBuilder<MotivationWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("kind" to kind))
            .build()

        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "fit_$kind", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}

class MotivationWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val kind = inputData.getString("kind") ?: "morning"
        val profile = ProfileStore(ctx).load()

        // last known steps for today (saved by the step sensor)
        val prefs = ctx.getSharedPreferences("steps", Context.MODE_PRIVATE)
        val stepsToday = if (prefs.getString("date", "") == LocalDate.now().toString()) prefs.getLong("today", 0L) else 0L
        val goalDone = stepsToday >= profile.stepGoal

        val day = LocalDate.now().dayOfYear
        var message = when {
            kind == "evening" && goalDone -> Notifier.GOAL_DONE_MESSAGE
            kind == "evening" -> Notifier.eveningMessages[day % Notifier.eveningMessages.size]
            else -> Notifier.morningMessages[day % Notifier.morningMessages.size]
        }
        if (profile.name.isNotBlank()) message = "${profile.name}, $message"

        Notifier.createChannel(ctx)
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_fit)
            .setContentTitle("FIT TO FIT")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        NotificationManagerCompat.from(ctx).notify(if (kind == "evening") 2002 else 2001, notification)
        return Result.success()
    }
}
