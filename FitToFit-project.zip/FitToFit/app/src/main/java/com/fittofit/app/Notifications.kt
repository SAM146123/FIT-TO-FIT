package com.fittofit.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "daily_motivation"

    val morningMessages = listOf(
        "காலை வணக்கம்! இன்று உங்கள் இலக்கை அடைய ஒரு அடியே போதும் — தொடங்குங்கள்! 💪",
        "ஒவ்வொரு அடியும் ஆரோக்கியத்தை நோக்கிய முன்னேற்றம். இன்றைய நடையைத் தொடங்குவோமா? 🚶",
        "சிறிய முயற்சிகள்தான் பெரிய மாற்றத்தை உருவாக்கும். இன்று 10 நிமிடம் நடங்கள்! 🌟",
        "தண்ணீர் குடியுங்கள், நடக்கத் தொடங்குங்கள் — இந்த நாள் உங்களுடையது! 💧",
        "நேற்றைவிட இன்று இன்னும் கொஞ்சம் சிறப்பாக! உங்களால் முடியும்! 🔥",
        "உங்கள் உடல் உங்களுக்கு நன்றி சொல்லும் — இன்று நகருங்கள்! ❤️",
        "இன்றைய இலக்கு தயார். நீங்கள் தயாரா? 🎯"
    )

    val eveningMessages = listOf(
        "மாலை வணக்கம்! இன்றைய இலக்கை முடித்துவிட்டீர்களா? இன்னும் நேரம் இருக்கிறது! 🌇",
        "ஒரு சிறிய நடை இன்றைய நாளை வெற்றியாக்கும். வாருங்கள்! 🚶‍♀️",
        "தூங்கும் முன் சில அடிகள் — உங்கள் streak-ஐ காப்பாற்றுங்கள்! 🔥",
        "இன்று நீங்கள் செய்தவை பெருமைக்குரியவை. கடைசி முயற்சி செய்வோமா? 🌙",
        "இலக்குக்கு அருகில் இருக்கிறீர்கள்! இன்னும் கொஞ்சம் நடங்கள்! 🏁"
    )

    const val GOAL_DONE_MESSAGE = "இன்றைய இலக்கை முடித்துவிட்டீர்கள்! வாழ்த்துகள் 🎉 நாளையும் தொடருங்கள்!"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Daily motivation", NotificationManager.IMPORTANCE_DEFAULT)
            ch.description = "Daily reminders to keep you moving"
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    /** Schedules a morning (8:00) and an evening (19:00) motivational notification, every day. */
    fun schedule(ctx: Context) {
        createChannel(ctx)
        // every ~15 minutes: tell the person when someone they follow has posted
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "follow_posts", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<FollowWorker>(15, TimeUnit.MINUTES).build()
        )
        // every hour: a motivation message until today's step goal is reached
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "hourly_goal", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<HourlyGoalWorker>(1, TimeUnit.HOURS).build()
        )
        enqueue(ctx, "morning", 8)
        enqueue(ctx, "evening", 19)
    }

    fun hourlyEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("notif", Context.MODE_PRIVATE).getBoolean("hourly", true)

    fun setHourly(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences("notif", Context.MODE_PRIVATE).edit().putBoolean("hourly", on).apply()
    }

    /** Hourly lines. %d is replaced by the steps still left. */
    val hourlyEn = listOf(
        "Only %d steps to go. You can do it!",
        "Every step counts. %d more and today's goal is yours!",
        "Get up and move for 5 minutes. %d steps left!",
        "Your future self will thank you. %d steps to your goal.",
        "Small steps, big results. Just %d more!",
        "Don't stop now. %d steps and you win the day!",
        "A short walk clears the mind. %d steps to go.",
        "You are stronger than your excuses. %d steps left!"
    )
    val hourlyTa = listOf(
        "இலக்குக்கு இன்னும் %d அடிகள் மட்டுமே. உங்களால் முடியும்!",
        "ஒவ்வொரு அடியும் முக்கியம். இன்னும் %d அடி, இன்றைய இலக்கு உங்களுக்கே!",
        "எழுந்து 5 நிமிடம் நடங்கள். %d அடிகள் மீதம்!",
        "இன்றைய முயற்சிக்கு நாளை உங்கள் உடல் நன்றி சொல்லும். %d அடிகள் மீதம்.",
        "சிறிய அடிகள், பெரிய மாற்றம். இன்னும் %d மட்டுமே!",
        "இப்போது நிறுத்தாதீர்கள். %d அடி நடந்தால் இன்றைய வெற்றி உங்களுடையது!",
        "ஒரு சிறு நடை மனதைத் தெளிவாக்கும். %d அடிகள் மீதம்.",
        "சாக்குப்போக்குகளை விட நீங்கள் வலிமையானவர். %d அடிகள் மீதம்!"
    )

    private fun enqueue(ctx: Context, kind: String, hour: Int) {
        val now = LocalDateTime.now()
        var first = now.toLocalDate().atTime(hour, 0)
        if (!first.isAfter(now)) first = first.plusDays(1)
        val delay = Duration.between(now, first).toMillis()

        val request = PeriodicWorkRequestBuilder<MotivationWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("kind" to kind))
            .build()

        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "fit_$kind", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}

class MotivationWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val kind = inputData.getString("kind") ?: "morning"
        val profile = ProfileStore(ctx).load()

        // last known steps for today (saved by the step sensor)
        val prefs = ctx.getSharedPreferences("steps", Context.MODE_PRIVATE)
        val stepsToday = if (prefs.getString("date", "") == LocalDate.now().toString()) prefs.getLong("today", 0L) else 0L
        val goalDone = stepsToday >= profile.stepGoal

        val day = LocalDate.now().dayOfYear
        var message = when {
            kind == "evening" && goalDone -> Notifier.GOAL_DONE_MESSAGE
            kind == "evening" -> Notifier.eveningMessages[day % Notifier.eveningMessages.size]
            else -> Notifier.morningMessages[day % Notifier.morningMessages.size]
        }
        if (profile.name.isNotBlank()) message = "${profile.name}, $message"

        Notifier.createChannel(ctx)
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_fit)
            .setContentTitle("FIT TO FIT")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        NotificationManagerCompat.from(ctx).notify(if (kind == "evening") 2002 else 2001, notification)
        return Result.success()
    }
}


/** Checks (about every 15 minutes) whether someone you follow has posted, and shows a notification. */
class FollowWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        try {
            val repo = SocialRepository()
            if (!repo.signedIn) return Result.success()
            val prefs = ctx.getSharedPreferences("follow", Context.MODE_PRIVATE)
            val last = prefs.getLong("last", 0L)
            val now = System.currentTimeMillis()
            if (last == 0L) {
                prefs.edit().putLong("last", now).apply()
                return Result.success()
            }
            val ids = repo.followingIds()
            if (ids.isEmpty()) {
                prefs.edit().putLong("last", now).apply()
                return Result.success()
            }
            val fresh = repo.newPostsFrom(ids, last).filter { it.authorId != repo.myUid }
            prefs.edit().putLong("last", now).apply()
            if (fresh.isEmpty()) return Result.success()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return Result.success()

            Notifier.createChannel(ctx)
            val pending = PendingIntent.getActivity(
                ctx, 1,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            fresh.takeLast(3).forEach { post ->
                val n = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
                    .setSmallIcon(R.drawable.ic_stat_fit)
                    .setContentTitle("${post.name} posted a new achievement")
                    .setContentText(post.text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(post.text))
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(ctx).notify(3000 + (post.id.hashCode() and 0xFFFF), n)
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return Result.success()
        }
        return Result.success()
    }
}


/** Every hour (7 AM - 9 PM): a motivation message until today's step goal is reached. */
class HourlyGoalWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        try {
            if (!Notifier.hourlyEnabled(ctx)) return Result.success()
            val hour = LocalDateTime.now().hour
            if (hour < 7 || hour > 21) return Result.success()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return Result.success()

            val profile = ProfileStore(ctx).load()
            val today = LocalDate.now().toString()
            val sensorPrefs = ctx.getSharedPreferences("steps", Context.MODE_PRIVATE)
            val fromSensor = if (sensorPrefs.getString("date", "") == today) sensorPrefs.getLong("today", 0L) else 0L
            val appPrefs = ctx.getSharedPreferences("goalcheck", Context.MODE_PRIVATE)
            val fromApp = if (appPrefs.getString("date", "") == today) appPrefs.getLong("steps", 0L) else 0L
            val steps = maxOf(fromSensor, fromApp)
            val left = profile.stepGoal - steps
            if (left <= 0) return Result.success() // goal reached: no more reminders today

            val lines = if (Settings.savedLang(ctx) == "ta") Notifier.hourlyTa else Notifier.hourlyEn
            val idx = (LocalDate.now().dayOfYear + hour) % lines.size
            var message = lines[idx].format(left)
            if (profile.name.isNotBlank()) message = profile.name + ", " + message

            Notifier.createChannel(ctx)
            val pending = PendingIntent.getActivity(
                ctx, 2,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_fit)
                .setContentTitle("FIT TO FIT")
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(pending)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(2003, n)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return Result.success()
        }
        return Result.success()
    }
}
