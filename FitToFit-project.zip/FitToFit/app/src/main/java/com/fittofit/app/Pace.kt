package com.fittofit.app

/** Pace and speed helpers for walks, runs and rides. */
object Pace {
    /** "5:30 min/km", or "—" when there is no distance. */
    fun pace(km: Double, seconds: Long): String {
        if (km < 0.05 || seconds <= 0) return "—"
        val s = (seconds / km).toLong()
        return "%d:%02d min/km".format(s / 60, s % 60)
    }

    /** "10.9 km/h", or "—". */
    fun speed(km: Double, seconds: Long): String {
        if (km <= 0.0 || seconds <= 0) return "—"
        return "%.1f km/h".format(km / (seconds / 3600.0))
    }

    fun paceShort(km: Double, seconds: Long): String {
        if (km < 0.05 || seconds <= 0) return "--:--"
        val s = (seconds / km).toLong()
        return "%d:%02d".format(s / 60, s % 60)
    }

    fun speedShort(km: Double, seconds: Long): String =
        if (km <= 0.0 || seconds <= 0) "0.0" else "%.1f".format(km / (seconds / 3600.0))
}
