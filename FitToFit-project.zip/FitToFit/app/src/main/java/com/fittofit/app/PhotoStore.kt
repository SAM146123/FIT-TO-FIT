package com.fittofit.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Keeps the user's profile picture as a small 128px JPEG saved as text.
 * Because it is small, the same picture can be shown to friends without needing file storage.
 */
object PhotoStore {
    private const val PREF = "photo"
    private const val KEY = "thumb"
    private const val SIZE = 128

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun thumbBase64(ctx: Context): String = prefs(ctx).getString(KEY, "") ?: ""

    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(KEY).apply()
    }

    fun decodeBase64(b64: String): Bitmap? {
        if (b64.isBlank()) return null
        return try {
            val bytes = Base64.decode(b64, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    /** Saves a picture we already have (for example the Google account photo) as the profile picture. */
    fun saveBitmap(ctx: Context, bmp: Bitmap): Boolean {
        return try {
            val side = min(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, SIZE, SIZE, true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            prefs(ctx).edit().putString(KEY, Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** A picture for a post: at most 640px on the long side, JPEG, saved as text (small enough for the free database). */
    fun postPhoto(ctx: Context, uri: Uri): String {
        return try {
            val bmp = decode(ctx, uri) ?: return ""
            val scale = 640f / max(bmp.width, bmp.height)
            val b = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true) else bmp
            var q = 72
            var bytes: ByteArray
            do {
                val out = ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, q, out)
                bytes = out.toByteArray()
                q -= 12
            } while (bytes.size > 180_000 && q > 30)
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    /** Reads the picked picture, crops it to a square and saves it. Returns true on success. */
    fun saveFrom(ctx: Context, uri: Uri): Boolean {
        return try {
            val bmp = decode(ctx, uri) ?: return false
            val side = min(bmp.width, bmp.height)
            val x = (bmp.width - side) / 2
            val y = (bmp.height - side) / 2
            val square = Bitmap.createBitmap(bmp, x, y, side, side)
            val scaled = Bitmap.createScaledBitmap(square, SIZE, SIZE, true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            val text = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            prefs(ctx).edit().putString(KEY, text).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun decode(ctx: Context, uri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(ctx.contentResolver, uri)
            return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val scale = 512f / max(w, h)
                if (scale < 1f) {
                    decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
                }
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
}
