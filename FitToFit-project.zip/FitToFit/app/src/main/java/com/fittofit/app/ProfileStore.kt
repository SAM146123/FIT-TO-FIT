package com.fittofit.app

import android.content.Context

data class Profile(
    val name: String = "",
    val age: Int = 0,
    val heightCm: Int = 0,
    val weightKg: Int = 0,
    val stepGoal: Int = 10_000,
    /** "M", "F" or "" (not set) */
    val sex: String = "",
    /** Country name, used for the diet plan */
    val country: String = "",
    /** "lose", "maintain" or "gain" */
    val goal: String = "maintain",
    /** true = vegetarian (no meat, fish or eggs) */
    val veg: Boolean = false,
    /** Google account the person signed in with (shown in the profile) */
    val email: String = "",
    /** Health conditions chosen by the person, comma separated ids (diabetes,bp,...) */
    val conditions: String = ""
)

/** Saves the user's own profile on the phone. */
class ProfileStore(context: Context) {
    private val p = context.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun load() = Profile(
        name = p.getString("name", "") ?: "",
        age = p.getInt("age", 0),
        heightCm = p.getInt("height", 0),
        weightKg = p.getInt("weight", 0),
        stepGoal = p.getInt("goal", 10_000),
        sex = p.getString("sex", "") ?: "",
        country = p.getString("country", "") ?: "",
        goal = p.getString("diet_goal", "maintain") ?: "maintain",
        veg = p.getBoolean("veg", false),
        email = p.getString("email", "") ?: "",
        conditions = p.getString("conditions", "") ?: ""
    )

    fun save(x: Profile) {
        p.edit()
            .putString("name", x.name)
            .putInt("age", x.age)
            .putInt("height", x.heightCm)
            .putInt("weight", x.weightKg)
            .putInt("goal", x.stepGoal)
            .putString("sex", x.sex)
            .putString("country", x.country)
            .putString("diet_goal", x.goal)
            .putBoolean("veg", x.veg)
            .putString("email", x.email)
            .putString("conditions", x.conditions)
            .apply()
    }
}
