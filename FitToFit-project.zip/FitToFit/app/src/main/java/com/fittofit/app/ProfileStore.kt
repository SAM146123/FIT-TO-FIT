package com.fittofit.app

import android.content.Context

data class Profile(
    val name: String = "",
    val age: Int = 0,
    val heightCm: Int = 0,
    val weightKg: Int = 0,
    val stepGoal: Int = 10_000,
    /** "M", "F" or "" (not set) */
    val sex: String = ""
)

/** Saves the user's own profile on the phone. */
class ProfileStore(context: Context) {
    private val p = context.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun load() = Profile(
        name = p.getString("name", "") ?: "",
        age = p.getInt("age", 0),
        heightCm = p.getInt("height", 0),
        weightKg = p.getInt("weight", 0),
        stepGoal = p.getInt("goal", 10_000),
        sex = p.getString("sex", "") ?: ""
    )

    fun save(x: Profile) {
        p.edit()
            .putString("name", x.name)
            .putInt("age", x.age)
            .putInt("height", x.heightCm)
            .putInt("weight", x.weightKg)
            .putInt("goal", x.stepGoal)
            .putString("sex", x.sex)
            .apply()
    }
}
