package com.fittofit.app

import java.time.LocalDate

/** One motivation line per day, in the chosen language. */
object Quotes {
    private val en = listOf(
        "Small steps every day lead to big changes.",
        "Your only competition is who you were yesterday.",
        "Strong body, strong mind. Keep moving!",
        "Don't wish for it. Walk for it.",
        "Every step is progress, no matter how small.",
        "You are stronger than you think.",
        "Today's effort is tomorrow's strength.",
        "Consistency beats intensity. Show up today!",
        "Make your health your habit.",
        "The best workout is the one you actually do.",
        "Push yourself, because nobody else will do it for you.",
        "Energy grows when you move. Let's go!",
        "One more step. One more day. One more win.",
        "Fitness is a journey, enjoy every step."
    )
    private val ta = listOf(
        "தினமும் சிறு அடிகள் பெரிய மாற்றத்தைத் தரும்.",
        "உங்கள் ஒரே போட்டி நேற்றைய நீங்கள்தான்.",
        "வலிமையான உடல், வலிமையான மனம். தொடர்ந்து நகருங்கள்!",
        "ஆசைப்படாதீர்கள், நடந்து சாதியுங்கள்.",
        "ஒவ்வொரு அடியும் முன்னேற்றமே, எவ்வளவு சிறியதாக இருந்தாலும்.",
        "நீங்கள் நினைப்பதைவிட வலிமையானவர்.",
        "இன்றைய முயற்சி நாளைய பலம்.",
        "தொடர்ச்சியே வெற்றி. இன்றும் வாருங்கள்!",
        "ஆரோக்கியத்தை உங்கள் பழக்கமாக்குங்கள்.",
        "சிறந்த உடற்பயிற்சி என்பது நீங்கள் உண்மையில் செய்வதுதான்.",
        "உங்களை நீங்களே ஊக்குவியுங்கள், வேறு யாரும் செய்யமாட்டார்கள்.",
        "நகர்ந்தால் சக்தி பெருகும். புறப்படுங்கள்!",
        "இன்னும் ஒரு அடி. இன்னும் ஒரு நாள். இன்னும் ஒரு வெற்றி.",
        "உடல்நலம் ஒரு பயணம், ஒவ்வொரு அடியையும் ரசியுங்கள்."
    )
    private val hi = listOf(
        "रोज़ के छोटे कदम बड़े बदलाव लाते हैं।",
        "आपकी एकमात्र प्रतियोगिता कल का आप हैं।",
        "मज़बूत शरीर, मज़बूत मन। चलते रहिए!",
        "सिर्फ़ चाहिए मत, चलकर पाइए।",
        "हर कदम प्रगति है, चाहे कितना भी छोटा हो।",
        "आप जितना सोचते हैं, उससे ज़्यादा मज़बूत हैं।",
        "आज की मेहनत कल की ताकत है।",
        "निरंतरता ही सफलता है। आज भी आइए!",
        "सेहत को अपनी आदत बनाइए।",
        "सबसे अच्छी कसरत वही है जो आप सच में करते हैं।",
        "खुद को आगे बढ़ाइए, कोई और यह नहीं करेगा।",
        "चलने से ऊर्जा बढ़ती है। चलिए!",
        "एक और कदम। एक और दिन। एक और जीत।",
        "फिटनेस एक सफ़र है, हर कदम का आनंद लीजिए।"
    )

    fun today(lang: String): String {
        val list = when (lang) {
            "ta" -> ta
            "hi" -> hi
            else -> en
        }
        return list[LocalDate.now().dayOfYear % list.size]
    }
}
