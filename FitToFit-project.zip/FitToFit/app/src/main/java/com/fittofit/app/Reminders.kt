package com.fittofit.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** One medicine the person wants to be reminded about every day. */
data class Med(val id: Long, val name: String, val hour: Int, val minute: Int)

/** Medicine reminders, saved only on this phone. */
object MedStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("meds", Context.MODE_PRIVATE)

    fun list(ctx: Context): List<Med> =
        (prefs(ctx).getString("list", "") ?: "").split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val f = line.split("|", limit = 4)
            if (f.size < 4) null else Med(
                f[0].toLongOrNull() ?: return@mapNotNull null,
                f[3],
                f[1].toIntOrNull() ?: 8,
                f[2].toIntOrNull() ?: 0
            )
        }.sortedBy { it.hour * 60 + it.minute }

    private fun save(ctx: Context, items: List<Med>) {
        prefs(ctx).edit().putString(
            "list",
            items.joinToString("\n") { "${it.id}|${it.hour}|${it.minute}|${it.name.replace("|", " ").replace("\n", " ")}" }
        ).apply()
    }

    fun add(ctx: Context, name: String, hour: Int, minute: Int): List<Med> {
        val med = Med(System.currentTimeMillis(), name.trim(), hour, minute)
        save(ctx, list(ctx) + med)
        schedule(ctx, med)
        return list(ctx)
    }

    fun remove(ctx: Context, id: Long): List<Med> {
        save(ctx, list(ctx).filter { it.id != id })
        try {
            WorkManager.getInstance(ctx).cancelUniqueWork("med_$id")
        } catch (e: Exception) {
            // ignore
        }
        return list(ctx)
    }

    /** Daily reminder at hour:minute (Android may move it a few minutes to save battery). */
    fun schedule(ctx: Context, med: Med) {
        val now = LocalDateTime.now()
        var first = now.toLocalDate().atTime(med.hour, med.minute)
        if (!first.isAfter(now)) first = first.plusDays(1)
        val delay = Duration.between(now, first).toMillis()
        val request = PeriodicWorkRequestBuilder<MedWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("name" to med.name, "id" to med.id))
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("med_${med.id}", ExistingPeriodicWorkPolicy.KEEP, request)
    }

    /** Makes sure every saved reminder is scheduled (safe to call at every app start). */
    fun scheduleAll(ctx: Context) {
        try {
            list(ctx).forEach { schedule(ctx, it) }
        } catch (e: Exception) {
            // ignore
        }
    }
}

private fun canNotify(ctx: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

private fun openAppIntent(ctx: Context, code: Int): PendingIntent = PendingIntent.getActivity(
    ctx, code,
    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

class MedWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        try {
            if (!canNotify(ctx)) return Result.success()
            val name = inputData.getString("name") ?: return Result.success()
            val id = inputData.getLong("id", 0L)
            val ta = Settings.savedLang(ctx) == "ta"
            val text = if (ta) "💊 மருந்து சாப்பிட வேண்டிய நேரம்: $name" else "💊 Time for your medicine: $name"
            Notifier.createChannel(ctx)
            val n = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_fit)
                .setContentTitle(if (ta) "மருந்து நினைவூட்டல்" else "Medicine reminder")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(openAppIntent(ctx, 3))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            NotificationManagerCompat.from(ctx).notify(4000 + (id % 1000).toInt(), n)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return Result.success()
        }
        return Result.success()
    }
}

/** Every 2 hours (8 AM - 8 PM): reminds the person to drink water until the daily goal is reached. */
class WaterWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        try {
            if (!Notifier.waterEnabled(ctx)) return Result.success()
            val hour = LocalDateTime.now().hour
            if (hour < 8 || hour > 20) return Result.success()
            if (!canNotify(ctx)) return Result.success()
            val profile = ProfileStore(ctx).load()
            val goal = Notifier.waterGoalMl(profile)
            val drunk = LogStore(ctx).waterMl()
            if (drunk >= goal) return Result.success()
            val left = goal - drunk
            val ta = Settings.savedLang(ctx) == "ta"
            val lines = if (ta) listOf(
                "💧 தண்ணீர் குடிக்கும் நேரம்! இன்னும் %d மிலி மீதம்.",
                "💧 ஒரு டம்ளர் தண்ணீர் குடியுங்கள். இன்றைய இலக்குக்கு %d மிலி மீதம்.",
                "💧 உடல் நீர்ச்சத்து முக்கியம். இன்னும் %d மிலி குடியுங்கள்."
            ) else listOf(
                "💧 Time to drink water! %d ml left for today.",
                "💧 Have a glass of water. %d ml to reach today's goal.",
                "💧 Stay hydrated. %d ml more to go."
            )
            var text = lines[(LocalDate.now().dayOfYear + hour) % lines.size].format(left)
            if (profile.name.isNotBlank()) text = profile.name + ", " + text
            Notifier.createChannel(ctx)
            val n = NotificationCompat.Builder(ctx, Notifier.CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_fit)
                .setContentTitle("FIT TO FIT")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(openAppIntent(ctx, 4))
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(2004, n)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return Result.success()
        }
        return Result.success()
    }
}

/** Home screen widget: today's steps and the goal. Tapping it opens the app. */
class StepsWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            try {
                appWidgetManager.updateAppWidget(id, build(context))
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    companion object {
        fun todaySteps(ctx: Context): Long {
            val today = LocalDate.now().toString()
            val sensor = ctx.getSharedPreferences("steps", Context.MODE_PRIVATE)
            val a = if (sensor.getString("date", "") == today) sensor.getLong("today", 0L) else 0L
            val app = ctx.getSharedPreferences("goalcheck", Context.MODE_PRIVATE)
            val b = if (app.getString("date", "") == today) app.getLong("steps", 0L) else 0L
            return maxOf(a, b)
        }

        fun build(ctx: Context): RemoteViews {
            val goal = ProfileStore(ctx).load().stepGoal.coerceAtLeast(1)
            val steps = todaySteps(ctx)
            val ta = Settings.savedLang(ctx) == "ta"
            val views = RemoteViews(ctx.packageName, R.layout.widget_steps)
            views.setTextViewText(R.id.widget_steps, String.format(java.util.Locale.US, "%,d", steps))
            val pct = ((steps * 100) / goal).toInt().coerceIn(0, 100)
            val goalText = if (ta) "இலக்கு " + goal + " அடிகள் · " + pct + "%" else "of " + goal + " steps · " + pct + "%"
            views.setTextViewText(R.id.widget_goal, goalText)
            views.setProgressBar(R.id.widget_bar, 100, pct, false)
            views.setOnClickPendingIntent(R.id.widget_root, openAppIntent(ctx, 9))
            return views
        }

        /** Redraws every widget the person has put on the home screen. */
        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, StepsWidget::class.java))
                if (ids.isEmpty()) return
                for (id in ids) mgr.updateAppWidget(id, build(ctx))
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
