package com.fittofit.app

import android.content.Context
import java.io.File

/** Saves the GPS path of each outdoor workout on the phone. */
object RouteStore {
    private fun file(ctx: Context, startMs: Long) = File(File(ctx.filesDir, "routes").apply { mkdirs() }, "route_$startMs.csv")

    fun save(ctx: Context, startMs: Long, points: List<Pair<Double, Double>>) {
        try {
            file(ctx, startMs).writeText(points.joinToString("\n") { "%.6f,%.6f".format(java.util.Locale.US, it.first, it.second) })
        } catch (e: Exception) {
            // the workout is still saved without its map
        }
    }

    fun load(ctx: Context, startMs: Long): List<Pair<Double, Double>> = try {
        file(ctx, startMs).readLines().mapNotNull { l ->
            val f = l.split(",")
            val a = f.getOrNull(0)?.toDoubleOrNull()
            val b = f.getOrNull(1)?.toDoubleOrNull()
            if (a != null && b != null) a to b else null
        }
    } catch (e: Exception) {
        emptyList()
    }
}
