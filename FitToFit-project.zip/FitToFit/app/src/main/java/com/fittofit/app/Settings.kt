package com.fittofit.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App-wide choices: theme, language and the link people get when you share the app. */
object Settings {
    const val DEFAULT_LINK = "https://github.com/SAM146123/FIT-TO-FIT/releases/latest"

    /** 0 = follow phone, 1 = light, 2 = dark */
    var themeMode by mutableIntStateOf(0)
        private set

    /** "en", "ta" or "hi" */
    var lang by mutableStateOf("en")
        private set

    var appLink by mutableStateOf(DEFAULT_LINK)
        private set

    private var started = false
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (started) return
        started = true
        val p = prefs(ctx)
        themeMode = p.getInt("theme", 0)
        lang = p.getString("lang", "en") ?: "en"
        appLink = p.getString("link", DEFAULT_LINK)?.ifBlank { DEFAULT_LINK } ?: DEFAULT_LINK
    }

    fun setTheme(ctx: Context, mode: Int) {
        themeMode = mode
        prefs(ctx).edit().putInt("theme", mode).apply()
    }

    fun setLang(ctx: Context, code: String) {
        lang = code
        prefs(ctx).edit().putString("lang", code).apply()
    }

    fun setLink(ctx: Context, link: String) {
        val v = link.trim().ifBlank { DEFAULT_LINK }
        appLink = v
        prefs(ctx).edit().putString("link", v).apply()
    }

    /** Language chosen by the user, readable from background workers too. */
    fun savedLang(ctx: Context): String = prefs(ctx).getString("lang", "en") ?: "en"
}
