package com.fittofit.app

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.time.DayOfWeek
import java.time.LocalDate

const val MAX_FRIENDS = 500

data class Friend(
    val uid: String,
    val name: String,
    val steps: Long = 0,
    val weekSteps: Long = 0,
    val kcal: Int = 0,
    val distanceKm: Double = 0.0,
    val activeMin: Int = 0,
    val streak: Int = 0,
    val level: Int = 1
)

data class SocialState(
    val signedIn: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val message: String? = null,
    val myCode: String = "",
    val friends: List<Friend> = emptyList(),
    val friendCount: Int = 0
)

fun friendlyError(e: Exception): String = when {
    e is IllegalArgumentException -> e.message ?: "Something went wrong."
    e is FirebaseNetworkException -> "No internet connection. Please try again."
    e is FirebaseAuthException -> when (e.errorCode) {
        "ERROR_INVALID_EMAIL" -> "That email address is not valid."
        "ERROR_WEAK_PASSWORD" -> "Password is too weak. Use at least 6 characters."
        "ERROR_EMAIL_ALREADY_IN_USE" -> "This email already has an account. Try logging in."
        "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "ERROR_USER_NOT_FOUND" -> "Wrong email or password."
        "ERROR_OPERATION_NOT_ALLOWED" -> "Email/Password sign-in is not enabled in Firebase."
        "ERROR_TOO_MANY_REQUESTS" -> "Too many attempts. Please wait a bit and try again."
        else -> e.message ?: "Sign-in failed."
    }
    e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ->
        "Permission denied. Publish the Firestore rules in the Firebase console."
    e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.UNAVAILABLE ->
        "Can't reach the server. Check your internet."
    else -> e.message ?: "Something went wrong."
}

/** Friends + leaderboard data stored in Firebase (Authentication + Firestore). */
class SocialRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private val uid: String? get() = auth.currentUser?.uid
    val signedIn: Boolean get() = auth.currentUser != null

    private fun users() = db.collection("users")

    private suspend fun uniqueCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        repeat(8) {
            val c = (1..6).map { alphabet.random() }.joinToString("")
            val taken = users().whereEqualTo("code", c).limit(1).get().await()
            if (taken.isEmpty) return c
        }
        throw IllegalArgumentException("Could not create a friend code. Please try again.")
    }

    suspend fun signUp(name: String, email: String, password: String): String {
        val res = auth.createUserWithEmailAndPassword(email, password).await()
        val id = res.user?.uid ?: throw IllegalArgumentException("Sign-up failed.")
        val code = uniqueCode()
        users().document(id).set(
            mapOf("name" to name, "code" to code, "created" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return code
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }

    fun signOut() = auth.signOut()

    /** Returns this user's friend code (creates one if missing). */
    suspend fun myCode(): String {
        val id = uid ?: return ""
        val doc = users().document(id).get().await()
        val existing = doc.getString("code")
        if (!existing.isNullOrBlank()) return existing
        val code = uniqueCode()
        users().document(id).set(mapOf("code" to code), SetOptions.merge()).await()
        return code
    }

    suspend fun pushStats(stats: Map<String, Any>) {
        val id = uid ?: return
        users().document(id).set(stats + ("updated" to FieldValue.serverTimestamp()), SetOptions.merge()).await()
    }

    private fun toFriend(d: DocumentSnapshot): Friend {
        val today = LocalDate.now().toString()
        val monday = LocalDate.now().with(DayOfWeek.MONDAY).toString()
        val fresh = d.getString("stepsDate") == today
        val weekFresh = d.getString("weekKey") == monday
        return Friend(
            uid = d.id,
            name = d.getString("name") ?: "Friend",
            steps = if (fresh) d.getLong("steps") ?: 0L else 0L,
            weekSteps = if (weekFresh) d.getLong("weekSteps") ?: 0L else 0L,
            kcal = if (fresh) (d.getLong("kcal") ?: 0L).toInt() else 0,
            distanceKm = if (fresh) d.getDouble("distanceKm") ?: 0.0 else 0.0,
            activeMin = if (fresh) (d.getLong("activeMin") ?: 0L).toInt() else 0,
            streak = (d.getLong("streak") ?: 0L).toInt(),
            level = (d.getLong("level") ?: 1L).toInt()
        )
    }

    /** Returns (number of friends, friends' current stats). */
    suspend fun loadFriends(): Pair<Int, List<Friend>> {
        val id = uid ?: return 0 to emptyList()
        val ids = users().document(id).collection("friends").get().await().documents.map { it.id }
        val result = mutableListOf<Friend>()
        ids.chunked(30).forEach { chunk ->
            val snap = users().whereIn(FieldPath.documentId(), chunk).get().await()
            snap.documents.forEach { result += toFriend(it) }
        }
        return ids.size to result
    }

    /** Adds a friend by their code (both people become friends). Returns the friend's name. */
    suspend fun addFriendByCode(rawCode: String, currentCount: Int): String {
        val me = uid ?: throw IllegalArgumentException("Please log in first.")
        val code = rawCode.trim().uppercase()
        if (code.length != 6) throw IllegalArgumentException("A friend code has 6 letters/numbers.")
        if (currentCount >= MAX_FRIENDS) throw IllegalArgumentException("You have reached the limit of $MAX_FRIENDS friends.")

        val found = users().whereEqualTo("code", code).limit(1).get().await()
        val other = found.documents.firstOrNull() ?: throw IllegalArgumentException("No user found with that code.")
        if (other.id == me) throw IllegalArgumentException("That's your own code!")

        val already = users().document(me).collection("friends").document(other.id).get().await()
        if (already.exists()) throw IllegalArgumentException("You are already friends.")

        val myName = users().document(me).get().await().getString("name") ?: "Friend"
        val otherName = other.getString("name") ?: "Friend"

        val batch = db.batch()
        batch.set(
            users().document(me).collection("friends").document(other.id),
            mapOf("name" to otherName, "since" to FieldValue.serverTimestamp())
        )
        batch.set(
            users().document(other.id).collection("friends").document(me),
            mapOf("name" to myName, "since" to FieldValue.serverTimestamp())
        )
        batch.commit().await()
        return otherName
    }

    suspend fun removeFriend(friendUid: String) {
        val me = uid ?: return
        val batch = db.batch()
        batch.delete(users().document(me).collection("friends").document(friendUid))
        batch.delete(users().document(friendUid).collection("friends").document(me))
        batch.commit().await()
    }
}
