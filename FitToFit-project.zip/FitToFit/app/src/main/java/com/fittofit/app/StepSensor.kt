package com.fittofit.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/**
 * Live step count from the phone's own step-counter sensor.
 * The sensor counts steps since the phone booted, so we keep a daily baseline.
 */
class StepSensor(context: Context) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
    private val prefs = context.getSharedPreferences("steps", Context.MODE_PRIVATE)

    val available: Boolean get() = sensor != null

    private val _today = MutableStateFlow(0L)
    val today: StateFlow<Long> = _today.asStateFlow()

    /** Raw counter since boot (-1 until the first reading). */
    private val _raw = MutableStateFlow(-1L)
    val raw: StateFlow<Long> = _raw.asStateFlow()

    init {
        if (prefs.getString("date", "") == LocalDate.now().toString()) {
            _today.value = prefs.getLong("today", 0L)
        }
    }

    fun start() {
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    fun stop() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val total = event.values[0].toLong()
        val d = LocalDate.now().toString()
        var base = prefs.getLong("base", total)
        var saved = prefs.getLong("saved", 0L)
        val last = prefs.getLong("last", total)

        if (prefs.getString("date", "") != d) {
            base = total          // new day
            saved = 0L
        } else if (total < last) {
            saved += (last - base) // phone rebooted, keep today's earlier steps
            base = total
        }
        val today = saved + (total - base)

        prefs.edit()
            .putString("date", d)
            .putLong("base", base)
            .putLong("saved", saved)
            .putLong("last", total)
            .putLong("today", today)
            .apply()

        _raw.value = total
        _today.value = today
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
