package com.fittofit.app

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/* ======================= crash log ======================= */

/** Saves the last crash on this phone so the person can share it. Nothing is sent automatically. */
object CrashLog {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crash", Context.MODE_PRIVATE)

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val text = android.util.Log.getStackTraceString(error).take(6000)
                prefs(app).edit().putLong("time", System.currentTimeMillis()).putString("text", text).commit()
            } catch (e: Exception) {
                // never block the crash
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun time(ctx: Context): Long = prefs(ctx).getLong("time", 0L)
    fun text(ctx: Context): String = prefs(ctx).getString("text", "") ?: ""
    fun clear(ctx: Context) = prefs(ctx).edit().clear().apply()
}

/* ======================= update check ======================= */

data class UpdateInfo(val available: Boolean, val url: String)

/** Looks at the "latest" release of the app on GitHub and says if it is newer than what is installed. */
object UpdateChecker {
    const val APK_URL = "https://github.com/SAM146123/FIT-TO-FIT/releases/latest/download/FitToFit.apk"
    private const val API = "https://api.github.com/repos/SAM146123/FIT-TO-FIT/releases/tags/latest"

    fun installedAt(ctx: Context): Long = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
    } catch (e: Exception) {
        0L
    }

    /** Call from a background thread. Returns null when it could not find out. */
    fun check(ctx: Context): UpdateInfo? {
        val conn = URL(API).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "FitToFit-app")
            if (conn.responseCode !in 200..299) return null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val assets = json.optJSONArray("assets") ?: return null
            var newest = 0L
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (!a.optString("name").endsWith(".apk")) continue
                val ms = java.time.Instant.parse(a.optString("updated_at")).toEpochMilli()
                if (ms > newest) newest = ms
            }
            if (newest == 0L) return null
            // the installed build was put on the phone AFTER its release file was uploaded
            UpdateInfo(newest > installedAt(ctx) + 120_000L, APK_URL)
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}

/* ======================= cloud backup ======================= */

/** Saves a copy of the person's data in their own private Firestore folder, and brings it back. */
object BackupManager {
    // not included: the Gemini key, Google sign-in settings, the step sensor counters
    private val files = listOf("profile", "logs", "meds", "healthlog", "notif", "badges", "settings")

    val signedIn: Boolean get() = FirebaseAuth.getInstance().currentUser != null

    private fun doc() = FirebaseFirestore.getInstance()
        .collection("users").document(FirebaseAuth.getInstance().currentUser?.uid ?: "none")
        .collection("backup").document("latest")

    private fun dump(ctx: Context, name: String): JSONObject {
        val out = JSONObject()
        for ((key, value) in ctx.getSharedPreferences(name, Context.MODE_PRIVATE).all) {
            val e = JSONObject()
            when (value) {
                is String -> { e.put("t", "s"); e.put("v", value) }
                is Int -> { e.put("t", "i"); e.put("v", value) }
                is Long -> { e.put("t", "l"); e.put("v", value) }
                is Boolean -> { e.put("t", "b"); e.put("v", value) }
                is Float -> { e.put("t", "f"); e.put("v", value.toDouble()) }
                is Set<*> -> {
                    e.put("t", "ss")
                    e.put("v", JSONArray(value.map { it.toString() }))
                }
                else -> continue
            }
            out.put(key, e)
        }
        return out
    }

    private fun load(ctx: Context, name: String, data: JSONObject) {
        val ed = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
        ed.clear()
        val keys = data.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val e = data.getJSONObject(k)
            when (e.optString("t")) {
                "s" -> ed.putString(k, e.optString("v"))
                "i" -> ed.putInt(k, e.optInt("v"))
                "l" -> ed.putLong(k, e.optLong("v"))
                "b" -> ed.putBoolean(k, e.optBoolean("v"))
                "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                "ss" -> {
                    val arr = e.getJSONArray("v")
                    ed.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                }
            }
        }
        ed.apply()
    }

    suspend fun backup(ctx: Context) {
        if (!signedIn) throw IllegalStateException("Please sign up or log in on the Friends tab first.")
        val all = JSONObject()
        for (f in files) all.put(f, dump(ctx, f))
        val text = all.toString()
        if (text.length > 900_000) throw IllegalStateException("Your data is too big to back up.")
        doc().set(mapOf("json" to text, "updated" to FieldValue.serverTimestamp())).await()
    }

    /** Returns false when there is no backup yet. */
    suspend fun restore(ctx: Context): Boolean {
        if (!signedIn) throw IllegalStateException("Please sign up or log in on the Friends tab first.")
        val snap = doc().get().await()
        val text = snap.getString("json") ?: return false
        val all = JSONObject(text)
        for (f in files) {
            val part = all.optJSONObject(f) ?: continue
            load(ctx, f, part)
        }
        return true
    }
}

/* ======================= sugar and blood pressure log ======================= */

/** type is "sugar" (a = mg/dL, b = 0 fasting / 1 after meal) or "bp" (a = systolic, b = diastolic). */
data class LogEntry(val type: String, val ms: Long, val a: Int, val b: Int, val note: String)

object HealthLogStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("healthlog", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<LogEntry> =
        (prefs(ctx).getString("items", "") ?: "").split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val f = line.split("|", limit = 5)
            if (f.size < 4) null else LogEntry(
                f[0], f[1].toLongOrNull() ?: return@mapNotNull null,
                f[2].toIntOrNull() ?: 0, f[3].toIntOrNull() ?: 0, f.getOrNull(4) ?: ""
            )
        }.sortedBy { it.ms }

    fun list(ctx: Context, type: String): List<LogEntry> = all(ctx).filter { it.type == type }

    private fun save(ctx: Context, items: List<LogEntry>) {
        prefs(ctx).edit().putString(
            "items",
            items.takeLast(400).joinToString("\n") {
                "${it.type}|${it.ms}|${it.a}|${it.b}|${it.note.replace("|", " ").replace("\n", " ")}"
            }
        ).apply()
    }

    fun add(ctx: Context, type: String, a: Int, b: Int, note: String = "") {
        save(ctx, all(ctx) + LogEntry(type, System.currentTimeMillis(), a, b, note))
    }

    fun remove(ctx: Context, ms: Long) = save(ctx, all(ctx).filter { it.ms != ms })
}

/* ======================= AI health assistant ======================= */

/** Chat with Google's Gemini AI using the person's own free key (the same key as the food scan). */
object AiCoach {
    private val models = listOf("gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash")

    /** Call from a background thread. history = list of ("user" or "model", text). */
    fun ask(apiKey: String, system: String, history: List<Pair<String, String>>, question: String): String {
        if (apiKey.isBlank()) throw FoodAiException("Please add your Gemini key first.")
        val contents = JSONArray()
        for ((role, text) in history.takeLast(10)) {
            contents.put(
                JSONObject().put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            put("contents", contents)
            put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 900))
        }.toString()

        var lastError = "Could not reach the AI service."
        for (model in models) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20_000
                conn.readTimeout = 60_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey)
                conn.outputStream.use { it.write(body.toByteArray()) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                when {
                    code in 200..299 -> return parse(text)
                    code == 400 || code == 403 -> throw FoodAiException("The Gemini key was not accepted. Check that you pasted it fully.")
                    code == 429 -> throw FoodAiException("Free limit reached for now. Please try again in a minute.")
                    code == 404 -> lastError = "AI model not found."
                    else -> lastError = "AI service error ($code)."
                }
            } catch (e: FoodAiException) {
                throw e
            } catch (e: java.io.IOException) {
                throw FoodAiException("No internet connection.")
            } finally {
                conn.disconnect()
            }
        }
        throw FoodAiException(lastError)
    }

    private fun parse(response: String): String {
        try {
            val parts = JSONObject(response).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            var text = ""
            for (i in 0 until parts.length()) text += parts.getJSONObject(i).optString("text")
            text = text.replace("**", "").replace("##", "").trim()
            if (text.isBlank()) throw FoodAiException("No answer. Please ask in a different way.")
            return text
        } catch (e: FoodAiException) {
            throw e
        } catch (e: Exception) {
            throw FoodAiException("No answer. Please ask in a different way.")
        }
    }

    fun systemPrompt(p: Profile, stepsToday: Long, tamil: Boolean): String {
        val conditions = p.conditions.split(",").filter { it.isNotBlank() }.joinToString(", ").ifBlank { "none told" }
        return "You are a friendly health and fitness helper inside the FIT TO FIT app. " +
            "Give short, practical, safe answers in simple words (under 150 words). Use short lines or numbered steps. " +
            (if (tamil) "Reply in Tamil. " else "Reply in the language the person writes in. ") +
            "Never diagnose. Never tell the person to stop or change a medicine. " +
            "For serious or lasting symptoms, say to see a doctor. For emergencies, say to call the local emergency number now. " +
            "Food advice should suit Indian home cooking. " +
            "About the person: age ${p.age}, sex ${p.sex}, height ${p.heightCm} cm, weight ${p.weightKg} kg, " +
            "goal ${p.goal}, country ${p.country.ifBlank { "India" }}, " + (if (p.veg) "vegetarian" else "eats non-veg") +
            ", health conditions: $conditions, steps today: $stepsToday, daily step goal: ${p.stepGoal}."
    }
}
