package com.fittofit.app

import android.content.Context
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * English voice instructions (Android text-to-speech).
 * The user turns this on or off; nothing is spoken while it is off.
 */
class VoiceCoach(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("voice", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<Pair<String, Boolean>>()

    private val _enabled = MutableStateFlow(prefs.getBoolean("on", false))
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    private val _problem = MutableStateFlow<String?>(null)
    val problem: StateFlow<String?> = _problem.asStateFlow()

    fun setEnabled(on: Boolean) {
        prefs.edit().putBoolean("on", on).apply()
        _enabled.value = on
        if (on) {
            ensure()
            speak("Voice coach is on.", true)
        } else {
            tts?.stop()
            pending.clear()
        }
    }

    private fun ensure() {
        if (tts == null) tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            _problem.value = "Text-to-speech is not available on this phone."
            return
        }
        val result = tts?.setLanguage(Locale.US)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            _problem.value = "English voice data is not installed. Install it in Settings > Text-to-speech."
            return
        }
        tts?.setSpeechRate(0.95f)
        ready = true
        _problem.value = null
        while (pending.isNotEmpty()) {
            val (text, interrupt) = pending.removeFirst()
            say(text, interrupt)
        }
    }

    private fun say(text: String, interrupt: Boolean) {
        tts?.speak(
            text,
            if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            null,
            "fit-" + System.nanoTime()
        )
    }

    /** Speaks [text] when the voice coach is on. [interrupt] cuts off whatever is being said. */
    fun speak(text: String, interrupt: Boolean = false) {
        if (!_enabled.value) return
        ensure()
        if (!ready) {
            pending.addLast(text to interrupt)
            while (pending.size > 4) pending.removeFirst()
            return
        }
        say(text, interrupt)
    }

    fun stop() {
        tts?.stop()
        pending.clear()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
