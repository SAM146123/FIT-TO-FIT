package com.fittofit.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Measures walking distance with GPS (more accurate than counting steps). */
@SuppressLint("MissingPermission")
class GpsTracker(context: Context) : LocationListener {

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var last: Location? = null

    var meters = 0.0
        private set
    var active = false
        private set
    var onUpdate: (() -> Unit)? = null

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    /** Returns true when GPS updates started. */
    fun start(): Boolean {
        meters = 0.0
        last = null
        if (!hasPermission()) return false
        return try {
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return false
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, this, Looper.getMainLooper())
            active = true
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        try {
            manager.removeUpdates(this)
        } catch (e: Exception) {
            // ignore
        }
        active = false
    }

    override fun onLocationChanged(location: Location) {
        if (location.hasAccuracy() && location.accuracy > 30f) return
        val prev = last
        if (prev == null) {
            last = location
        } else {
            val d = prev.distanceTo(location)
            // ignore GPS jitter (< 3 m) and impossible jumps (> 80 m in 2 s)
            if (d in 3f..80f) {
                meters += d
                last = location
            }
        }
        onUpdate?.invoke()
    }

    override fun onProviderEnabled(provider: String) = Unit

    override fun onProviderDisabled(provider: String) = Unit

    @Deprecated("Needed for older Android versions")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
}

/**
 * Keeps the app alive while a walk is running, so voice updates and distance
 * tracking continue even when the screen is off.
 */
class WalkService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_fit)
            .setContentTitle("FIT TO FIT")
            .setContentText("Walk in progress - voice updates every 0.5 km")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = 0
                if (Build.VERSION.SDK_INT >= 34 && granted(Manifest.permission.ACTIVITY_RECOGNITION)) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH
                }
                if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                }
                if (type == 0 && Build.VERSION.SDK_INT >= 34) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (type == 0) startForeground(NOTIFICATION_ID, notification)
                else startForeground(NOTIFICATION_ID, notification, type)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Walk in progress", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL = "walk_session"
        private const val NOTIFICATION_ID = 3001

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, WalkService::class.java))
            } catch (e: Exception) {
                // the walk still works while the app is open
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WalkService::class.java))
        }
    }
}
