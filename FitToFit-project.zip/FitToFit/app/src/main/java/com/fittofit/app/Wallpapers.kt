package com.fittofit.app

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/** One wallpaper: either an online photo (url) or a picture the user added (file). */
class Wall(
    val id: String,
    val author: String,
    val thumbUrl: String?,
    val fullUrl: String?,
    val file: File?,
    val thumbB64: String? = null,
    val ownerUid: String? = null,
    val community: Boolean = false
)

/**
 * Free wallpapers.
 * Online photos come from Picsum Photos (free photos from Unsplash, no key needed). A new set of 20 is chosen every day.
 * Pictures added by the user are copied into the app's own folder.
 */
object WallStore {
    private const val PER_DAY = 20
    private const val PAGES = 35

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 40_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "FitToFit/1.0 (wallpapers)")
        return c
    }

    private fun fetchBytes(url: String): ByteArray? {
        val c = open(url)
        return try {
            if (c.responseCode in 200..299) c.inputStream.use { it.readBytes() } else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    /** Today's set. Saved for the day so it also opens without internet after the first load. */
    fun today(ctx: Context): List<Wall> {
        val day = LocalDate.now()
        val dir = File(ctx.filesDir, "wall_daily").apply { mkdirs() }
        val cache = File(dir, "$day.json")
        var text = if (cache.exists()) cache.readText() else ""
        if (text.isBlank()) {
            val page = (day.toEpochDay() % PAGES).toInt() + 1
            val bytes = fetchBytes("https://picsum.photos/v2/list?page=$page&limit=$PER_DAY")
            if (bytes != null) {
                text = String(bytes)
                try {
                    cache.writeText(text)
                    dir.listFiles()?.filter { it.name != cache.name }?.forEach { it.delete() }
                } catch (e: Exception) { }
            }
        }
        if (text.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                Wall(
                    id = "p$id",
                    author = o.optString("author", "Unsplash"),
                    thumbUrl = "https://picsum.photos/id/$id/360/640",
                    fullUrl = "https://picsum.photos/id/$id/2160/3840",
                    file = null
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** The user's own pictures, newest first. */
    fun mine(ctx: Context): List<Wall> {
        val dir = File(ctx.filesDir, "mywalls")
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        return files.map { Wall("m" + it.name, "My picture", null, null, it) }
    }

    /** Copies a picture the user picked into the app folder (shrunk if bigger than 4K). */
    fun addFromUri(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return false
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 3840) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val dir = File(ctx.filesDir, "mywalls").apply { mkdirs() }
            val out = File(dir, "w${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 93, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun remove(w: Wall) {
        try { w.file?.delete() } catch (e: Exception) { }
    }

    private fun decodeSampled(file: File, maxSide: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, b)
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= maxSide) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    /** Small picture for the grid. */
    fun thumb(ctx: Context, w: Wall): Bitmap? {
        w.thumbB64?.let {
            return try {
                val b = Base64.decode(it, Base64.NO_WRAP)
                BitmapFactory.decodeByteArray(b, 0, b.size)
            } catch (e: Exception) { null }
        }
        w.file?.let { return decodeSampled(it, 640) }
        val dir = File(ctx.cacheDir, "wallthumb").apply { mkdirs() }
        val f = File(dir, "${w.id}.jpg")
        if (!(f.exists() && f.length() > 1000)) {
            val bytes = w.thumbUrl?.let { fetchBytes(it) } ?: return null
            try { f.writeBytes(bytes) } catch (e: Exception) { return null }
        }
        return decodeSampled(f, 640)
    }

    /** The full 4K file on the phone (downloaded once). */
    fun fullFile(ctx: Context, w: Wall): File? {
        w.file?.let { return it }
        if (w.community) return CommunityWalls.fullFile(ctx, w)
        val dir = File(ctx.cacheDir, "wallfull").apply { mkdirs() }
        val f = File(dir, "${w.id}.jpg")
        if (f.exists() && f.length() > 5000) return f
        val bytes = w.fullUrl?.let { fetchBytes(it) } ?: return null
        return try {
            dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(5)?.forEach { it.delete() }
            f.writeBytes(bytes)
            f
        } catch (e: Exception) {
            null
        }
    }

    /** Preview picture (half size) so big photos do not use too much memory. */
    fun preview(file: File): Bitmap? = decodeSampled(file, 1920)

    /** which: 1 = home screen, 2 = lock screen, 3 = both. Returns true when it worked. */
    fun setWallpaper(ctx: Context, file: File, which: Int): Boolean {
        return try {
            val bmp = decodeSampled(file, 3840) ?: return false
            val wm = WallpaperManager.getInstance(ctx)
            val flags = when (which) {
                1 -> WallpaperManager.FLAG_SYSTEM
                2 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            wm.setBitmap(bmp, null, true, flags)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Saves a copy into the phone gallery (Pictures/FitToFit). Works on Android 10 and newer. */
    fun saveToGallery(ctx: Context, file: File, name: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "FitToFit_$name.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FitToFit")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            true
        } catch (e: Exception) {
            false
        }
    }
}

/**
 * Pictures shared by users for everyone.
 * Stored in Firebase Firestore (no paid storage needed): a small preview in "wallpapers" and a Full HD copy in "wallpaperFiles".
 * Three reports from different people hide a picture.
 */
object CommunityWalls {
    private const val MAX_RAW_BYTES = 650_000
    private const val HIDE_AFTER = 3

    val signedIn: Boolean get() = FirebaseAuth.getInstance().currentUser != null
    val myUid: String get() = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    private fun db() = FirebaseFirestore.getInstance()

    suspend fun list(): List<Wall> {
        val snap = db().collection("wallpapers").orderBy("created", Query.Direction.DESCENDING).limit(40).get().await()
        return snap.documents.mapNotNull { d ->
            val thumb = d.getString("thumb") ?: return@mapNotNull null
            val reports = (d.get("reporters") as? List<*>)?.size ?: 0
            if (reports >= HIDE_AFTER) return@mapNotNull null
            Wall(
                id = "c" + d.id, author = d.getString("name").orEmpty().ifBlank { "A FIT TO FIT user" },
                thumbUrl = null, fullUrl = null, file = null,
                thumbB64 = thumb, ownerUid = d.getString("uid"), community = true
            )
        }
    }

    private fun realId(w: Wall) = w.id.removePrefix("c")

    fun fullFile(ctx: Context, w: Wall): File? {
        val dir = File(ctx.cacheDir, "wallfull").apply { mkdirs() }
        val f = File(dir, "${w.id}.jpg")
        if (f.exists() && f.length() > 5000) return f
        return try {
            val snap = com.google.android.gms.tasks.Tasks.await(db().collection("wallpaperFiles").document(realId(w)).get())
            val b64 = snap.getString("img") ?: return null
            f.writeBytes(Base64.decode(b64, Base64.NO_WRAP))
            f
        } catch (e: Exception) {
            null
        }
    }

    private fun scaleToFit(bmp: Bitmap, maxW: Int, maxH: Int): Bitmap {
        val r = minOf(maxW.toFloat() / bmp.width, maxH.toFloat() / bmp.height, 1f)
        if (r >= 1f) return bmp
        return Bitmap.createScaledBitmap(bmp, (bmp.width * r).toInt().coerceAtLeast(1), (bmp.height * r).toInt().coerceAtLeast(1), true)
    }

    private fun jpeg(bmp: Bitmap, q: Int): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
        return out.toByteArray()
    }

    /** Returns null when it worked, or a short reason when it did not. */
    suspend fun upload(ctx: Context, uri: Uri, name: String): String? {
        if (!signedIn) return "Please sign up or log in on the Friends tab first."
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return "Could not add this picture"
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1920) sample *= 2
            val src = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return "Could not add this picture"
            val full = scaleToFit(src, 1080, 1920)
            var q = 88
            var bytes = jpeg(full, q)
            while (bytes.size > MAX_RAW_BYTES && q > 45) { q -= 8; bytes = jpeg(full, q) }
            if (bytes.size > MAX_RAW_BYTES) return "This picture is too big. Try a smaller one."
            val thumbBytes = jpeg(scaleToFit(full, 270, 480), 70)
            val uid = myUid
            val id = db().collection("wallpapers").document().id
            val batch = db().batch()
            batch.set(
                db().collection("wallpapers").document(id),
                mapOf(
                    "uid" to uid, "name" to name.ifBlank { "A FIT TO FIT user" },
                    "thumb" to Base64.encodeToString(thumbBytes, Base64.NO_WRAP),
                    "created" to FieldValue.serverTimestamp(), "reporters" to emptyList<String>()
                )
            )
            batch.set(
                db().collection("wallpaperFiles").document(id),
                mapOf("uid" to uid, "img" to Base64.encodeToString(bytes, Base64.NO_WRAP))
            )
            batch.commit().await()
            null
        } catch (e: Exception) {
            "Could not share. Check your internet and the Firestore rules."
        }
    }

    suspend fun delete(w: Wall): Boolean {
        return try {
            val batch = db().batch()
            batch.delete(db().collection("wallpapers").document(realId(w)))
            batch.delete(db().collection("wallpaperFiles").document(realId(w)))
            batch.commit().await()
            true
        } catch (e: Exception) { false }
    }

    suspend fun report(w: Wall): Boolean {
        if (!signedIn) return false
        return try {
            db().collection("wallpapers").document(realId(w)).update("reporters", FieldValue.arrayUnion(myUid)).await()
            true
        } catch (e: Exception) { false }
    }
}
