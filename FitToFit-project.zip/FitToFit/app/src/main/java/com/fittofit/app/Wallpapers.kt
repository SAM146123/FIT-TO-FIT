package com.fittofit.app

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/** One wallpaper: either an online photo (url) or a picture the user added (file). */
class Wall(
    val id: String,
    val author: String,
    val thumbUrl: String?,
    val fullUrl: String?,
    val file: File?
)

/**
 * Free wallpapers.
 * Online photos come from Picsum Photos (free photos from Unsplash, no key needed). A new set of 20 is chosen every day.
 * Pictures added by the user are copied into the app's own folder.
 */
object WallStore {
    private const val PER_DAY = 20
    private const val PAGES = 35

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 40_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "FitToFit/1.0 (wallpapers)")
        return c
    }

    private fun fetchBytes(url: String): ByteArray? {
        val c = open(url)
        return try {
            if (c.responseCode in 200..299) c.inputStream.use { it.readBytes() } else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    /** Today's set. Saved for the day so it also opens without internet after the first load. */
    fun today(ctx: Context): List<Wall> {
        val day = LocalDate.now()
        val dir = File(ctx.filesDir, "wall_daily").apply { mkdirs() }
        val cache = File(dir, "$day.json")
        var text = if (cache.exists()) cache.readText() else ""
        if (text.isBlank()) {
            val page = (day.toEpochDay() % PAGES).toInt() + 1
            val bytes = fetchBytes("https://picsum.photos/v2/list?page=$page&limit=$PER_DAY")
            if (bytes != null) {
                text = String(bytes)
                try {
                    cache.writeText(text)
                    dir.listFiles()?.filter { it.name != cache.name }?.forEach { it.delete() }
                } catch (e: Exception) { }
            }
        }
        if (text.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                Wall(
                    id = "p$id",
                    author = o.optString("author", "Unsplash"),
                    thumbUrl = "https://picsum.photos/id/$id/360/640",
                    fullUrl = "https://picsum.photos/id/$id/2160/3840",
                    file = null
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** The user's own pictures, newest first. */
    fun mine(ctx: Context): List<Wall> {
        val dir = File(ctx.filesDir, "mywalls")
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        return files.map { Wall("m" + it.name, "My picture", null, null, it) }
    }

    /** Copies a picture the user picked into the app folder (shrunk if bigger than 4K). */
    fun addFromUri(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return false
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 3840) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val dir = File(ctx.filesDir, "mywalls").apply { mkdirs() }
            val out = File(dir, "w${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 93, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun remove(w: Wall) {
        try { w.file?.delete() } catch (e: Exception) { }
    }

    private fun decodeSampled(file: File, maxSide: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, b)
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= maxSide) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    /** Small picture for the grid. */
    fun thumb(ctx: Context, w: Wall): Bitmap? {
        w.file?.let { return decodeSampled(it, 640) }
        val dir = File(ctx.cacheDir, "wallthumb").apply { mkdirs() }
        val f = File(dir, "${w.id}.jpg")
        if (!(f.exists() && f.length() > 1000)) {
            val bytes = w.thumbUrl?.let { fetchBytes(it) } ?: return null
            try { f.writeBytes(bytes) } catch (e: Exception) { return null }
        }
        return decodeSampled(f, 640)
    }

    /** The full 4K file on the phone (downloaded once). */
    fun fullFile(ctx: Context, w: Wall): File? {
        w.file?.let { return it }
        val dir = File(ctx.cacheDir, "wallfull").apply { mkdirs() }
        val f = File(dir, "${w.id}.jpg")
        if (f.exists() && f.length() > 5000) return f
        val bytes = w.fullUrl?.let { fetchBytes(it) } ?: return null
        return try {
            dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(5)?.forEach { it.delete() }
            f.writeBytes(bytes)
            f
        } catch (e: Exception) {
            null
        }
    }

    /** Preview picture (half size) so big photos do not use too much memory. */
    fun preview(file: File): Bitmap? = decodeSampled(file, 1920)

    /** which: 1 = home screen, 2 = lock screen, 3 = both. Returns true when it worked. */
    fun setWallpaper(ctx: Context, file: File, which: Int): Boolean {
        return try {
            val bmp = decodeSampled(file, 3840) ?: return false
            val wm = WallpaperManager.getInstance(ctx)
            val flags = when (which) {
                1 -> WallpaperManager.FLAG_SYSTEM
                2 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            wm.setBitmap(bmp, null, true, flags)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Saves a copy into the phone gallery (Pictures/FitToFit). Works on Android 10 and newer. */
    fun saveToGallery(ctx: Context, file: File, name: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "FitToFit_$name.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FitToFit")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            true
        } catch (e: Exception) {
            false
        }
    }
}
