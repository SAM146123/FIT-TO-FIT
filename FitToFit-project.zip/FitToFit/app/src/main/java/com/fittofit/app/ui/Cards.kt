package com.fittofit.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import java.text.NumberFormat
import java.util.Locale

private val CardShape = RoundedCornerShape(20.dp)

@Composable
fun FitCard(
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .shadow(6.dp, CardShape, ambientColor = Color(0x22000000), spotColor = Color(0x22000000))
            .clip(CardShape)
            .background(if (color == Color.White) FitColors.Surface else color),
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(Locale.ROOT),
        fontSize = 12.sp, fontWeight = FontWeight.Bold,
        color = FitColors.Ink.copy(alpha = 0.55f),
        modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp)
    )
}

private fun Long.fmt(): String = NumberFormat.getInstance(Locale.US).format(this)

/* ---------------- Daily activity ---------------- */

@Composable
fun DailyActivityCard(state: FitUiState, onConnectHealth: () -> Unit) {
    val goal = state.stepGoal
    val steps = state.today.steps
    val pct = (steps.toFloat() / goal).coerceIn(0f, 1f)
    FitCard(FitColors.Coral, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 16.dp.toPx()
                    val inset = stroke / 2
                    val sz = Size(size.width - stroke, size.height - stroke)
                    drawArc(Color.White.copy(alpha = .35f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(stroke))
                    drawArc(FitColors.Ink, -90f, 360f * pct, false, Offset(inset, inset), sz, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Text("${(pct * 100).toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text("Steps", fontSize = 13.sp, color = FitColors.Ink)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(steps.fmt(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
                    Text(" / ${goal.toLong().fmt()}", fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .7f), modifier = Modifier.padding(bottom = 4.dp))
                }
                LinearBar(pct, FitColors.Ink, Color.White.copy(alpha = .35f), Modifier.fillMaxWidth().padding(vertical = 6.dp))
                Text("${state.today.calories.toInt()} kcal · ${"%.1f".format(state.today.distanceKm)} km", fontSize = 13.sp, color = FitColors.Ink)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleIcon(Icons.Filled.DirectionsRun, FitColors.Lime)
                    CircleIcon(Icons.Outlined.FavoriteBorder, Color.White.copy(alpha = .35f))
                    CircleIcon(Icons.Outlined.LocalFireDepartment, Color.White.copy(alpha = .35f))
                }
                if (!state.healthConnected) {
                    Text(
                        if (state.healthAvailable) "Tap to sync Google Fit data" else "Install Health Connect",
                        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink,
                        modifier = Modifier.padding(top = 8.dp).clickable { onConnectHealth() }
                    )
                }
            }
        }
    }
}

@Composable
fun LinearBar(progress: Float, fill: Color, track: Color, modifier: Modifier = Modifier) {
    Box(modifier.height(7.dp).clip(CircleShape).background(track)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).clip(CircleShape).background(fill))
    }
}

@Composable
private fun CircleIcon(icon: ImageVector, bg: Color) {
    Box(Modifier.size(34.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = FitColors.Ink, modifier = Modifier.size(18.dp))
    }
}

/* ---------------- Weekly progress ---------------- */

@Composable
fun WeeklyProgressCard(weekly: List<Long>, totalKm: Double) {
    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val maxV = (weekly.maxOrNull() ?: 0L).coerceAtLeast(1L).toFloat()
    val todayIdx = java.time.LocalDate.now().dayOfWeek.value - 1
    FitCard(FitColors.Lime, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp)) {
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    weekly.forEachIndexed { i, v ->
                        val h = (v / maxV).coerceAtLeast(0.06f)
                        Box(
                            Modifier.width(22.dp).fillMaxHeight(h).clip(RoundedCornerShape(3.dp))
                                .background(if (i == todayIdx) FitColors.Coral else FitColors.LimeDark)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    days.forEach { Text(it, fontSize = 9.sp, color = FitColors.Ink, modifier = Modifier.width(22.dp), textAlign = TextAlign.Center, maxLines = 1) }
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.height(130.dp)) {
                Text("Total", fontSize = 12.sp)
                Text(weekly.sum().fmt(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("steps", fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Text("Total distance", fontSize = 12.sp, textAlign = TextAlign.Center)
                Text("${"%.1f".format(totalKm)} km", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/* ---------------- Workout ---------------- */

@Composable
fun Badge(text: String, bg: Color, fg: Color) {
    Box(
        Modifier.size(64.dp).rotate(12f).clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 10.sp, fontWeight = FontWeight.Black, color = fg, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}

/* ---------------- Goal tracker ---------------- */

@Composable
fun GoalTrackerCard(steps: Long, goal: Int) {
    val p = (steps.toFloat() / goal).coerceIn(0f, 1f)
    FitCard(FitColors.Teal, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.TrackChanges, null, tint = FitColors.Ink, modifier = Modifier.size(60.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(goal.toLong().fmt(), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(" steps", fontSize = 14.sp, modifier = Modifier.padding(bottom = 3.dp))
                }
                LinearBar(p, FitColors.Ink, Color.White.copy(alpha = .6f), Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Progress", fontSize = 13.sp)
                    Text("${(p * 100).toInt()}%", fontSize = 13.sp)
                }
            }
        }
    }
}

/* ---------------- Exercises ---------------- */

@Composable
fun ExerciseCard(title: String, subtitle: String, bottom: String, modifier: Modifier = Modifier) {
    FitCard(FitColors.Purple, modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Icon(Icons.Filled.SportsGymnastics, null, tint = FitColors.Ink, modifier = Modifier.size(46.dp))
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(bottom, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(36.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.PlayArrow, null, tint = FitColors.Ink)
                }
            }
        }
    }
}

/* ---------------- Heart rate ---------------- */

@Composable
fun HeartRateCard(bpm: Int, history: List<Int>, deviceName: String?, onDeviceClick: () -> Unit) {
    FitCard(FitColors.Navy, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Favorite, null, tint = FitColors.Red, modifier = Modifier.size(22.dp))
                Spacer(Modifier.weight(1f))
                Row(
                    Modifier.clip(CircleShape).background(Color.White.copy(alpha = .12f)).clickable { onDeviceClick() }.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Watch, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Text(" ${deviceName ?: "Connect watch"}", color = Color.White, fontSize = 11.sp)
                }
            }
            val data = if (history.size >= 2) history else listOf(70, 82, 78, 95, 88, 110, 100, 125, 118, 140, 130, 145)
            Canvas(Modifier.fillMaxWidth().height(80.dp).padding(vertical = 6.dp)) {
                val mn = (data.minOrNull() ?: 0).toFloat()
                val mx = (data.maxOrNull() ?: 1).toFloat().coerceAtLeast(mn + 1)
                val path = Path()
                data.forEachIndexed { i, v ->
                    val x = size.width * i / (data.size - 1)
                    val y = size.height * (1 - (v - mn) / (mx - mn))
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, FitColors.Red, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text(if (bpm > 0) "$bpm" else "--", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(" bpm", fontSize = 16.sp, color = Color.White, modifier = Modifier.padding(bottom = 5.dp))
                Spacer(Modifier.weight(1f))
                Text(if (bpm > 0) "LIVE" else "Not connected", fontSize = 13.sp, color = Color.White.copy(alpha = .8f))
            }
        }
    }
}
