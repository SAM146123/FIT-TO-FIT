package com.fittofit.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import com.fittofit.app.WalkState
import java.text.NumberFormat
import java.util.Locale

/* ---------------- Profile (editable, from the user's own data) ---------------- */

@Composable
fun ProfileCard(
    name: String,
    level: Int,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    FitCard(Color.White, modifier.clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(FitColors.Purple),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    name.firstOrNull()?.uppercase() ?: "?",
                    fontWeight = FontWeight.Black, fontSize = 22.sp, color = FitColors.Ink
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (name.isBlank()) "Set up your profile" else name,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Text(subtitle, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
            }
            Text(
                "LEVEL $level", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.White,
                modifier = Modifier.clip(CircleShape).background(FitColors.Blue)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Outlined.Edit, "Edit profile", tint = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.size(18.dp))
        }
    }
}

/* ---------------- Today's workout (walking) ---------------- */

@Composable
fun WalkingTodayCard(state: FitUiState, onStart: () -> Unit) {
    val remaining = (state.stepGoal - state.today.steps).coerceAtLeast(0)
    FitCard(FitColors.Blue, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("TODAY'S WORKOUT", fontSize = 12.sp, color = Color.White.copy(alpha = .85f), fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DirectionsWalk, null, tint = Color.White, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("WALKING", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            if (remaining > 0) "$remaining steps to goal" else "Goal reached!",
                            color = Color.White, fontSize = 13.sp
                        )
                        Text("${"%.2f".format(state.today.distanceKm)} km so far", color = Color.White, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.clip(CircleShape).background(Color.White).clickable { onStart() }
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Text("Start walking", color = FitColors.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            Badge("STREAK\n${state.streakDays} days", FitColors.Coral, FitColors.Ink)
        }
    }
}

/* ---------------- Category tabs ---------------- */

@Composable
fun CategoryTabs(selected: Int, onSelect: (Int) -> Unit) {
    val names = listOf("Walking", "Running", "Cycling", "Yoga", "Strength")
    val icons = listOf(
        Icons.Filled.DirectionsWalk, Icons.Filled.DirectionsRun, Icons.Filled.DirectionsBike,
        Icons.Filled.SelfImprovement, Icons.Filled.FitnessCenter
    )
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(FitColors.Yellow).padding(horizontal = 6.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                names.forEachIndexed { i, n ->
                    Text(
                        n, fontSize = 12.sp,
                        fontWeight = if (i == selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { onSelect(i) }
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                icons.forEachIndexed { i, ic ->
                    Box(
                        Modifier.size(width = 48.dp, height = 44.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (i == selected) FitColors.Yellow else Color(0xFFF6EEDD))
                            .clickable { onSelect(i) },
                        contentAlignment = Alignment.Center
                    ) { Icon(ic, null, tint = FitColors.Ink) }
                }
            }
        }
    }
}

/* ---------------- Walking session ---------------- */

private fun formatTime(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

@Composable
private fun WalkStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
        Text(label, fontSize = 12.sp, color = FitColors.Ink)
    }
}

@Composable
fun WalkCard(walk: WalkState, sensorAvailable: Boolean, onStart: () -> Unit, onStop: () -> Unit) {
    FitCard(FitColors.Teal, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("WALKING SESSION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
            Text(
                NumberFormat.getInstance(Locale.US).format(walk.steps),
                fontSize = 52.sp, fontWeight = FontWeight.Black, color = FitColors.Ink
            )
            Text("steps", fontSize = 13.sp, color = FitColors.Ink)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                WalkStat(formatTime(walk.seconds), "time")
                WalkStat("%.2f".format(walk.distanceKm), "km")
                WalkStat("${walk.kcal}", "kcal")
            }
            if (!sensorAvailable) {
                Text(
                    "This phone has no step sensor, so walking sessions can't be counted.",
                    fontSize = 12.sp, color = FitColors.Ink, textAlign = TextAlign.Center
                )
            } else {
                Box(
                    Modifier.clip(CircleShape)
                        .background(if (walk.running) FitColors.Coral else FitColors.Ink)
                        .clickable { if (walk.running) onStop() else onStart() }
                        .padding(horizontal = 36.dp, vertical = 12.dp)
                ) {
                    Text(
                        if (walk.running) "Stop" else "Start walk",
                        color = if (walk.running) FitColors.Ink else Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                }
            }
        }
    }
}

/* ---------------- Achievements (based on real progress) ---------------- */

@Composable
fun AchievementCard(steps: Long, goal: Int, streak: Int) {
    val reached = steps >= goal
    FitCard(FitColors.Orange, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.EmojiEvents, null, tint = FitColors.Ink, modifier = Modifier.size(64.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (reached) "GOAL\nREACHED!" else "KEEP\nGOING!",
                    fontSize = 18.sp, fontWeight = FontWeight.Black, color = FitColors.Ink, lineHeight = 22.sp
                )
                if (!reached) {
                    Text("${goal - steps} steps to your goal", fontSize = 12.sp, color = FitColors.Ink)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val icons = listOf(
                        Icons.Filled.Star, Icons.Filled.Bolt, Icons.Filled.Verified,
                        Icons.Filled.WorkspacePremium, Icons.Filled.MilitaryTech
                    )
                    val earned = when {
                        steps >= goal -> 5
                        else -> ((steps * 5) / goal).toInt().coerceIn(0, 4)
                    }
                    icons.forEachIndexed { i, ic ->
                        Icon(
                            ic, null,
                            tint = if (i < earned) FitColors.Yellow else Color.White.copy(alpha = .45f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
            Badge("$streak DAY\nSTREAK", FitColors.Navy, Color.White)
        }
    }
}
