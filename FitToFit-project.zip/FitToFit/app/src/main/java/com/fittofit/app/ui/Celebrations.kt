package com.fittofit.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.sin
import kotlin.random.Random

private class Particle(
    val x: Float,
    val speed: Float,
    val size: Float,
    val color: Color,
    val phase: Float,
    val spin: Float,
    val drift: Float
)

private val confettiColors = listOf(
    FitColors.Coral, FitColors.Lime, FitColors.Yellow, FitColors.Teal,
    FitColors.Orange, FitColors.Purple, Color.White, FitColors.Blue
)

/** Falling confetti, drawn on a Canvas and animated every frame. */
@Composable
fun ConfettiBurst(modifier: Modifier = Modifier, count: Int = 110) {
    val particles = remember {
        List(count) {
            Particle(
                x = Random.nextFloat(),
                speed = 0.18f + Random.nextFloat() * 0.35f,
                size = 8f + Random.nextFloat() * 10f,
                color = confettiColors.random(),
                phase = Random.nextFloat(),
                spin = 120f + Random.nextFloat() * 360f,
                drift = (Random.nextFloat() - 0.5f) * 0.05f
            )
        }
    }
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            androidx.compose.runtime.withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
        }
    }
    Canvas(modifier.fillMaxSize()) {
        particles.forEach { p ->
            val progress = (t * p.speed + p.phase) % 1f
            val y = progress * (size.height + 60f) - 30f
            val wobble = sin((t + p.phase * 6f) * 3f) * 18f
            val xBase = (((p.x + p.drift * t) % 1f) + 1f) % 1f
            val x = xBase * size.width + wobble
            rotate(degrees = t * p.spin + p.phase * 360f, pivot = Offset(x, y)) {
                drawRect(
                    color = p.color,
                    topLeft = Offset(x - p.size / 2f, y - p.size / 4f),
                    size = Size(p.size, p.size / 2f)
                )
            }
        }
    }
}

@Composable
private fun CelebrationFrame(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            ConfettiBurst()
            content()
        }
    }
}

@Composable
private fun PillButton(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(bg).clickable { onClick() }
            .padding(horizontal = 34.dp, vertical = 12.dp)
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

/** Shown when the daily step goal is completed. */
@Composable
fun GoalCelebrationDialog(name: String, steps: Long, goal: Int, streak: Int, onShare: () -> Unit = {}, onDismiss: () -> Unit) {
    val pop = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    val infinite = rememberInfiniteTransition(label = "trophy")
    val tilt by infinite.animateFloat(
        initialValue = -8f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "tilt"
    )
    val glow by infinite.animateFloat(
        initialValue = 0.85f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    CelebrationFrame(onDismiss) {
        Column(
            Modifier.padding(28.dp).fillMaxWidth().scale(pop.value)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(FitColors.Orange, FitColors.Coral)))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(120.dp).scale(glow).clip(CircleShape).background(Color.White.copy(alpha = .25f)))
                Icon(
                    Icons.Filled.EmojiEvents, null, tint = Color.White,
                    modifier = Modifier.size(84.dp).rotate(tilt)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "🎉 Congratulations${if (name.isNotBlank()) ", $name" else ""}!",
                fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "You completed today's goal!",
                fontSize = 16.sp, color = Color.White, textAlign = TextAlign.Center
            )
            Text(
                "Daily goal complete — ${"%,d".format(steps)} / ${"%,d".format(goal)} steps",
                fontSize = 13.sp, color = Color.White.copy(alpha = .9f), textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )
            if (streak > 1) {
                Text(
                    "🔥 $streak-day streak!",
                    fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Text(
                "“${com.fittofit.app.Quotes.today(com.fittofit.app.Settings.lang)}”",
                fontSize = 14.sp, color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 12.dp)
            )
            Spacer(Modifier.height(18.dp))
            PillButton("Share my win", Color.White.copy(alpha = .25f), Color.White, onShare)
            Spacer(Modifier.height(8.dp))
            PillButton("Awesome!", Color.White, FitColors.Coral, onDismiss)
        }
    }
}

/** Shown the first time the user opens the app each day. */
@Composable
fun WelcomeBackDialog(name: String, steps: Long, goal: Int, streak: Int, onDismiss: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "heart")
    val beat by infinite.animateFloat(
        initialValue = 0.9f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beat"
    )
    val pop = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    val remaining = (goal - steps).coerceAtLeast(0)
    CelebrationFrame(onDismiss) {
        Column(
            Modifier.padding(28.dp).fillMaxWidth().scale(pop.value)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(FitColors.Blue, FitColors.Teal)))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(110.dp).scale(beat).clip(CircleShape).background(Color.White.copy(alpha = .22f)))
                Icon(Icons.Filled.Favorite, null, tint = Color.White, modifier = Modifier.size(70.dp).scale(beat))
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Welcome back, $name! 👋",
                fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (remaining > 0) "Only $remaining steps left to reach today's goal. You can do it! 💪"
                else "You've already reached today's goal. Awesome! 🌟",
                fontSize = 15.sp, color = Color.White, textAlign = TextAlign.Center
            )
            if (streak > 0) {
                Text(
                    "🔥 $streak-day streak — keep it going!",
                    fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            PillButton("Let's go!", Color.White, FitColors.Blue, onDismiss)
        }
    }
}

/** Shown when a Video Coach workout is finished. */
@Composable
fun WorkoutCompleteDialog(title: String, minutes: Int, kcal: Int, onDismiss: () -> Unit) {
    val pop = remember { Animatable(0.2f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    CelebrationFrame(onDismiss) {
        Column(
            Modifier.padding(28.dp).fillMaxWidth().scale(pop.value)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(FitColors.Purple, FitColors.Blue)))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.EmojiEvents, null, tint = Color.White, modifier = Modifier.size(80.dp))
            Spacer(Modifier.height(12.dp))
            Text("Workout complete! 💪", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(title, fontSize = 16.sp, color = Color.White, textAlign = TextAlign.Center)
            Text(
                "$minutes min · about $kcal kcal",
                fontSize = 14.sp, color = Color.White.copy(alpha = .9f), modifier = Modifier.padding(top = 6.dp)
            )
            Spacer(Modifier.height(18.dp))
            PillButton("Great job!", Color.White, FitColors.Blue, onDismiss)
        }
    }
}
