package com.fittofit.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max

class Exercise(
    val id: String,
    val title: String,
    val category: String,
    val level: String,
    val timed: Boolean,
    val reps: Int,
    val seconds: Int,
    val sets: Int,
    val restSec: Int,
    val cycleMs: Int,
    val kcalPerMin: Double,
    val intro: String,
    val steps: List<String>,
    val cues: List<String>
) {
    val summary: String
        get() = if (timed) "$sets sets × $seconds sec" else "$sets sets × $reps reps"
}

/** Every exercise has two real photos (start and end position) stored in assets/coach. */
object CoachData {

    private val allExercises: List<Exercise> = listOf(
        Exercise(
            id = "jacks", title = "Jumping Jacks", category = "Cardio", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 20, cycleMs = 1100,
            kcalPerMin = 8.0,
            intro = "Jumping jacks raise your heart rate fast.",
            steps = listOf("Stand with your feet together and arms by your sides.", "Jump your feet apart while raising your arms overhead.", "Jump back to the start and repeat."),
            cues = listOf("Land softly on the balls of your feet.", "Keep your core tight.", "Stay light and bouncy.", "Breathe steadily.")
        ),
        Exercise(
            id = "knees", title = "High Knees", category = "Cardio", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 800,
            kcalPerMin = 9.0,
            intro = "High knees get your heart pumping.",
            steps = listOf("Stand tall with your feet hip-width apart.", "Run on the spot, driving each knee up to hip height.", "Pump your arms and stay on the balls of your feet."),
            cues = listOf("Drive your knees up.", "Pump your arms.", "Stay tall.", "Keep a quick rhythm.")
        ),
        Exercise(
            id = "climbers", title = "Mountain Climbers", category = "Cardio", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 900,
            kcalPerMin = 9.0,
            intro = "Mountain climbers work your core and heart together.",
            steps = listOf("Start in a high plank with your hands under your shoulders.", "Drive one knee towards your chest, then switch quickly.", "Keep your hips low and your core tight."),
            cues = listOf("Keep your hips low.", "Fast feet.", "Core tight.", "Breathe steadily.")
        ),
        Exercise(
            id = "jumpsquat", title = "Jump Squats", category = "Cardio", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 1600,
            kcalPerMin = 10.0,
            intro = "Jump squats add power to a normal squat.",
            steps = listOf("Stand with your feet shoulder-width apart.", "Squat down, then explode upwards into a jump.", "Land softly and go straight into the next squat."),
            cues = listOf("Land softly.", "Chest up.", "Swing your arms.", "Knees in line with your toes.")
        ),
        Exercise(
            id = "squat", title = "Bodyweight Squats", category = "Legs", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 3000,
            kcalPerMin = 6.0,
            intro = "Squats build strong legs and glutes.",
            steps = listOf("Stand with your feet shoulder-width apart.", "Push your hips back and bend your knees, as if sitting on a chair.", "Keep your chest up and your heels on the floor.", "Push through your heels to stand up."),
            cues = listOf("Chest up.", "Knees in line with your toes.", "Push through your heels.", "Keep your back straight.")
        ),
        Exercise(
            id = "revlunge", title = "Reverse Lunges", category = "Legs", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3200,
            kcalPerMin = 6.0,
            intro = "Reverse lunges are gentle on your knees.",
            steps = listOf("Stand tall with your hands on your hips.", "Step one foot back and lower until both knees bend to about 90 degrees.", "Push through your front heel to come back up, then switch legs."),
            cues = listOf("Keep your chest up.", "Front knee over your ankle.", "Lower straight down.", "Switch legs each time.")
        ),
        Exercise(
            id = "lunge", title = "Forward Lunges", category = "Legs", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3200,
            kcalPerMin = 6.0,
            intro = "Lunges work each leg on its own.",
            steps = listOf("Stand tall with your feet together.", "Step one foot forward and lower until both knees bend to about 90 degrees.", "Push off the front foot to stand up, then switch legs."),
            cues = listOf("Keep your chest up.", "Front knee over your ankle.", "Lower straight down.", "Switch legs each time.")
        ),
        Exercise(
            id = "stepup", title = "Step Ups", category = "Legs", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 2400,
            kcalPerMin = 7.0,
            intro = "Step ups build strong legs, just like climbing stairs.",
            steps = listOf("Stand in front of a sturdy step or low bench.", "Place one foot on the step and push up until you stand tall.", "Step back down with control and switch legs."),
            cues = listOf("Push through your heel.", "Stand tall at the top.", "Step down slowly.", "Switch legs.")
        ),
        Exercise(
            id = "bridge", title = "Glute Bridges", category = "Glutes", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 25, cycleMs = 2600,
            kcalPerMin = 5.0,
            intro = "Glute bridges strengthen your hips and lower back.",
            steps = listOf("Lie on your back with your knees bent and feet flat.", "Press through your heels and lift your hips.", "Squeeze your glutes at the top, then lower slowly."),
            cues = listOf("Squeeze your glutes.", "Push through your heels.", "Do not arch your back.", "Lower slowly.")
        ),
        Exercise(
            id = "sbridge", title = "Single-Leg Glute Bridges", category = "Glutes", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3000,
            kcalPerMin = 6.0,
            intro = "This harder bridge works one side at a time.",
            steps = listOf("Lie on your back with your knees bent.", "Lift one leg straight up.", "Push through the other heel to lift your hips, then lower slowly."),
            cues = listOf("Keep your hips level.", "Squeeze your glute.", "Move slowly.", "Switch legs after each set.")
        ),
        Exercise(
            id = "donkey", title = "Donkey Kicks", category = "Glutes", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 25, cycleMs = 2400,
            kcalPerMin = 5.0,
            intro = "Donkey kicks shape and strengthen your glutes.",
            steps = listOf("Start on your hands and knees.", "Keep your knee bent and lift one foot towards the ceiling.", "Squeeze your glute at the top, then lower and repeat."),
            cues = listOf("Keep your back flat.", "Squeeze at the top.", "Do not swing your leg.", "Look at the floor.")
        ),
        Exercise(
            id = "pushup", title = "Push-ups", category = "Upper Body", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            kcalPerMin = 7.0,
            intro = "Push-ups strengthen your chest, arms and core.",
            steps = listOf("Place your hands under your shoulders and make a straight line from head to heels.", "Lower your chest towards the floor, elbows at about 45 degrees.", "Push the floor away to return to the top."),
            cues = listOf("Keep your body in one straight line.", "Do not let your hips sag.", "Breathe in going down, out going up.", "Elbows close to your body.")
        ),
        Exercise(
            id = "incline", title = "Incline Push-ups", category = "Upper Body", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            kcalPerMin = 5.0,
            intro = "Incline push-ups are easier on your arms and shoulders.",
            steps = listOf("Place your hands on a sturdy bench or table.", "Walk your feet back until your body is in a straight line.", "Lower your chest towards the bench, then push back up."),
            cues = listOf("Straight line from head to heels.", "Core tight.", "Elbows at 45 degrees.", "Push the bench away.")
        ),
        Exercise(
            id = "decline", title = "Decline Push-ups", category = "Upper Body", level = "Advanced",
            timed = false, reps = 8, seconds = 0, sets = 3, restSec = 40, cycleMs = 3000,
            kcalPerMin = 8.0,
            intro = "Decline push-ups put extra work on your chest and shoulders.",
            steps = listOf("Place your feet on a sturdy bench and your hands on the floor.", "Keep a straight line from your head to your heels.", "Lower your head towards the floor, then push back up."),
            cues = listOf("Core tight.", "Do not let your hips sag.", "Control the way down.", "Breathe steadily.")
        ),
        Exercise(
            id = "diamond", title = "Diamond Push-ups", category = "Upper Body", level = "Advanced",
            timed = false, reps = 8, seconds = 0, sets = 3, restSec = 40, cycleMs = 2800,
            kcalPerMin = 8.0,
            intro = "Diamond push-ups target your triceps.",
            steps = listOf("Place your hands close together under your chest, thumbs and fingers forming a diamond.", "Keep your body in a straight line.", "Lower your chest to your hands, then push back up."),
            cues = listOf("Elbows close to your body.", "Core tight.", "Straight line from head to heels.", "Push up strongly.")
        ),
        Exercise(
            id = "dips", title = "Triceps Dips", category = "Upper Body", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            kcalPerMin = 6.0,
            intro = "Dips on a chair or couch strengthen your triceps.",
            steps = listOf("Sit on the edge of a sturdy chair and place your hands beside your hips.", "Slide forward off the chair with your knees bent.", "Lower your body by bending your elbows, then push back up."),
            cues = listOf("Keep your back close to the chair.", "Elbows point back.", "Shoulders down.", "Push up strongly.")
        ),
        Exercise(
            id = "plank", title = "Plank Hold", category = "Core", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 4000,
            kcalPerMin = 4.0,
            intro = "The plank builds a strong core.",
            steps = listOf("Place your hands under your shoulders.", "Make a straight line from your head to your heels.", "Squeeze your stomach and glutes, and hold."),
            cues = listOf("Squeeze your stomach.", "Keep your hips level.", "Look at the floor.", "Breathe slowly, do not hold your breath.")
        ),
        Exercise(
            id = "sideplank", title = "Side Plank", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 20, sets = 2, restSec = 20, cycleMs = 3000,
            kcalPerMin = 4.0,
            intro = "The side plank strengthens your sides and hips.",
            steps = listOf("Lie on your side with your elbow under your shoulder.", "Lift your hips so your body makes a straight line.", "Hold, then switch sides."),
            cues = listOf("Hips high.", "Straight line from head to feet.", "Breathe steadily.", "Stack your shoulders.")
        ),
        Exercise(
            id = "superman", title = "Superman Hold", category = "Core", level = "Beginner",
            timed = true, reps = 0, seconds = 20, sets = 3, restSec = 20, cycleMs = 3000,
            kcalPerMin = 4.0,
            intro = "The superman hold strengthens your lower back.",
            steps = listOf("Lie face down with your arms stretched forward.", "Lift your arms, chest and legs off the floor.", "Hold, then lower slowly."),
            cues = listOf("Squeeze your glutes.", "Look at the floor.", "Reach long.", "Breathe steadily.")
        ),
        Exercise(
            id = "crunch", title = "Bicycle Crunches", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 1600,
            kcalPerMin = 7.0,
            intro = "Bicycle crunches work your abs and obliques.",
            steps = listOf("Lie on your back with your hands behind your head.", "Bring one knee in while twisting the opposite elbow towards it.", "Switch sides in a smooth pedalling motion."),
            cues = listOf("Do not pull on your neck.", "Twist from your waist.", "Keep a steady rhythm.", "Breathe out as you twist.")
        ),
        Exercise(
            id = "crunches", title = "Crunches", category = "Core", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 20, cycleMs = 2400,
            kcalPerMin = 5.0,
            intro = "Crunches strengthen your upper abs.",
            steps = listOf("Lie on your back with your knees bent and your hands behind your head.", "Lift your shoulders off the floor by tightening your abs.", "Lower slowly and repeat."),
            cues = listOf("Do not pull on your neck.", "Breathe out as you lift.", "Move slowly.", "Keep your feet flat.")
        )
    )

    /** Exercises that have real photos in assets/coach. */
    private val photoIds = setOf(
        "jacks", "knees", "climbers", "jumpsquat", "squat", "revlunge", "lunge", "stepup", "bridge", "sbridge",
        "donkey", "pushup", "incline", "decline", "diamond", "dips", "plank", "sideplank", "superman", "crunch", "crunches"
    )

    /** Only workouts that have real photos are shown. */
    val exercises: List<Exercise> = allExercises.filter { it.id in photoIds }

    val categories = listOf("All", "Cardio", "Legs", "Glutes", "Upper Body", "Core")
}

/** Real photo animation: the start and end position fade into each other like a short video. */
@Composable
fun CoachMedia(ex: Exercise, modifier: Modifier = Modifier, crop: Boolean = false) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val frames = remember(ex.id) {
        (0..1).map { n ->
            try {
                ctx.assets.open("coach/${ex.id}_$n.jpg").use { android.graphics.BitmapFactory.decodeStream(it) }
                    ?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val transition = rememberInfiniteTransition(label = "photo")
    val v by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(max(ex.cycleMs / 2, 600), easing = LinearEasing), RepeatMode.Reverse),
        label = "mix"
    )
    val t = ((v - 0.12f) / 0.76f).coerceIn(0f, 1f)
    val alpha = t * t * (3f - 2f * t)
    val scale = if (crop) androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit
    Box(modifier.clip(RoundedCornerShape(14.dp))) {
        frames[0]?.let { androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize(), contentScale = scale) }
        frames[1]?.let {
            androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize().alpha(alpha), contentScale = scale)
        }
    }
}

/* ================= list of workouts ================= */

@Composable
fun CoachHub(onOpen: (Exercise) -> Unit) {
    var category by remember { mutableStateOf("All") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(FitColors.Blue, FitColors.Teal)))
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(18.dp).fillMaxWidth(0.6f)) {
                Text("Video Coach", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(
                    "Follow your animated coach. Turn on the voice for spoken instructions.",
                    fontSize = 12.sp, color = Color.White.copy(alpha = .92f)
                )
            }
            val first = CoachData.exercises.first { it.id == "pushup" }
            CoachMedia(first, Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).size(width = 150.dp, height = 100.dp), crop = true)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CoachData.categories.forEach { c ->
                val on = c == category
                Text(
                    c, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (on) Color.White else FitColors.Ink,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (on) FitColors.Ink else Color.White)
                        .clickable { category = c }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        CoachData.exercises.filter { category == "All" || it.category == category }.forEach { ex ->
            FitCard(Color.White, Modifier.fillMaxWidth().clickable { onOpen(ex) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(86.dp).clip(RoundedCornerShape(16.dp)).background(FitColors.Cream)
                    ) {
                        CoachMedia(ex, Modifier.fillMaxSize(), crop = true)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ex.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
                        Text(ex.summary, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
                        Text(
                            ex.category + " · " + ex.level, fontSize = 11.sp,
                            color = FitColors.Ink.copy(alpha = .5f), modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

/* ================= one workout with the coach ================= */

private enum class Phase { Idle, Intro, Countdown, Work, Rest, Done }

@Composable
fun CoachPlayer(
    ex: Exercise,
    voiceOn: Boolean,
    voiceProblem: String?,
    actions: ExtraActions,
    onBack: () -> Unit
) {
    var phase by remember { mutableStateOf(Phase.Idle) }
    var runId by remember { mutableIntStateOf(0) }
    var figureKey by remember { mutableIntStateOf(0) }
    var caption by remember { mutableStateOf(ex.intro) }
    var setNo by remember { mutableIntStateOf(1) }
    var count by remember { mutableIntStateOf(0) }
    var restLeft by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf<Triple<String, Int, Int>?>(null) }

    BackHandler { actions.stopSpeak(); onBack() }
    DisposableEffect(Unit) { onDispose { actions.stopSpeak() } }

    LaunchedEffect(runId) {
        if (runId == 0) return@LaunchedEffect
        val startedAt = System.currentTimeMillis()
        fun say(text: String, interrupt: Boolean = false) = actions.speak(text, interrupt)

        phase = Phase.Intro
        caption = ex.steps.first()
        say("Let's do ${ex.title}. ${ex.steps.first()}", true)
        delay(if (voiceOn) 1500L + ex.steps.first().length * 55L else 1500L)

        phase = Phase.Countdown
        for (n in 3 downTo 1) {
            countdown = n
            caption = "Get ready..."
            say("$n", true)
            delay(1000)
        }

        for (s in 1..ex.sets) {
            setNo = s
            phase = Phase.Work
            figureKey += 1
            caption = ex.cues.first()
            say(if (s == 1) "Go!" else "Set $s. Go!", true)

            if (!ex.timed) {
                count = 0
                delay(700)
                for (r in 1..ex.reps) {
                    delay(ex.cycleMs.toLong())
                    count = r
                    caption = ex.cues[(r / 3) % ex.cues.size]
                    say("$r", true)
                    if (r == ex.reps / 2) say("Halfway there!", false)
                    if (r == ex.reps - 1) say("One more!", false)
                }
            } else {
                say(ex.cues.first(), false)
                for (left in ex.seconds downTo 1) {
                    count = left
                    val elapsed = ex.seconds - left
                    if (elapsed > 0 && elapsed % 8 == 0) caption = ex.cues[(elapsed / 8) % ex.cues.size]
                    when {
                        left == ex.seconds / 2 -> say("Halfway there. Keep going!", true)
                        left == 10 -> say("Ten seconds left.", true)
                        left <= 3 -> say("$left", true)
                        elapsed > 0 && elapsed % 10 == 5 -> say(ex.cues[(elapsed / 10) % ex.cues.size], false)
                    }
                    delay(1000)
                }
                count = 0
            }

            if (s < ex.sets) {
                phase = Phase.Rest
                caption = "Great set! Rest and breathe."
                say("Great set! Rest for ${ex.restSec} seconds.", true)
                for (left in ex.restSec downTo 1) {
                    restLeft = left
                    if (left == 3) say("Get ready.", false)
                    delay(1000)
                }
            }
        }

        phase = Phase.Done
        val minutes = max(1, ((System.currentTimeMillis() - startedAt) / 60000L).toInt())
        val kcal = (ex.kcalPerMin * minutes).toInt()
        caption = "Workout complete. Great job!"
        say("Workout complete! Great job. You burned about $kcal calories.", true)
        actions.finishWorkout(ex.title, minutes, kcal)
        done = Triple(ex.title, minutes, kcal)
        runId = 0
    }

    val running = phase == Phase.Intro || phase == Phase.Countdown || phase == Phase.Work || phase == Phase.Rest

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.clip(CircleShape).clickable { actions.stopSpeak(); onBack() }.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = FitColors.Ink)
            Spacer(Modifier.width(6.dp))
            Text("Video Coach", fontWeight = FontWeight.Bold, color = FitColors.Ink)
        }

        // animated coach
        Box(
            Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFE6F0FF), Color(0xFFFFFFFF))))
        ) {
            key(figureKey) {
                CoachMedia(ex, Modifier.fillMaxSize())
            }
            Text(
                ex.title, fontSize = 18.sp, fontWeight = FontWeight.Black, color = FitColors.Ink,
                modifier = Modifier.align(Alignment.TopStart).padding(14.dp)
            )
            val big = when (phase) {
                Phase.Countdown -> "$countdown"
                Phase.Work -> if (ex.timed) "${count}s" else "$count / ${ex.reps}"
                Phase.Rest -> "Rest ${restLeft}s"
                Phase.Done -> "Done!"
                else -> ""
            }
            if (big.isNotEmpty()) {
                Text(
                    big, fontSize = 28.sp, fontWeight = FontWeight.Black, color = FitColors.Blue,
                    modifier = Modifier.align(Alignment.TopEnd).padding(14.dp)
                )
            }
            if (phase == Phase.Work || phase == Phase.Rest) {
                Text(
                    "Set $setNo of ${ex.sets}", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = FitColors.Ink.copy(alpha = .6f),
                    modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                )
            }
        }

        // coach speech bubble
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(FitColors.Blue),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.SportsGymnastics, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(12.dp)
            ) {
                Text("Coach", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FitColors.Blue)
                Text(caption, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = FitColors.Ink)
            }
        }

        // start / stop
        Box(
            Modifier.fillMaxWidth().clip(CircleShape)
                .background(if (running) FitColors.Coral else FitColors.Ink)
                .clickable {
                    if (running) {
                        runId = 0
                        phase = Phase.Idle
                        caption = ex.intro
                        actions.stopSpeak()
                    } else {
                        runId += 1
                    }
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    running -> "Stop"
                    phase == Phase.Done -> "Start again"
                    else -> "Start workout"
                },
                color = if (running) FitColors.Ink else Color.White,
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }

        // voice switch
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice coach (English)", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                        Text(
                            "Spoken instructions, rep counts and reminders",
                            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
                        )
                    }
                    Switch(checked = voiceOn, onCheckedChange = { actions.setVoice(it) })
                }
                if (voiceOn && voiceProblem != null) {
                    Text(voiceProblem, fontSize = 12.sp, color = FitColors.Red, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        // how to
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("How to do it", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                ex.steps.forEachIndexed { i, s ->
                    Row {
                        Text("${i + 1}.", fontWeight = FontWeight.Bold, color = FitColors.Blue, modifier = Modifier.width(22.dp))
                        Text(s, fontSize = 13.sp, color = FitColors.Ink)
                    }
                }
                Text("Coach tips", fontWeight = FontWeight.Bold, color = FitColors.Ink, modifier = Modifier.padding(top = 6.dp))
                ex.cues.forEach { Text("• $it", fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .8f)) }
                Text(
                    "Stop if you feel pain or dizziness. If you have a health condition, check with your doctor first.",
                    fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f), textAlign = TextAlign.Start,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }

    done?.let { (title, minutes, kcal) ->
        WorkoutCompleteDialog(title, minutes, kcal) { done = null }
    }
}
