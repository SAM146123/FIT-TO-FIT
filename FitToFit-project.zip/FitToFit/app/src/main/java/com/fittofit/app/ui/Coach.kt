package com.fittofit.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max

class Exercise(
    val id: String,
    val title: String,
    val category: String,
    val level: String,
    val timed: Boolean,
    val reps: Int,
    val seconds: Int,
    val sets: Int,
    val restSec: Int,
    val cycleMs: Int,
    val ground: Float,
    val kcalPerMin: Double,
    val intro: String,
    val steps: List<String>,
    val cues: List<String>,
    val keys: List<FloatArray>,
    /** "side" or "front" */
    val view: String = "side",
    /** none, wall, step, bench, boxL, chair */
    val prop: String = "none",
    /** true when lying on the back (face looks up) */
    val faceUp: Boolean = false
) {
    val summary: String
        get() = if (timed) "$sets sets × $seconds sec" else "$sets sets × $reps reps"

    /** Which outfit colours the coach wears (0..5). */
    val look: Int get() = kotlin.math.abs(id.hashCode()) % 6
}

/** Body positions are listed as: head, neck, hip, near elbow/hand, far elbow/hand, near knee/foot, far knee/foot (x, y in 0..1). */
object CoachData {

    val exercises: List<Exercise> = listOf(
        Exercise(
            id = "walk", title = "Brisk Walk", category = "Cardio", level = "Beginner",
            timed = true, reps = 0, seconds = 45, sets = 2, restSec = 20, cycleMs = 1100,
            ground = 0.91f, kcalPerMin = 5.0,
            intro = "A brisk walk warms up your whole body.",
            steps = listOf("Stand tall with your shoulders relaxed.", "Swing your arms naturally as you step.", "Take quick, even steps and breathe steadily."),
            cues = listOf("Keep your head up.", "Swing your arms.", "Breathe in and out evenly.", "Land softly on your heels."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.46f, 0.38f, 0.42f, 0.50f, 0.54f, 0.37f, 0.59f, 0.48f, 0.56f, 0.70f, 0.62f, 0.90f, 0.45f, 0.70f, 0.38f, 0.88f),
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.54f, 0.37f, 0.59f, 0.48f, 0.46f, 0.38f, 0.42f, 0.50f, 0.45f, 0.70f, 0.38f, 0.88f, 0.56f, 0.70f, 0.62f, 0.90f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "jacks", title = "Jumping Jacks", category = "Cardio", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 20, cycleMs = 1100,
            ground = 0.91f, kcalPerMin = 8.0,
            intro = "Jumping jacks raise your heart rate fast.",
            steps = listOf("Stand with your feet together and arms by your sides.", "Jump your feet apart while raising your arms overhead.", "Jump back to the start and repeat."),
            cues = listOf("Land softly on the balls of your feet.", "Keep your core tight.", "Stay light and bouncy.", "Breathe steadily."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.40f, 0.36f, 0.37f, 0.50f, 0.60f, 0.36f, 0.63f, 0.50f, 0.46f, 0.70f, 0.45f, 0.90f, 0.54f, 0.70f, 0.55f, 0.90f),
                floatArrayOf(0.50f, 0.08f, 0.50f, 0.18f, 0.50f, 0.46f, 0.36f, 0.26f, 0.30f, 0.08f, 0.64f, 0.26f, 0.70f, 0.08f, 0.38f, 0.64f, 0.30f, 0.84f, 0.62f, 0.64f, 0.70f, 0.84f)
            ),
            view = "front", prop = "none", faceUp = false
        ),
        Exercise(
            id = "knees", title = "High Knees", category = "Cardio", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 800,
            ground = 0.91f, kcalPerMin = 9.0,
            intro = "High knees get your heart pumping.",
            steps = listOf("Stand tall with your feet hip-width apart.", "Run on the spot, driving each knee up to hip height.", "Pump your arms and stay on the balls of your feet."),
            cues = listOf("Drive your knees up.", "Pump your arms.", "Stay tall.", "Keep a quick rhythm."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.56f, 0.36f, 0.62f, 0.26f, 0.44f, 0.38f, 0.40f, 0.48f, 0.62f, 0.46f, 0.58f, 0.64f, 0.49f, 0.70f, 0.47f, 0.90f),
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.44f, 0.38f, 0.40f, 0.48f, 0.56f, 0.36f, 0.62f, 0.26f, 0.49f, 0.70f, 0.47f, 0.90f, 0.62f, 0.46f, 0.58f, 0.64f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "climbers", title = "Mountain Climbers", category = "Cardio", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 900,
            ground = 0.81f, kcalPerMin = 9.0,
            intro = "Mountain climbers work your core and heart together.",
            steps = listOf("Start in a high plank with your hands under your shoulders.", "Drive one knee towards your chest, then switch quickly.", "Keep your hips low and your core tight."),
            cues = listOf("Keep your hips low.", "Fast feet.", "Core tight.", "Breathe steadily."),
            keys = listOf(
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.60f, 0.62f, 0.54f, 0.76f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.60f, 0.62f, 0.54f, 0.76f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "jumpsquat", title = "Jump Squats", category = "Cardio", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 1600,
            ground = 0.91f, kcalPerMin = 10.0,
            intro = "Jump squats add power to a normal squat.",
            steps = listOf("Stand with your feet shoulder-width apart.", "Squat down, then explode upwards into a jump.", "Land softly and go straight into the next squat."),
            cues = listOf("Land softly.", "Chest up.", "Swing your arms.", "Knees in line with your toes."),
            keys = listOf(
                floatArrayOf(0.58f, 0.28f, 0.54f, 0.40f, 0.36f, 0.62f, 0.64f, 0.46f, 0.74f, 0.44f, 0.63f, 0.47f, 0.73f, 0.45f, 0.60f, 0.66f, 0.52f, 0.90f, 0.58f, 0.67f, 0.50f, 0.90f),
                floatArrayOf(0.50f, 0.08f, 0.50f, 0.18f, 0.50f, 0.46f, 0.46f, 0.31f, 0.40f, 0.17f, 0.47f, 0.32f, 0.41f, 0.18f, 0.51f, 0.66f, 0.52f, 0.84f, 0.49f, 0.66f, 0.50f, 0.84f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "squat", title = "Bodyweight Squats", category = "Legs", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Squats build strong legs and glutes.",
            steps = listOf("Stand with your feet shoulder-width apart.", "Push your hips back and bend your knees, as if sitting on a chair.", "Keep your chest up and your heels on the floor.", "Push through your heels to stand up."),
            cues = listOf("Chest up.", "Knees in line with your toes.", "Push through your heels.", "Keep your back straight."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.58f, 0.32f, 0.68f, 0.30f, 0.57f, 0.33f, 0.67f, 0.31f, 0.51f, 0.70f, 0.53f, 0.90f, 0.49f, 0.70f, 0.51f, 0.90f),
                floatArrayOf(0.58f, 0.28f, 0.54f, 0.40f, 0.36f, 0.62f, 0.64f, 0.46f, 0.74f, 0.44f, 0.63f, 0.47f, 0.73f, 0.45f, 0.60f, 0.66f, 0.52f, 0.90f, 0.58f, 0.67f, 0.50f, 0.90f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "sumo", title = "Sumo Squats", category = "Legs", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Sumo squats work your inner thighs and glutes.",
            steps = listOf("Stand with your feet wide and toes pointing out.", "Hold your hands together at your chest.", "Bend your knees and lower your hips straight down.", "Squeeze your glutes to stand up."),
            cues = listOf("Knees over your toes.", "Keep your chest tall.", "Hips straight down.", "Squeeze your glutes."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.44f, 0.37f, 0.50f, 0.34f, 0.56f, 0.37f, 0.50f, 0.34f, 0.36f, 0.70f, 0.28f, 0.90f, 0.64f, 0.70f, 0.72f, 0.90f),
                floatArrayOf(0.50f, 0.28f, 0.50f, 0.38f, 0.50f, 0.62f, 0.43f, 0.48f, 0.50f, 0.46f, 0.57f, 0.48f, 0.50f, 0.46f, 0.33f, 0.68f, 0.28f, 0.90f, 0.67f, 0.68f, 0.72f, 0.90f)
            ),
            view = "front", prop = "none", faceUp = false
        ),
        Exercise(
            id = "revlunge", title = "Reverse Lunges", category = "Legs", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3200,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Reverse lunges are gentle on your knees.",
            steps = listOf("Stand tall with your hands on your hips.", "Step one foot back and lower until both knees bend to about 90 degrees.", "Push through your front heel to come back up, then switch legs."),
            cues = listOf("Keep your chest up.", "Front knee over your ankle.", "Lower straight down.", "Switch legs each time."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.50f, 0.37f, 0.53f, 0.50f, 0.50f, 0.37f, 0.47f, 0.50f, 0.51f, 0.70f, 0.53f, 0.90f, 0.49f, 0.70f, 0.47f, 0.90f),
                floatArrayOf(0.50f, 0.20f, 0.50f, 0.30f, 0.52f, 0.58f, 0.46f, 0.44f, 0.52f, 0.54f, 0.47f, 0.44f, 0.53f, 0.54f, 0.64f, 0.70f, 0.62f, 0.90f, 0.40f, 0.82f, 0.28f, 0.88f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "lunge", title = "Forward Lunges", category = "Legs", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3200,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Lunges work each leg on its own.",
            steps = listOf("Stand tall with your feet together.", "Step one foot forward and lower until both knees bend to about 90 degrees.", "Push off the front foot to stand up, then switch legs."),
            cues = listOf("Keep your chest up.", "Front knee over your ankle.", "Lower straight down.", "Switch legs each time."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.50f, 0.37f, 0.53f, 0.50f, 0.50f, 0.37f, 0.47f, 0.50f, 0.51f, 0.70f, 0.53f, 0.90f, 0.49f, 0.70f, 0.47f, 0.90f),
                floatArrayOf(0.50f, 0.18f, 0.50f, 0.28f, 0.50f, 0.56f, 0.47f, 0.42f, 0.50f, 0.56f, 0.50f, 0.42f, 0.52f, 0.56f, 0.70f, 0.64f, 0.70f, 0.90f, 0.38f, 0.84f, 0.24f, 0.90f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "sidelunge", title = "Side Lunges", category = "Legs", level = "Intermediate",
            timed = false, reps = 8, seconds = 0, sets = 2, restSec = 30, cycleMs = 4000,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Side lunges train your legs from a new angle.",
            steps = listOf("Stand tall with your feet hip-width apart.", "Step wide to one side and bend that knee, keeping the other leg straight.", "Push back to the middle and repeat on the other side."),
            cues = listOf("Sit back into your hip.", "Keep your chest up.", "Toes point forward.", "Push off the bent leg."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.44f, 0.38f, 0.46f, 0.46f, 0.56f, 0.38f, 0.54f, 0.46f, 0.45f, 0.70f, 0.42f, 0.90f, 0.55f, 0.70f, 0.58f, 0.90f),
                floatArrayOf(0.38f, 0.26f, 0.39f, 0.36f, 0.40f, 0.60f, 0.34f, 0.46f, 0.42f, 0.50f, 0.46f, 0.46f, 0.38f, 0.50f, 0.27f, 0.70f, 0.22f, 0.90f, 0.58f, 0.76f, 0.74f, 0.90f),
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.44f, 0.38f, 0.46f, 0.46f, 0.56f, 0.38f, 0.54f, 0.46f, 0.45f, 0.70f, 0.42f, 0.90f, 0.55f, 0.70f, 0.58f, 0.90f),
                floatArrayOf(0.62f, 0.26f, 0.61f, 0.36f, 0.60f, 0.60f, 0.66f, 0.46f, 0.58f, 0.50f, 0.54f, 0.46f, 0.62f, 0.50f, 0.73f, 0.70f, 0.78f, 0.90f, 0.42f, 0.76f, 0.26f, 0.90f)
            ),
            view = "front", prop = "none", faceUp = false
        ),
        Exercise(
            id = "calf", title = "Calf Raises", category = "Legs", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 20, cycleMs = 1800,
            ground = 0.91f, kcalPerMin = 4.0,
            intro = "Calf raises strengthen your lower legs and ankles.",
            steps = listOf("Stand tall with your feet hip-width apart.", "Rise up onto the balls of your feet.", "Pause at the top, then lower slowly."),
            cues = listOf("Rise slowly.", "Squeeze your calves.", "Stay tall.", "Lower with control."),
            keys = listOf(
                floatArrayOf(0.50f, 0.12f, 0.50f, 0.22f, 0.50f, 0.50f, 0.50f, 0.37f, 0.53f, 0.50f, 0.50f, 0.37f, 0.47f, 0.50f, 0.51f, 0.70f, 0.53f, 0.90f, 0.49f, 0.70f, 0.47f, 0.90f),
                floatArrayOf(0.50f, 0.08f, 0.50f, 0.18f, 0.50f, 0.46f, 0.50f, 0.33f, 0.53f, 0.46f, 0.50f, 0.33f, 0.47f, 0.46f, 0.51f, 0.67f, 0.53f, 0.86f, 0.49f, 0.67f, 0.47f, 0.86f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "wallsit", title = "Wall Sit", category = "Legs", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 25, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 5.0,
            intro = "The wall sit burns your thighs and builds endurance.",
            steps = listOf("Lean your back flat against a wall.", "Slide down until your knees are at 90 degrees.", "Hold this position and breathe steadily."),
            cues = listOf("Back flat on the wall.", "Knees at 90 degrees.", "Keep breathing.", "Press through your heels."),
            keys = listOf(
                floatArrayOf(0.31f, 0.30f, 0.31f, 0.40f, 0.31f, 0.62f, 0.37f, 0.50f, 0.48f, 0.57f, 0.36f, 0.50f, 0.47f, 0.57f, 0.52f, 0.62f, 0.52f, 0.90f, 0.51f, 0.62f, 0.51f, 0.90f),
                floatArrayOf(0.31f, 0.31f, 0.31f, 0.41f, 0.31f, 0.63f, 0.37f, 0.51f, 0.48f, 0.58f, 0.36f, 0.51f, 0.47f, 0.58f, 0.52f, 0.63f, 0.52f, 0.90f, 0.51f, 0.63f, 0.51f, 0.90f)
            ),
            view = "side", prop = "wall", faceUp = false
        ),
        Exercise(
            id = "stepup", title = "Step Ups", category = "Legs", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 2400,
            ground = 0.91f, kcalPerMin = 7.0,
            intro = "Step ups build strong legs, just like climbing stairs.",
            steps = listOf("Stand in front of a sturdy step or low bench.", "Place one foot on the step and push up until you stand tall.", "Step back down with control and switch legs."),
            cues = listOf("Push through your heel.", "Stand tall at the top.", "Step down slowly.", "Switch legs."),
            keys = listOf(
                floatArrayOf(0.38f, 0.12f, 0.38f, 0.22f, 0.38f, 0.50f, 0.40f, 0.38f, 0.42f, 0.50f, 0.40f, 0.38f, 0.37f, 0.50f, 0.46f, 0.64f, 0.56f, 0.83f, 0.38f, 0.70f, 0.36f, 0.90f),
                floatArrayOf(0.60f, 0.08f, 0.60f, 0.18f, 0.60f, 0.46f, 0.64f, 0.33f, 0.62f, 0.45f, 0.64f, 0.33f, 0.57f, 0.45f, 0.61f, 0.65f, 0.61f, 0.83f, 0.68f, 0.58f, 0.66f, 0.70f)
            ),
            view = "side", prop = "step", faceUp = false
        ),
        Exercise(
            id = "bridge", title = "Glute Bridges", category = "Glutes", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 25, cycleMs = 2600,
            ground = 0.80f, kcalPerMin = 5.0,
            intro = "Glute bridges strengthen your hips and lower back.",
            steps = listOf("Lie on your back with your knees bent and feet flat.", "Press through your heels and lift your hips.", "Squeeze your glutes at the top, then lower slowly."),
            cues = listOf("Squeeze your glutes.", "Push through your heels.", "Do not arch your back.", "Lower slowly."),
            keys = listOf(
                floatArrayOf(0.20f, 0.73f, 0.29f, 0.75f, 0.53f, 0.79f, 0.40f, 0.78f, 0.54f, 0.79f, 0.41f, 0.78f, 0.55f, 0.79f, 0.66f, 0.60f, 0.74f, 0.80f, 0.65f, 0.60f, 0.73f, 0.80f),
                floatArrayOf(0.20f, 0.73f, 0.30f, 0.74f, 0.52f, 0.57f, 0.40f, 0.78f, 0.54f, 0.79f, 0.41f, 0.78f, 0.55f, 0.79f, 0.68f, 0.58f, 0.74f, 0.80f, 0.67f, 0.58f, 0.73f, 0.80f)
            ),
            view = "side", prop = "none", faceUp = true
        ),
        Exercise(
            id = "sbridge", title = "Single-Leg Glute Bridges", category = "Glutes", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3000,
            ground = 0.80f, kcalPerMin = 6.0,
            intro = "This harder bridge works one side at a time.",
            steps = listOf("Lie on your back with your knees bent.", "Lift one leg straight up.", "Push through the other heel to lift your hips, then lower slowly."),
            cues = listOf("Keep your hips level.", "Squeeze your glute.", "Move slowly.", "Switch legs after each set."),
            keys = listOf(
                floatArrayOf(0.20f, 0.73f, 0.29f, 0.75f, 0.53f, 0.79f, 0.40f, 0.78f, 0.54f, 0.79f, 0.41f, 0.78f, 0.55f, 0.79f, 0.66f, 0.60f, 0.74f, 0.80f, 0.65f, 0.60f, 0.73f, 0.80f),
                floatArrayOf(0.20f, 0.73f, 0.30f, 0.74f, 0.52f, 0.57f, 0.40f, 0.78f, 0.54f, 0.79f, 0.41f, 0.78f, 0.55f, 0.79f, 0.68f, 0.58f, 0.74f, 0.80f, 0.70f, 0.47f, 0.86f, 0.36f)
            ),
            view = "side", prop = "none", faceUp = true
        ),
        Exercise(
            id = "donkey", title = "Donkey Kicks", category = "Glutes", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 25, cycleMs = 2400,
            ground = 0.81f, kcalPerMin = 5.0,
            intro = "Donkey kicks shape and strengthen your glutes.",
            steps = listOf("Start on your hands and knees.", "Keep your knee bent and lift one foot towards the ceiling.", "Squeeze your glute at the top, then lower and repeat."),
            cues = listOf("Keep your back flat.", "Squeeze at the top.", "Do not swing your leg.", "Look at the floor."),
            keys = listOf(
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.37f, 0.74f, 0.24f, 0.80f, 0.36f, 0.74f, 0.23f, 0.80f),
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.28f, 0.60f, 0.22f, 0.42f, 0.36f, 0.74f, 0.23f, 0.80f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "hydrant", title = "Fire Hydrants", category = "Glutes", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 25, cycleMs = 2400,
            ground = 0.81f, kcalPerMin = 5.0,
            intro = "Fire hydrants work the sides of your hips and glutes.",
            steps = listOf("Start on your hands and knees.", "Lift one knee out to the side, keeping it bent.", "Lower it back down with control and repeat."),
            cues = listOf("Keep your hips square.", "Move slowly.", "Core tight.", "Squeeze your glute."),
            keys = listOf(
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.37f, 0.74f, 0.24f, 0.80f, 0.36f, 0.74f, 0.23f, 0.80f),
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.40f, 0.62f, 0.28f, 0.68f, 0.36f, 0.74f, 0.23f, 0.80f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "pushup", title = "Push-ups", category = "Upper Body", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            ground = 0.81f, kcalPerMin = 7.0,
            intro = "Push-ups strengthen your chest, arms and core.",
            steps = listOf("Place your hands under your shoulders and make a straight line from head to heels.", "Lower your chest towards the floor, elbows at about 45 degrees.", "Push the floor away to return to the top."),
            cues = listOf("Keep your body in one straight line.", "Do not let your hips sag.", "Breathe in going down, out going up.", "Elbows close to your body."),
            keys = listOf(
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.60f, 0.75f, 0.64f, 0.45f, 0.68f, 0.60f, 0.70f, 0.76f, 0.79f, 0.59f, 0.70f, 0.74f, 0.79f, 0.30f, 0.73f, 0.15f, 0.79f, 0.31f, 0.73f, 0.16f, 0.79f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "kneepush", title = "Knee Push-ups", category = "Upper Body", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            ground = 0.81f, kcalPerMin = 5.0,
            intro = "Knee push-ups are a great way to build up to full push-ups.",
            steps = listOf("Kneel down and place your hands under your shoulders.", "Keep a straight line from your head to your knees.", "Lower your chest to the floor, then push back up."),
            cues = listOf("Keep your core tight.", "Straight line from head to knees.", "Elbows close to your body.", "Breathe steadily."),
            keys = listOf(
                floatArrayOf(0.84f, 0.38f, 0.75f, 0.43f, 0.52f, 0.62f, 0.76f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.36f, 0.78f, 0.22f, 0.70f, 0.37f, 0.78f, 0.23f, 0.70f),
                floatArrayOf(0.84f, 0.60f, 0.75f, 0.64f, 0.52f, 0.70f, 0.62f, 0.70f, 0.76f, 0.79f, 0.61f, 0.70f, 0.74f, 0.79f, 0.36f, 0.78f, 0.22f, 0.70f, 0.37f, 0.78f, 0.23f, 0.70f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "incline", title = "Incline Push-ups", category = "Upper Body", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            ground = 0.91f, kcalPerMin = 5.0,
            intro = "Incline push-ups are easier on your arms and shoulders.",
            steps = listOf("Place your hands on a sturdy bench or table.", "Walk your feet back until your body is in a straight line.", "Lower your chest towards the bench, then push back up."),
            cues = listOf("Straight line from head to heels.", "Core tight.", "Elbows at 45 degrees.", "Push the bench away."),
            keys = listOf(
                floatArrayOf(0.85f, 0.33f, 0.74f, 0.38f, 0.45f, 0.63f, 0.75f, 0.48f, 0.77f, 0.58f, 0.74f, 0.48f, 0.76f, 0.58f, 0.30f, 0.76f, 0.15f, 0.89f, 0.31f, 0.76f, 0.16f, 0.89f),
                floatArrayOf(0.81f, 0.43f, 0.71f, 0.48f, 0.45f, 0.66f, 0.66f, 0.57f, 0.77f, 0.58f, 0.65f, 0.57f, 0.76f, 0.58f, 0.30f, 0.77f, 0.15f, 0.89f, 0.31f, 0.77f, 0.16f, 0.89f)
            ),
            view = "side", prop = "bench", faceUp = false
        ),
        Exercise(
            id = "decline", title = "Decline Push-ups", category = "Upper Body", level = "Advanced",
            timed = false, reps = 8, seconds = 0, sets = 3, restSec = 40, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 8.0,
            intro = "Decline push-ups put extra work on your chest and shoulders.",
            steps = listOf("Place your feet on a sturdy bench and your hands on the floor.", "Keep a straight line from your head to your heels.", "Lower your head towards the floor, then push back up."),
            cues = listOf("Core tight.", "Do not let your hips sag.", "Control the way down.", "Breathe steadily."),
            keys = listOf(
                floatArrayOf(0.84f, 0.58f, 0.73f, 0.62f, 0.45f, 0.52f, 0.75f, 0.76f, 0.75f, 0.89f, 0.73f, 0.76f, 0.73f, 0.89f, 0.30f, 0.55f, 0.17f, 0.60f, 0.31f, 0.55f, 0.18f, 0.60f),
                floatArrayOf(0.84f, 0.74f, 0.73f, 0.76f, 0.45f, 0.58f, 0.64f, 0.82f, 0.75f, 0.89f, 0.62f, 0.82f, 0.73f, 0.89f, 0.30f, 0.58f, 0.17f, 0.60f, 0.31f, 0.58f, 0.18f, 0.60f)
            ),
            view = "side", prop = "boxL", faceUp = false
        ),
        Exercise(
            id = "diamond", title = "Diamond Push-ups", category = "Upper Body", level = "Advanced",
            timed = false, reps = 8, seconds = 0, sets = 3, restSec = 40, cycleMs = 2800,
            ground = 0.81f, kcalPerMin = 8.0,
            intro = "Diamond push-ups target your triceps.",
            steps = listOf("Place your hands close together under your chest, thumbs and fingers forming a diamond.", "Keep your body in a straight line.", "Lower your chest to your hands, then push back up."),
            cues = listOf("Elbows close to your body.", "Core tight.", "Straight line from head to heels.", "Push up strongly."),
            keys = listOf(
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.60f, 0.75f, 0.64f, 0.45f, 0.68f, 0.56f, 0.68f, 0.76f, 0.79f, 0.55f, 0.68f, 0.74f, 0.79f, 0.30f, 0.73f, 0.15f, 0.79f, 0.31f, 0.73f, 0.16f, 0.79f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "pike", title = "Pike Push-ups", category = "Upper Body", level = "Advanced",
            timed = false, reps = 8, seconds = 0, sets = 3, restSec = 40, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 7.0,
            intro = "Pike push-ups build strong shoulders.",
            steps = listOf("Start in a push-up position, then walk your feet in and lift your hips high.", "Bend your elbows and lower the top of your head towards the floor.", "Push back up to the pike position."),
            cues = listOf("Hips high.", "Elbows point back.", "Head between your arms.", "Press up strongly."),
            keys = listOf(
                floatArrayOf(0.71f, 0.70f, 0.64f, 0.58f, 0.46f, 0.40f, 0.65f, 0.74f, 0.67f, 0.88f, 0.63f, 0.74f, 0.65f, 0.88f, 0.38f, 0.64f, 0.30f, 0.88f, 0.39f, 0.64f, 0.31f, 0.88f),
                floatArrayOf(0.77f, 0.80f, 0.68f, 0.70f, 0.46f, 0.42f, 0.56f, 0.80f, 0.67f, 0.88f, 0.55f, 0.80f, 0.65f, 0.88f, 0.38f, 0.65f, 0.30f, 0.88f, 0.39f, 0.65f, 0.31f, 0.88f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "dips", title = "Triceps Dips", category = "Upper Body", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Dips on a chair or couch strengthen your triceps.",
            steps = listOf("Sit on the edge of a sturdy chair and place your hands beside your hips.", "Slide forward off the chair with your knees bent.", "Lower your body by bending your elbows, then push back up."),
            cues = listOf("Keep your back close to the chair.", "Elbows point back.", "Shoulders down.", "Push up strongly."),
            keys = listOf(
                floatArrayOf(0.40f, 0.25f, 0.37f, 0.38f, 0.42f, 0.62f, 0.34f, 0.52f, 0.35f, 0.62f, 0.33f, 0.52f, 0.34f, 0.62f, 0.60f, 0.66f, 0.62f, 0.90f, 0.59f, 0.66f, 0.61f, 0.90f),
                floatArrayOf(0.40f, 0.37f, 0.37f, 0.50f, 0.42f, 0.74f, 0.28f, 0.57f, 0.35f, 0.62f, 0.27f, 0.57f, 0.34f, 0.62f, 0.62f, 0.76f, 0.64f, 0.90f, 0.61f, 0.76f, 0.63f, 0.90f)
            ),
            view = "side", prop = "chair", faceUp = false
        ),
        Exercise(
            id = "plank", title = "Plank Hold", category = "Core", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 4000,
            ground = 0.81f, kcalPerMin = 4.0,
            intro = "The plank builds a strong core.",
            steps = listOf("Place your hands under your shoulders.", "Make a straight line from your head to your heels.", "Squeeze your stomach and glutes, and hold."),
            cues = listOf("Squeeze your stomach.", "Keep your hips level.", "Look at the floor.", "Breathe slowly, do not hold your breath."),
            keys = listOf(
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.53f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.65f, 0.15f, 0.79f, 0.31f, 0.65f, 0.16f, 0.79f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "sideplank", title = "Side Plank", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 20, sets = 2, restSec = 20, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 4.0,
            intro = "The side plank strengthens your sides and hips.",
            steps = listOf("Lie on your side with your elbow under your shoulder.", "Lift your hips so your body makes a straight line.", "Hold, then switch sides."),
            cues = listOf("Hips high.", "Straight line from head to feet.", "Breathe steadily.", "Stack your shoulders."),
            keys = listOf(
                floatArrayOf(0.74f, 0.46f, 0.66f, 0.52f, 0.40f, 0.62f, 0.66f, 0.74f, 0.58f, 0.88f, 0.66f, 0.30f, 0.66f, 0.16f, 0.30f, 0.74f, 0.16f, 0.88f, 0.31f, 0.74f, 0.17f, 0.88f),
                floatArrayOf(0.74f, 0.52f, 0.66f, 0.58f, 0.40f, 0.72f, 0.66f, 0.77f, 0.58f, 0.88f, 0.66f, 0.34f, 0.66f, 0.20f, 0.30f, 0.78f, 0.16f, 0.88f, 0.31f, 0.78f, 0.17f, 0.88f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "taps", title = "Shoulder Taps", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 2000,
            ground = 0.81f, kcalPerMin = 7.0,
            intro = "Shoulder taps train your core to stay steady.",
            steps = listOf("Start in a high plank with your feet slightly apart.", "Lift one hand and tap the opposite shoulder.", "Place it back and switch sides without rocking your hips."),
            cues = listOf("Keep your hips still.", "Core tight.", "Feet wide for balance.", "Move with control."),
            keys = listOf(
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.80f, 0.56f, 0.75f, 0.47f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.75f, 0.61f, 0.76f, 0.79f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f),
                floatArrayOf(0.83f, 0.38f, 0.75f, 0.43f, 0.45f, 0.54f, 0.80f, 0.56f, 0.75f, 0.47f, 0.74f, 0.61f, 0.74f, 0.79f, 0.30f, 0.66f, 0.15f, 0.79f, 0.31f, 0.66f, 0.16f, 0.79f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "birddog", title = "Bird-Dog", category = "Core", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 25, cycleMs = 4000,
            ground = 0.81f, kcalPerMin = 4.0,
            intro = "The bird-dog builds balance and a strong back.",
            steps = listOf("Start on your hands and knees.", "Reach one arm forward and the opposite leg back.", "Hold for a moment, return, then switch sides."),
            cues = listOf("Keep your hips level.", "Reach long.", "Back flat.", "Move slowly."),
            keys = listOf(
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.37f, 0.74f, 0.24f, 0.80f, 0.36f, 0.74f, 0.23f, 0.80f),
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.78f, 0.48f, 0.92f, 0.46f, 0.22f, 0.52f, 0.07f, 0.52f, 0.36f, 0.74f, 0.23f, 0.80f),
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.64f, 0.65f, 0.66f, 0.81f, 0.63f, 0.65f, 0.65f, 0.81f, 0.37f, 0.74f, 0.24f, 0.80f, 0.36f, 0.74f, 0.23f, 0.80f),
                floatArrayOf(0.77f, 0.45f, 0.66f, 0.51f, 0.37f, 0.53f, 0.78f, 0.48f, 0.92f, 0.46f, 0.63f, 0.65f, 0.65f, 0.81f, 0.37f, 0.74f, 0.24f, 0.80f, 0.22f, 0.52f, 0.07f, 0.52f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "superman", title = "Superman Hold", category = "Core", level = "Beginner",
            timed = true, reps = 0, seconds = 20, sets = 3, restSec = 20, cycleMs = 3000,
            ground = 0.80f, kcalPerMin = 4.0,
            intro = "The superman hold strengthens your lower back.",
            steps = listOf("Lie face down with your arms stretched forward.", "Lift your arms, chest and legs off the floor.", "Hold, then lower slowly."),
            cues = listOf("Squeeze your glutes.", "Look at the floor.", "Reach long.", "Breathe steadily."),
            keys = listOf(
                floatArrayOf(0.80f, 0.74f, 0.72f, 0.76f, 0.45f, 0.78f, 0.84f, 0.78f, 0.94f, 0.78f, 0.83f, 0.78f, 0.93f, 0.78f, 0.30f, 0.78f, 0.16f, 0.78f, 0.31f, 0.78f, 0.17f, 0.78f),
                floatArrayOf(0.82f, 0.66f, 0.72f, 0.71f, 0.46f, 0.74f, 0.85f, 0.64f, 0.95f, 0.60f, 0.84f, 0.64f, 0.94f, 0.60f, 0.30f, 0.70f, 0.14f, 0.62f, 0.31f, 0.70f, 0.15f, 0.62f)
            ),
            view = "side", prop = "none", faceUp = false
        ),
        Exercise(
            id = "crunch", title = "Bicycle Crunches", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 1600,
            ground = 0.80f, kcalPerMin = 7.0,
            intro = "Bicycle crunches work your abs and obliques.",
            steps = listOf("Lie on your back with your hands behind your head.", "Bring one knee in while twisting the opposite elbow towards it.", "Switch sides in a smooth pedalling motion."),
            cues = listOf("Do not pull on your neck.", "Twist from your waist.", "Keep a steady rhythm.", "Breathe out as you twist."),
            keys = listOf(
                floatArrayOf(0.26f, 0.60f, 0.33f, 0.69f, 0.53f, 0.78f, 0.30f, 0.52f, 0.27f, 0.60f, 0.31f, 0.53f, 0.28f, 0.61f, 0.64f, 0.58f, 0.72f, 0.68f, 0.74f, 0.70f, 0.90f, 0.62f),
                floatArrayOf(0.26f, 0.60f, 0.33f, 0.69f, 0.53f, 0.78f, 0.31f, 0.53f, 0.28f, 0.61f, 0.30f, 0.52f, 0.27f, 0.60f, 0.74f, 0.70f, 0.90f, 0.62f, 0.64f, 0.58f, 0.72f, 0.68f)
            ),
            view = "side", prop = "none", faceUp = true
        )
    )

    val categories = listOf("All", "Cardio", "Legs", "Glutes", "Upper Body", "Core")
}

/* ================= animated coach figure (illustrated character) ================= */

private class Outfit(val shirt: Color, val shorts: Color, val shoes: Color)

private val outfits = listOf(
    Outfit(Color(0xFF3EB54A), Color(0xFF3B3F4B), Color(0xFF2D7FE8)),
    Outfit(Color(0xFFE83A4F), Color(0xFF6B7080), Color(0xFFF05A8C)),
    Outfit(Color(0xFFFFC21F), Color(0xFF2F3B5C), Color(0xFF2D7FE8)),
    Outfit(Color(0xFF7A6BE0), Color(0xFF3B3F4B), Color(0xFFFF7A66)),
    Outfit(Color(0xFF5EB8D9), Color(0xFF4A4F5E), Color(0xFF3EB54A)),
    Outfit(Color(0xFFFF8A3D), Color(0xFF2F3B5C), Color(0xFFF5F5F5))
)

private val skinColor = Color(0xFFF2C19B)
private val hairColor = Color(0xFF5A3622)
private val propColor = Color(0xFFB08968)

private fun shade(c: Color, f: Float) = Color(c.red * f, c.green * f, c.blue * f, 1f)

@Composable
fun CoachFigure(ex: Exercise, modifier: Modifier = Modifier) {
    val keys = ex.keys
    val transition = rememberInfiniteTransition(label = "figure")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = keys.size.toFloat(),
        animationSpec = infiniteRepeatable(tween(ex.cycleMs, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val outfit = outfits[ex.look]
    val front = ex.view == "front"
    Canvas(modifier) {
        val side = size.minDimension
        val ox = (size.width - side) / 2f
        val oy = (size.height - side) / 2f
        val i = phase.toInt().coerceIn(0, keys.size - 1)
        val f = phase - i
        val e = f * f * (3f - 2f * f)
        val a = keys[i]
        val b = keys[(i + 1) % keys.size]
        fun pt(j: Int) = Offset(
            ox + (a[2 * j] + (b[2 * j] - a[2 * j]) * e) * side,
            oy + (a[2 * j + 1] + (b[2 * j + 1] - a[2 * j + 1]) * e) * side
        )
        fun line(p: Offset, q: Offset, w: Float, c: Color) =
            drawLine(c, p, q, strokeWidth = w, cap = StrokeCap.Round)

        // ground shadow
        val gy = oy + ex.ground * side + side * 0.02f
        drawOval(
            Color(0x2D1565E8), Offset(ox + side * 0.10f, gy - side * 0.015f), Size(side * 0.80f, side * 0.035f)
        )

        // props
        val rr = CornerRadius(side * 0.017f, side * 0.017f)
        fun box(x1: Float, y1: Float, x2: Float) =
            drawRoundRect(propColor, Offset(ox + x1 * side, oy + y1 * side), Size((x2 - x1) * side, gy - (oy + y1 * side)), rr)
        when (ex.prop) {
            "wall" -> {
                drawRect(Color(0xFFC8D2E4), Offset(ox + side * 0.14f, oy + side * 0.06f), Size(side * 0.10f, gy - (oy + side * 0.06f)))
                drawRect(Color(0xFFA0ACC4), Offset(ox + side * 0.22f, oy + side * 0.06f), Size(side * 0.02f, gy - (oy + side * 0.06f)))
            }
            "step" -> box(0.50f, 0.83f, 0.82f)
            "bench" -> box(0.66f, 0.585f, 0.90f)
            "boxL" -> box(0.08f, 0.605f, 0.30f)
            "chair" -> box(0.14f, 0.625f, 0.34f)
        }

        val head = pt(0)
        val neck = pt(1)
        val hip = pt(2)
        val far = if (front) 1f else 0.82f

        fun leg(k: Int, ft: Int, sh: Float) {
            val kn = pt(k)
            val fo = pt(ft)
            line(hip, kn, side * 0.078f, shade(outfit.shorts, sh))
            line(kn, fo, side * 0.05f, shade(skinColor, sh))
            val dx = fo.x - kn.x
            val dy = fo.y - kn.y
            val face = if (head.x >= neck.x || front) 1f else -1f
            val tx: Float
            val ty: Float
            if (kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.5f) {
                tx = 0f; ty = 1f
            } else {
                tx = if (front) (if (fo.x >= hip.x) 1f else -1f) else face
                ty = 0f
            }
            line(fo, Offset(fo.x + tx * side * 0.05f, fo.y + ty * side * 0.05f), side * 0.045f, shade(outfit.shoes, sh))
        }

        fun arm(el: Int, hd: Int, sh: Float) {
            val elbow = pt(el)
            val hand = pt(hd)
            val mid = Offset(neck.x + (elbow.x - neck.x) * 0.4f, neck.y + (elbow.y - neck.y) * 0.4f)
            line(neck, elbow, side * 0.045f, shade(skinColor, sh))
            line(neck, mid, side * 0.052f, shade(outfit.shirt, sh))
            line(elbow, hand, side * 0.04f, shade(skinColor, sh))
            drawCircle(shade(skinColor, sh), side * 0.027f, hand)
        }

        // far side, body, near side
        leg(9, 10, far)
        arm(5, 6, far)
        line(neck, hip, side * 0.105f, outfit.shirt)
        drawCircle(outfit.shirt, side * 0.056f, neck)
        val kn = pt(7)
        line(hip, Offset((hip.x * 3 + kn.x) / 4, (hip.y * 3 + kn.y) / 4), side * 0.095f, outfit.shorts)
        leg(7, 8, 1f)
        arm(3, 4, 1f)

        // head
        line(neck, head, side * 0.03f, skinColor)
        val dir = if (head.x - neck.x >= 0f || front) 1f else -1f
        val r = side * 0.062f
        val eye = Color(0xFF281E1E)
        if (front) {
            drawCircle(hairColor, r * 1.08f, Offset(head.x, head.y - r * 0.2f))
            drawCircle(skinColor, r * 0.92f, Offset(head.x, head.y + r * 0.12f))
            drawCircle(eye, side * 0.009f, Offset(head.x - r * 0.35f, head.y + r * 0.12f))
            drawCircle(eye, side * 0.009f, Offset(head.x + r * 0.35f, head.y + r * 0.12f))
        } else {
            drawCircle(hairColor, r * 1.08f, Offset(head.x - dir * r * 0.25f, head.y - r * 0.2f))
            drawCircle(skinColor, r * 0.86f, Offset(head.x + dir * r * 0.2f, head.y + r * 0.15f))
            if (ex.faceUp) drawCircle(eye, side * 0.009f, Offset(head.x, head.y - r * 0.35f))
            else drawCircle(eye, side * 0.009f, Offset(head.x + dir * r * 0.55f, head.y + r * 0.05f))
        }
    }
}

/* ================= list of workouts ================= */

@Composable
fun CoachHub(onOpen: (Exercise) -> Unit) {
    var category by remember { mutableStateOf("All") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(FitColors.Blue, FitColors.Teal)))
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(18.dp).fillMaxWidth(0.6f)) {
                Text("Video Coach", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(
                    "Follow your animated coach. Turn on the voice for spoken instructions.",
                    fontSize = 12.sp, color = Color.White.copy(alpha = .92f)
                )
            }
            val first = CoachData.exercises[1]
            CoachFigure(first, Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(116.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CoachData.categories.forEach { c ->
                val on = c == category
                Text(
                    c, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (on) Color.White else FitColors.Ink,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (on) FitColors.Ink else Color.White)
                        .clickable { category = c }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        CoachData.exercises.filter { category == "All" || it.category == category }.forEach { ex ->
            FitCard(Color.White, Modifier.fillMaxWidth().clickable { onOpen(ex) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(86.dp).clip(RoundedCornerShape(16.dp)).background(FitColors.Cream)
                    ) {
                        CoachFigure(ex, Modifier.fillMaxSize().padding(4.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ex.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
                        Text(ex.summary, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
                        Text(
                            ex.category + " · " + ex.level, fontSize = 11.sp,
                            color = FitColors.Ink.copy(alpha = .5f), modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

/* ================= one workout with the coach ================= */

private enum class Phase { Idle, Intro, Countdown, Work, Rest, Done }

@Composable
fun CoachPlayer(
    ex: Exercise,
    voiceOn: Boolean,
    voiceProblem: String?,
    actions: ExtraActions,
    onBack: () -> Unit
) {
    var phase by remember { mutableStateOf(Phase.Idle) }
    var runId by remember { mutableIntStateOf(0) }
    var figureKey by remember { mutableIntStateOf(0) }
    var caption by remember { mutableStateOf(ex.intro) }
    var setNo by remember { mutableIntStateOf(1) }
    var count by remember { mutableIntStateOf(0) }
    var restLeft by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf<Triple<String, Int, Int>?>(null) }

    BackHandler { actions.stopSpeak(); onBack() }
    DisposableEffect(Unit) { onDispose { actions.stopSpeak() } }

    LaunchedEffect(runId) {
        if (runId == 0) return@LaunchedEffect
        val startedAt = System.currentTimeMillis()
        fun say(text: String, interrupt: Boolean = false) = actions.speak(text, interrupt)

        phase = Phase.Intro
        caption = ex.steps.first()
        say("Let's do ${ex.title}. ${ex.steps.first()}", true)
        delay(if (voiceOn) 1500L + ex.steps.first().length * 55L else 1500L)

        phase = Phase.Countdown
        for (n in 3 downTo 1) {
            countdown = n
            caption = "Get ready..."
            say("$n", true)
            delay(1000)
        }

        for (s in 1..ex.sets) {
            setNo = s
            phase = Phase.Work
            figureKey += 1
            caption = ex.cues.first()
            say(if (s == 1) "Go!" else "Set $s. Go!", true)

            if (!ex.timed) {
                count = 0
                delay(700)
                for (r in 1..ex.reps) {
                    delay(ex.cycleMs.toLong())
                    count = r
                    caption = ex.cues[(r / 3) % ex.cues.size]
                    say("$r", true)
                    if (r == ex.reps / 2) say("Halfway there!", false)
                    if (r == ex.reps - 1) say("One more!", false)
                }
            } else {
                say(ex.cues.first(), false)
                for (left in ex.seconds downTo 1) {
                    count = left
                    val elapsed = ex.seconds - left
                    if (elapsed > 0 && elapsed % 8 == 0) caption = ex.cues[(elapsed / 8) % ex.cues.size]
                    when {
                        left == ex.seconds / 2 -> say("Halfway there. Keep going!", true)
                        left == 10 -> say("Ten seconds left.", true)
                        left <= 3 -> say("$left", true)
                        elapsed > 0 && elapsed % 10 == 5 -> say(ex.cues[(elapsed / 10) % ex.cues.size], false)
                    }
                    delay(1000)
                }
                count = 0
            }

            if (s < ex.sets) {
                phase = Phase.Rest
                caption = "Great set! Rest and breathe."
                say("Great set! Rest for ${ex.restSec} seconds.", true)
                for (left in ex.restSec downTo 1) {
                    restLeft = left
                    if (left == 3) say("Get ready.", false)
                    delay(1000)
                }
            }
        }

        phase = Phase.Done
        val minutes = max(1, ((System.currentTimeMillis() - startedAt) / 60000L).toInt())
        val kcal = (ex.kcalPerMin * minutes).toInt()
        caption = "Workout complete. Great job!"
        say("Workout complete! Great job. You burned about $kcal calories.", true)
        actions.finishWorkout(ex.title, minutes, kcal)
        done = Triple(ex.title, minutes, kcal)
        runId = 0
    }

    val running = phase == Phase.Intro || phase == Phase.Countdown || phase == Phase.Work || phase == Phase.Rest

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.clip(CircleShape).clickable { actions.stopSpeak(); onBack() }.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = FitColors.Ink)
            Spacer(Modifier.width(6.dp))
            Text("Video Coach", fontWeight = FontWeight.Bold, color = FitColors.Ink)
        }

        // animated coach
        Box(
            Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFE6F0FF), Color(0xFFFFFFFF))))
        ) {
            key(figureKey) {
                CoachFigure(ex, Modifier.fillMaxSize().padding(10.dp))
            }
            Text(
                ex.title, fontSize = 18.sp, fontWeight = FontWeight.Black, color = FitColors.Ink,
                modifier = Modifier.align(Alignment.TopStart).padding(14.dp)
            )
            val big = when (phase) {
                Phase.Countdown -> "$countdown"
                Phase.Work -> if (ex.timed) "${count}s" else "$count / ${ex.reps}"
                Phase.Rest -> "Rest ${restLeft}s"
                Phase.Done -> "Done!"
                else -> ""
            }
            if (big.isNotEmpty()) {
                Text(
                    big, fontSize = 28.sp, fontWeight = FontWeight.Black, color = FitColors.Blue,
                    modifier = Modifier.align(Alignment.TopEnd).padding(14.dp)
                )
            }
            if (phase == Phase.Work || phase == Phase.Rest) {
                Text(
                    "Set $setNo of ${ex.sets}", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = FitColors.Ink.copy(alpha = .6f),
                    modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                )
            }
        }

        // coach speech bubble
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(FitColors.Blue),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.SportsGymnastics, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(12.dp)
            ) {
                Text("Coach", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FitColors.Blue)
                Text(caption, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = FitColors.Ink)
            }
        }

        // start / stop
        Box(
            Modifier.fillMaxWidth().clip(CircleShape)
                .background(if (running) FitColors.Coral else FitColors.Ink)
                .clickable {
                    if (running) {
                        runId = 0
                        phase = Phase.Idle
                        caption = ex.intro
                        actions.stopSpeak()
                    } else {
                        runId += 1
                    }
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    running -> "Stop"
                    phase == Phase.Done -> "Start again"
                    else -> "Start workout"
                },
                color = if (running) FitColors.Ink else Color.White,
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }

        // voice switch
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice coach (English)", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                        Text(
                            "Spoken instructions, rep counts and reminders",
                            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
                        )
                    }
                    Switch(checked = voiceOn, onCheckedChange = { actions.setVoice(it) })
                }
                if (voiceOn && voiceProblem != null) {
                    Text(voiceProblem, fontSize = 12.sp, color = FitColors.Red, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        // how to
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("How to do it", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                ex.steps.forEachIndexed { i, s ->
                    Row {
                        Text("${i + 1}.", fontWeight = FontWeight.Bold, color = FitColors.Blue, modifier = Modifier.width(22.dp))
                        Text(s, fontSize = 13.sp, color = FitColors.Ink)
                    }
                }
                Text("Coach tips", fontWeight = FontWeight.Bold, color = FitColors.Ink, modifier = Modifier.padding(top = 6.dp))
                ex.cues.forEach { Text("• $it", fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .8f)) }
                Text(
                    "Stop if you feel pain or dizziness. If you have a health condition, check with your doctor first.",
                    fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f), textAlign = TextAlign.Start,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }

    done?.let { (title, minutes, kcal) ->
        WorkoutCompleteDialog(title, minutes, kcal) { done = null }
    }
}
