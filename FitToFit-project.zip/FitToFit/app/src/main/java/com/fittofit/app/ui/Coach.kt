package com.fittofit.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max

private typealias Pt = Pair<Float, Float>

/** One body position: head, neck, hip, then elbow/hand (left, right), knee/foot (left, right). */
private fun pose(
    head: Pt, neck: Pt, hip: Pt,
    eL: Pt, hL: Pt, eR: Pt, hR: Pt,
    kL: Pt, fL: Pt, kR: Pt, fR: Pt
): FloatArray = floatArrayOf(
    head.first, head.second, neck.first, neck.second, hip.first, hip.second,
    eL.first, eL.second, hL.first, hL.second, eR.first, eR.second, hR.first, hR.second,
    kL.first, kL.second, fL.first, fL.second, kR.first, kR.second, fR.first, fR.second
)

class Exercise(
    val id: String,
    val title: String,
    val category: String,
    val level: String,
    val timed: Boolean,
    val reps: Int,
    val seconds: Int,
    val sets: Int,
    val restSec: Int,
    val cycleMs: Int,
    val ground: Float,
    val kcalPerMin: Double,
    val intro: String,
    val steps: List<String>,
    val cues: List<String>,
    val keys: List<FloatArray>
) {
    val summary: String
        get() = if (timed) "$sets sets × $seconds sec" else "$sets sets × $reps reps"
}

object CoachData {

    // ---------- poses (side view faces right; coordinates are 0..1 inside a square) ----------
    private val standSide = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.50f to 0.37f, 0.53f to 0.50f, 0.50f to 0.37f, 0.47f to 0.50f,
        0.51f to 0.70f, 0.53f to 0.90f, 0.49f to 0.70f, 0.47f to 0.90f
    )

    private val jackDown = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.40f to 0.36f, 0.37f to 0.50f, 0.60f to 0.36f, 0.63f to 0.50f,
        0.46f to 0.70f, 0.45f to 0.90f, 0.54f to 0.70f, 0.55f to 0.90f
    )
    private val jackUp = pose(
        0.50f to 0.08f, 0.50f to 0.18f, 0.50f to 0.46f,
        0.36f to 0.26f, 0.30f to 0.08f, 0.64f to 0.26f, 0.70f to 0.08f,
        0.38f to 0.64f, 0.30f to 0.84f, 0.62f to 0.64f, 0.70f to 0.84f
    )

    private val squatUp = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.58f to 0.32f, 0.68f to 0.30f, 0.57f to 0.33f, 0.67f to 0.31f,
        0.51f to 0.70f, 0.53f to 0.90f, 0.49f to 0.70f, 0.51f to 0.90f
    )
    private val squatDown = pose(
        0.58f to 0.28f, 0.54f to 0.40f, 0.36f to 0.62f,
        0.64f to 0.46f, 0.74f to 0.44f, 0.63f to 0.47f, 0.73f to 0.45f,
        0.60f to 0.66f, 0.52f to 0.90f, 0.58f to 0.67f, 0.50f to 0.90f
    )

    private val pushUp = pose(
        0.83f to 0.38f, 0.75f to 0.43f, 0.45f to 0.54f,
        0.75f to 0.61f, 0.76f to 0.79f, 0.74f to 0.61f, 0.74f to 0.79f,
        0.30f to 0.66f, 0.15f to 0.79f, 0.31f to 0.66f, 0.16f to 0.79f
    )
    private val pushDown = pose(
        0.83f to 0.60f, 0.75f to 0.64f, 0.45f to 0.68f,
        0.60f to 0.70f, 0.76f to 0.79f, 0.59f to 0.70f, 0.74f to 0.79f,
        0.30f to 0.73f, 0.15f to 0.79f, 0.31f to 0.73f, 0.16f to 0.79f
    )
    private val plankBreath = pose(
        0.83f to 0.38f, 0.75f to 0.43f, 0.45f to 0.53f,
        0.75f to 0.61f, 0.76f to 0.79f, 0.74f to 0.61f, 0.74f to 0.79f,
        0.30f to 0.65f, 0.15f to 0.79f, 0.31f to 0.65f, 0.16f to 0.79f
    )

    private val lungeDown = pose(
        0.50f to 0.18f, 0.50f to 0.28f, 0.50f to 0.56f,
        0.47f to 0.42f, 0.50f to 0.56f, 0.50f to 0.42f, 0.52f to 0.56f,
        0.70f to 0.64f, 0.70f to 0.90f, 0.38f to 0.84f, 0.24f to 0.90f
    )

    private val kneeLeft = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.56f to 0.36f, 0.62f to 0.26f, 0.44f to 0.38f, 0.40f to 0.48f,
        0.62f to 0.46f, 0.58f to 0.64f, 0.49f to 0.70f, 0.47f to 0.90f
    )
    private val kneeRight = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.44f to 0.38f, 0.40f to 0.48f, 0.56f to 0.36f, 0.62f to 0.26f,
        0.49f to 0.70f, 0.47f to 0.90f, 0.62f to 0.46f, 0.58f to 0.64f
    )

    private val climbA = pose(
        0.83f to 0.38f, 0.75f to 0.43f, 0.45f to 0.54f,
        0.75f to 0.61f, 0.76f to 0.79f, 0.74f to 0.61f, 0.74f to 0.79f,
        0.60f to 0.62f, 0.54f to 0.76f, 0.31f to 0.66f, 0.16f to 0.79f
    )
    private val climbB = pose(
        0.83f to 0.38f, 0.75f to 0.43f, 0.45f to 0.54f,
        0.75f to 0.61f, 0.76f to 0.79f, 0.74f to 0.61f, 0.74f to 0.79f,
        0.30f to 0.66f, 0.15f to 0.79f, 0.60f to 0.62f, 0.54f to 0.76f
    )

    private val walkA = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.46f to 0.38f, 0.42f to 0.50f, 0.54f to 0.37f, 0.59f to 0.48f,
        0.56f to 0.70f, 0.62f to 0.90f, 0.45f to 0.70f, 0.38f to 0.88f
    )
    private val walkB = pose(
        0.50f to 0.12f, 0.50f to 0.22f, 0.50f to 0.50f,
        0.54f to 0.37f, 0.59f to 0.48f, 0.46f to 0.38f, 0.42f to 0.50f,
        0.45f to 0.70f, 0.38f to 0.88f, 0.56f to 0.70f, 0.62f to 0.90f
    )

    val exercises: List<Exercise> = listOf(
        Exercise(
            id = "walk", title = "Brisk Walk", category = "Cardio", level = "Beginner",
            timed = true, reps = 0, seconds = 45, sets = 2, restSec = 20, cycleMs = 1100,
            ground = 0.91f, kcalPerMin = 5.0,
            intro = "A brisk walk warms up your whole body.",
            steps = listOf(
                "Stand tall with your shoulders relaxed.",
                "Swing your arms naturally as you step.",
                "Take quick, even steps and breathe steadily."
            ),
            cues = listOf("Keep your head up.", "Swing your arms.", "Breathe in and out evenly.", "Land softly on your heels."),
            keys = listOf(walkA, walkB)
        ),
        Exercise(
            id = "jacks", title = "Jumping Jacks", category = "Cardio", level = "Beginner",
            timed = false, reps = 15, seconds = 0, sets = 3, restSec = 20, cycleMs = 1100,
            ground = 0.91f, kcalPerMin = 8.0,
            intro = "Jumping jacks raise your heart rate fast.",
            steps = listOf(
                "Stand with your feet together and arms by your sides.",
                "Jump your feet apart while raising your arms overhead.",
                "Jump back to the start and repeat."
            ),
            cues = listOf("Land softly on the balls of your feet.", "Keep your core tight.", "Stay light and bouncy.", "Breathe steadily."),
            keys = listOf(jackDown, jackUp)
        ),
        Exercise(
            id = "squat", title = "Squats", category = "Strength", level = "Beginner",
            timed = false, reps = 12, seconds = 0, sets = 3, restSec = 30, cycleMs = 3000,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Squats build strong legs and glutes.",
            steps = listOf(
                "Stand with your feet shoulder-width apart.",
                "Push your hips back and bend your knees, as if sitting on a chair.",
                "Keep your chest up and your heels on the floor.",
                "Push through your heels to stand up."
            ),
            cues = listOf("Chest up.", "Knees in line with your toes.", "Push through your heels.", "Keep your back straight."),
            keys = listOf(squatUp, squatDown)
        ),
        Exercise(
            id = "pushup", title = "Push-ups", category = "Strength", level = "Intermediate",
            timed = false, reps = 10, seconds = 0, sets = 3, restSec = 30, cycleMs = 2800,
            ground = 0.81f, kcalPerMin = 7.0,
            intro = "Push-ups strengthen your chest, arms and core.",
            steps = listOf(
                "Place your hands under your shoulders and make a straight line from head to heels.",
                "Lower your chest towards the floor, elbows at about 45 degrees.",
                "Push the floor away to return to the top."
            ),
            cues = listOf("Keep your body in one straight line.", "Do not let your hips sag.", "Breathe in going down, out going up.", "Elbows close to your body."),
            keys = listOf(pushUp, pushDown)
        ),
        Exercise(
            id = "plank", title = "Plank Hold", category = "Core", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 4000,
            ground = 0.81f, kcalPerMin = 4.0,
            intro = "The plank builds a strong core.",
            steps = listOf(
                "Place your hands under your shoulders.",
                "Make a straight line from your head to your heels.",
                "Squeeze your stomach and glutes, and hold."
            ),
            cues = listOf("Squeeze your stomach.", "Keep your hips level.", "Look at the floor.", "Breathe slowly, do not hold your breath."),
            keys = listOf(pushUp, plankBreath)
        ),
        Exercise(
            id = "lunge", title = "Lunges", category = "Strength", level = "Beginner",
            timed = false, reps = 10, seconds = 0, sets = 2, restSec = 30, cycleMs = 3200,
            ground = 0.91f, kcalPerMin = 6.0,
            intro = "Lunges work each leg on its own.",
            steps = listOf(
                "Stand tall with your feet together.",
                "Step one foot forward and lower until both knees bend to about 90 degrees.",
                "Push off the front foot to stand up, then switch legs."
            ),
            cues = listOf("Keep your chest up.", "Front knee over your ankle.", "Lower straight down.", "Switch legs each time."),
            keys = listOf(standSide, lungeDown)
        ),
        Exercise(
            id = "knees", title = "High Knees", category = "Cardio", level = "Beginner",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 800,
            ground = 0.91f, kcalPerMin = 9.0,
            intro = "High knees get your heart pumping.",
            steps = listOf(
                "Stand tall with your feet hip-width apart.",
                "Run on the spot, driving each knee up to hip height.",
                "Pump your arms and stay on the balls of your feet."
            ),
            cues = listOf("Drive your knees up.", "Pump your arms.", "Stay tall.", "Keep a quick rhythm."),
            keys = listOf(kneeLeft, kneeRight)
        ),
        Exercise(
            id = "climbers", title = "Mountain Climbers", category = "Core", level = "Intermediate",
            timed = true, reps = 0, seconds = 30, sets = 3, restSec = 20, cycleMs = 900,
            ground = 0.81f, kcalPerMin = 9.0,
            intro = "Mountain climbers work your core and heart together.",
            steps = listOf(
                "Start in a high plank with your hands under your shoulders.",
                "Drive one knee towards your chest, then switch quickly.",
                "Keep your hips low and your core tight."
            ),
            cues = listOf("Keep your hips low.", "Fast feet.", "Core tight.", "Breathe steadily."),
            keys = listOf(climbA, climbB)
        )
    )

    val categories = listOf("All", "Cardio", "Strength", "Core")
}

/* ================= animated coach figure ================= */

@Composable
fun StickFigure(
    keys: List<FloatArray>,
    cycleMs: Int,
    ground: Float,
    modifier: Modifier = Modifier,
    body: Color = FitColors.Ink,
    headColor: Color = FitColors.Coral
) {
    val transition = rememberInfiniteTransition(label = "figure")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = keys.size.toFloat(),
        animationSpec = infiniteRepeatable(tween(cycleMs, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier) {
        val side = size.minDimension
        val ox = (size.width - side) / 2f
        val oy = (size.height - side) / 2f
        val i = phase.toInt().coerceIn(0, keys.size - 1)
        val f = phase - i
        val e = f * f * (3f - 2f * f)
        val a = keys[i]
        val b = keys[(i + 1) % keys.size]
        fun pt(j: Int) = Offset(
            ox + (a[2 * j] + (b[2 * j] - a[2 * j]) * e) * side,
            oy + (a[2 * j + 1] + (b[2 * j + 1] - a[2 * j + 1]) * e) * side
        )

        val sw = side * 0.035f
        val groundY = oy + ground * side + sw * 1.2f
        drawLine(
            body.copy(alpha = 0.25f),
            Offset(ox + side * 0.04f, groundY), Offset(ox + side * 0.96f, groundY),
            strokeWidth = sw * 0.6f, cap = StrokeCap.Round
        )

        val neck = pt(1)
        val hip = pt(2)
        val far = body.copy(alpha = 0.45f)

        // limbs on the far side
        drawLine(far, hip, pt(9), sw, StrokeCap.Round)
        drawLine(far, pt(9), pt(10), sw, StrokeCap.Round)
        drawLine(far, neck, pt(5), sw, StrokeCap.Round)
        drawLine(far, pt(5), pt(6), sw, StrokeCap.Round)

        // body
        drawLine(body, neck, hip, sw * 1.7f, StrokeCap.Round)

        // limbs on the near side
        drawLine(body, hip, pt(7), sw, StrokeCap.Round)
        drawLine(body, pt(7), pt(8), sw, StrokeCap.Round)
        drawLine(body, neck, pt(3), sw, StrokeCap.Round)
        drawLine(body, pt(3), pt(4), sw, StrokeCap.Round)

        drawCircle(headColor, radius = side * 0.06f, center = pt(0))
    }
}

/* ================= list of workouts ================= */

@Composable
fun CoachHub(onOpen: (Exercise) -> Unit) {
    var category by remember { mutableStateOf("All") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(FitColors.Blue, FitColors.Teal)))
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(18.dp).fillMaxWidth(0.6f)) {
                Text("Video Coach", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(
                    "Follow your animated coach. Turn on the voice for spoken instructions.",
                    fontSize = 12.sp, color = Color.White.copy(alpha = .92f)
                )
            }
            val first = CoachData.exercises[1]
            StickFigure(
                first.keys, first.cycleMs, first.ground,
                Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(116.dp),
                body = Color.White, headColor = FitColors.Yellow
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CoachData.categories.forEach { c ->
                val on = c == category
                Text(
                    c, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (on) Color.White else FitColors.Ink,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (on) FitColors.Ink else Color.White)
                        .clickable { category = c }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        CoachData.exercises.filter { category == "All" || it.category == category }.forEach { ex ->
            FitCard(Color.White, Modifier.fillMaxWidth().clickable { onOpen(ex) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(86.dp).clip(RoundedCornerShape(16.dp)).background(FitColors.Cream)
                    ) {
                        StickFigure(ex.keys, ex.cycleMs, ex.ground, Modifier.fillMaxSize().padding(4.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ex.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
                        Text(ex.summary, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
                        Text(
                            ex.category + " · " + ex.level, fontSize = 11.sp,
                            color = FitColors.Ink.copy(alpha = .5f), modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

/* ================= one workout with the coach ================= */

private enum class Phase { Idle, Intro, Countdown, Work, Rest, Done }

@Composable
fun CoachPlayer(
    ex: Exercise,
    voiceOn: Boolean,
    voiceProblem: String?,
    actions: ExtraActions,
    onBack: () -> Unit
) {
    var phase by remember { mutableStateOf(Phase.Idle) }
    var runId by remember { mutableIntStateOf(0) }
    var figureKey by remember { mutableIntStateOf(0) }
    var caption by remember { mutableStateOf(ex.intro) }
    var setNo by remember { mutableIntStateOf(1) }
    var count by remember { mutableIntStateOf(0) }
    var restLeft by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf<Triple<String, Int, Int>?>(null) }

    BackHandler { actions.stopSpeak(); onBack() }
    DisposableEffect(Unit) { onDispose { actions.stopSpeak() } }

    LaunchedEffect(runId) {
        if (runId == 0) return@LaunchedEffect
        val startedAt = System.currentTimeMillis()
        fun say(text: String, interrupt: Boolean = false) = actions.speak(text, interrupt)

        phase = Phase.Intro
        caption = ex.steps.first()
        say("Let's do ${ex.title}. ${ex.steps.first()}", true)
        delay(if (voiceOn) 1500L + ex.steps.first().length * 55L else 1500L)

        phase = Phase.Countdown
        for (n in 3 downTo 1) {
            countdown = n
            caption = "Get ready..."
            say("$n", true)
            delay(1000)
        }

        for (s in 1..ex.sets) {
            setNo = s
            phase = Phase.Work
            figureKey += 1
            caption = ex.cues.first()
            say(if (s == 1) "Go!" else "Set $s. Go!", true)

            if (!ex.timed) {
                count = 0
                delay(700)
                for (r in 1..ex.reps) {
                    delay(ex.cycleMs.toLong())
                    count = r
                    caption = ex.cues[(r / 3) % ex.cues.size]
                    say("$r", true)
                    if (r == ex.reps / 2) say("Halfway there!", false)
                    if (r == ex.reps - 1) say("One more!", false)
                }
            } else {
                say(ex.cues.first(), false)
                for (left in ex.seconds downTo 1) {
                    count = left
                    val elapsed = ex.seconds - left
                    if (elapsed > 0 && elapsed % 8 == 0) caption = ex.cues[(elapsed / 8) % ex.cues.size]
                    when {
                        left == ex.seconds / 2 -> say("Halfway there. Keep going!", true)
                        left == 10 -> say("Ten seconds left.", true)
                        left <= 3 -> say("$left", true)
                        elapsed > 0 && elapsed % 10 == 5 -> say(ex.cues[(elapsed / 10) % ex.cues.size], false)
                    }
                    delay(1000)
                }
                count = 0
            }

            if (s < ex.sets) {
                phase = Phase.Rest
                caption = "Great set! Rest and breathe."
                say("Great set! Rest for ${ex.restSec} seconds.", true)
                for (left in ex.restSec downTo 1) {
                    restLeft = left
                    if (left == 3) say("Get ready.", false)
                    delay(1000)
                }
            }
        }

        phase = Phase.Done
        val minutes = max(1, ((System.currentTimeMillis() - startedAt) / 60000L).toInt())
        val kcal = (ex.kcalPerMin * minutes).toInt()
        caption = "Workout complete. Great job!"
        say("Workout complete! Great job. You burned about $kcal calories.", true)
        actions.finishWorkout(ex.title, minutes, kcal)
        done = Triple(ex.title, minutes, kcal)
        runId = 0
    }

    val running = phase == Phase.Intro || phase == Phase.Countdown || phase == Phase.Work || phase == Phase.Rest

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.clip(CircleShape).clickable { actions.stopSpeak(); onBack() }.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = FitColors.Ink)
            Spacer(Modifier.width(6.dp))
            Text("Video Coach", fontWeight = FontWeight.Bold, color = FitColors.Ink)
        }

        // animated coach
        Box(
            Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFE6F0FF), Color(0xFFFFFFFF))))
        ) {
            key(figureKey) {
                StickFigure(ex.keys, ex.cycleMs, ex.ground, Modifier.fillMaxSize().padding(10.dp))
            }
            Text(
                ex.title, fontSize = 18.sp, fontWeight = FontWeight.Black, color = FitColors.Ink,
                modifier = Modifier.align(Alignment.TopStart).padding(14.dp)
            )
            val big = when (phase) {
                Phase.Countdown -> "$countdown"
                Phase.Work -> if (ex.timed) "${count}s" else "$count / ${ex.reps}"
                Phase.Rest -> "Rest ${restLeft}s"
                Phase.Done -> "Done!"
                else -> ""
            }
            if (big.isNotEmpty()) {
                Text(
                    big, fontSize = 28.sp, fontWeight = FontWeight.Black, color = FitColors.Blue,
                    modifier = Modifier.align(Alignment.TopEnd).padding(14.dp)
                )
            }
            if (phase == Phase.Work || phase == Phase.Rest) {
                Text(
                    "Set $setNo of ${ex.sets}", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = FitColors.Ink.copy(alpha = .6f),
                    modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)
                )
            }
        }

        // coach speech bubble
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(FitColors.Blue),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.SportsGymnastics, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(12.dp)
            ) {
                Text("Coach", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FitColors.Blue)
                Text(caption, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = FitColors.Ink)
            }
        }

        // start / stop
        Box(
            Modifier.fillMaxWidth().clip(CircleShape)
                .background(if (running) FitColors.Coral else FitColors.Ink)
                .clickable {
                    if (running) {
                        runId = 0
                        phase = Phase.Idle
                        caption = ex.intro
                        actions.stopSpeak()
                    } else {
                        runId += 1
                    }
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    running -> "Stop"
                    phase == Phase.Done -> "Start again"
                    else -> "Start workout"
                },
                color = if (running) FitColors.Ink else Color.White,
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }

        // voice switch
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice coach (English)", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                        Text(
                            "Spoken instructions, rep counts and reminders",
                            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
                        )
                    }
                    Switch(checked = voiceOn, onCheckedChange = { actions.setVoice(it) })
                }
                if (voiceOn && voiceProblem != null) {
                    Text(voiceProblem, fontSize = 12.sp, color = FitColors.Red, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        // how to
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("How to do it", fontWeight = FontWeight.Bold, color = FitColors.Ink)
                ex.steps.forEachIndexed { i, s ->
                    Row {
                        Text("${i + 1}.", fontWeight = FontWeight.Bold, color = FitColors.Blue, modifier = Modifier.width(22.dp))
                        Text(s, fontSize = 13.sp, color = FitColors.Ink)
                    }
                }
                Text("Coach tips", fontWeight = FontWeight.Bold, color = FitColors.Ink, modifier = Modifier.padding(top = 6.dp))
                ex.cues.forEach { Text("• $it", fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .8f)) }
                Text(
                    "Stop if you feel pain or dizziness. If you have a health condition, check with your doctor first.",
                    fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f), textAlign = TextAlign.Start,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }

    done?.let { (title, minutes, kcal) ->
        WorkoutCompleteDialog(title, minutes, kcal) { done = null }
    }
}
