package com.fittofit.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.DayPlan
import com.fittofit.app.DietData
import com.fittofit.app.DietPlanner
import com.fittofit.app.Dish
import com.fittofit.app.FitUiState
import com.fittofit.app.PlanMeal
import com.fittofit.app.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import kotlin.math.roundToInt

/* ---------------- food photos (free Wikipedia images, saved on the phone after the first load) ---------------- */

private object FoodPhotos {
    fun get(ctx: Context, title: String): Bitmap? {
        val name = title.lowercase().replace(Regex("[^a-z0-9]"), "_")
        val dir = File(ctx.cacheDir, "foodphotos").apply { mkdirs() }
        val file = File(dir, "$name.jpg")
        if (file.exists() && file.length() > 1000) {
            return BitmapFactory.decodeFile(file.absolutePath)
        }
        return try {
            val api = "https://en.wikipedia.org/api/rest_v1/page/summary/" +
                URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
            val json = JSONObject(fetchText(api))
            val thumb = json.optJSONObject("thumbnail")?.optString("source").orEmpty()
            if (thumb.isBlank()) return null
            val big = thumb.replace(Regex("/\\d+px-"), "/640px-")
            val bytes = fetchBytes(big) ?: fetchBytes(thumb) ?: return null
            file.writeBytes(bytes)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "FitToFit/1.0 (fitness app; food photos)")
        return c
    }

    private fun fetchText(url: String): String {
        val c = open(url)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun fetchBytes(url: String): ByteArray? {
        val c = open(url)
        return try {
            if (c.responseCode in 200..299) c.inputStream.use { it.readBytes() } else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }
}

@Composable
fun FoodPhoto(wiki: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, wiki) {
        value = withContext(Dispatchers.IO) { FoodPhotos.get(ctx, wiki) }
    }
    Box(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFCDEB4E), Color(0xFF7DA11A)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), wiki, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        } else {
            Text("🍽️", fontSize = 40.sp)
        }
    }
}

/* ---------------- small helpers ---------------- */

@Composable
private fun Pill(text: String, on: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(if (on) FitColors.Ink else FitColors.Chip)
            .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (on) FitColors.Surface else FitColors.Ink)
    }
}

@Composable
private fun TableRow(cols: List<String>, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        cols.forEachIndexed { i, t ->
            Text(
                t, fontSize = 12.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                color = FitColors.Ink, maxLines = 2,
                modifier = Modifier.weight(if (i == 0) 2.4f else 1f)
            )
        }
    }
}

private fun portionText(m: PlanMeal): String = when (m.portion) {
    0.5f -> "½ serving"; 0.75f -> "¾ serving"; 1f -> "1 serving"; 1.25f -> "1¼ servings"; 1.5f -> "1½ servings"
    else -> "%.2f servings".format(m.portion)
}

@Composable
fun CountryPickerDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text("Country", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(DietData.countries) { c ->
                    Text(
                        c, fontSize = 15.sp, color = FitColors.Ink,
                        fontWeight = if (c == current) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 11.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/* ---------------- the diet plan page ---------------- */

private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

@Composable
fun DietPage(s: FitUiState, a: HealthActions) {
    val p = s.profile
    var showCountry by remember { mutableStateOf(false) }
    var day by remember { mutableIntStateOf(LocalDate.now().dayOfWeek.value - 1) }
    val todayIdx = LocalDate.now().dayOfWeek.value - 1
    val week = remember(p.country, p.goal, p.veg, p.weightKg, p.heightCm, p.age, p.sex) { DietPlanner.week(p) }
    val target = DietPlanner.targetKcal(p)
    val proteinTarget = DietPlanner.proteinTarget(p)

    // ---- your settings ----
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Country", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                    Text(
                        if (p.country.isBlank()) "Choose your country" else p.country,
                        fontSize = 18.sp, fontWeight = FontWeight.Black, color = FitColors.Ink
                    )
                    Text("${DietPlanner.regionName(p)} food", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                }
                Pill("Change", false) { showCountry = true }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("lose" to "Lose weight", "maintain" to "Maintain", "gain" to "Gain muscle").forEach { (k, label) ->
                    Pill(label, p.goal == k) { a.saveProfile(p.copy(goal = k)) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Eat everything", !p.veg) { a.saveProfile(p.copy(veg = false)) }
                Pill("Vegetarian", p.veg) { a.saveProfile(p.copy(veg = true)) }
            }
            Text(
                "Daily target: $target kcal · protein about $proteinTarget g. Based on your age, height, weight and goal.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .7f)
            )
        }
    }

    // ---- today's progress and advice ----
    TodayAdvice(s, week[todayIdx], target, proteinTarget)

    // ---- before / after workout ----
    WorkoutFoodCard("Before workout", "Eat 30–60 minutes before. Drink 300–500 ml water.", DietPlanner.preWorkout(p))
    WorkoutFoodCard("After workout", "Within 1 hour. Drink water, add some protein.", DietPlanner.postWorkout(p))

    // ---- 7 day plan ----
    Text("7-day plan", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        dayNames.forEachIndexed { i, n ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (i == day) FitColors.Ink else FitColors.Chip)
                    .clickable { day = i }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(n, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (i == day) FitColors.Surface else FitColors.Ink)
            }
        }
    }
    val plan = week[day]
    plan.meals.forEach { m ->
        MealCard(m, canTick = day == todayIdx, eaten = m.slot in s.eatenSlots) {
            a.toggleMeal(m.slot, m.kcal, m.protein, m.carbs, m.fat)
        }
    }
    NutritionTable(plan)

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Healthy eating rules", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
            Text(
                "• Fresh, home-cooked food only — no packaged or ready-made food.\n" +
                    "• No added sugar, sweets or sugary drinks. Fruit gives all the sweetness you need.\n" +
                    "• Drink 2–3 litres of water a day.\n" +
                    "• Use little oil and less salt.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .75f), lineHeight = 18.sp
            )
            Text(
                "Nutrition values are typical estimates for one serving, not lab values. Dish photos come from Wikipedia and need internet the first time. " +
                    "This is general guidance, not medical advice. If you have a health condition, ask your doctor or dietitian.",
                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f), lineHeight = 15.sp
            )
        }
    }

    if (showCountry) {
        CountryPickerDialog(p.country, onPick = { a.saveProfile(p.copy(country = it)); showCountry = false }) { showCountry = false }
    }
}

@Composable
private fun TodayAdvice(s: FitUiState, today: DayPlan, target: Int, proteinTarget: Int) {
    val eaten = s.foodKcal
    val left = target - eaten
    val order = listOf("B", "L", "D", "S")
    val next = today.meals.firstOrNull { it.slot !in s.eatenSlots }
    val advice = when {
        eaten == 0 && next != null -> "Start your day with ${DietPlanner.slotName(next.slot).lowercase()}: ${next.dish.name}."
        left < -100 -> "You have passed today's target by ${-left} kcal. For the rest of the day choose water, vegetables or fruit."
        next == null -> "You finished all planned meals today. Great job! 🎉"
        left < next.kcal * 0.8 -> "Only $left kcal left today. Choose a lighter ${DietPlanner.slotName(next.slot).lowercase()}, such as soup, salad or fruit."
        else -> "Next: ${DietPlanner.slotName(next.slot)} — ${next.dish.name}. You have $left kcal left today."
    }
    val proteinLeft = (proteinTarget - s.foodP).coerceAtLeast(0)
    FitCard(FitColors.Blue, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Today", fontSize = 12.sp, color = Color.White.copy(alpha = .85f))
            Text("$eaten / $target kcal eaten", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
            Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(alpha = .3f))) {
                Box(
                    Modifier.fillMaxWidth((eaten.toFloat() / target).coerceIn(0f, 1f)).height(8.dp)
                        .clip(CircleShape).background(Color.White)
                )
            }
            Text(
                "Protein ${s.foodP} g · Carbs ${s.foodC} g · Fat ${s.foodF} g" +
                    if (proteinLeft > 0) " · $proteinLeft g protein to go" else " · protein goal reached ✓",
                fontSize = 12.sp, color = Color.White.copy(alpha = .95f)
            )
            Text(advice, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
private fun WorkoutFoodCard(title: String, tip: String, dishes: List<Dish>) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
            Text(tip, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
            dishes.forEach { d ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FoodPhoto(d.wiki, Modifier.size(64.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FitColors.Ink)
                        Text(
                            "${d.serving} · ${d.kcal} kcal · P ${d.protein} · C ${d.carbs} · F ${d.fat}",
                            fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MealCard(m: PlanMeal, canTick: Boolean, eaten: Boolean, onTick: () -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column {
            FoodPhoto(m.dish.wiki, Modifier.fillMaxWidth().height(170.dp))
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    DietPlanner.slotName(m.slot).uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    color = FitColors.LimeDark
                )
                Text(m.dish.name, fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
                Text("${portionText(m)} (${m.dish.serving})", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
                TableRow(listOf("", "kcal", "Protein", "Carbs", "Fat", "Fibre"), bold = true)
                TableRow(listOf("This meal", "${m.kcal}", "${m.protein} g", "${m.carbs} g", "${m.fat} g", "${m.fiber} g"))
                if (canTick) {
                    Box(
                        Modifier.clip(CircleShape)
                            .background(if (eaten) FitColors.LimeDark else FitColors.Blue)
                            .clickable { onTick() }.padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text(if (eaten) "Eaten ✓ (tap to undo)" else "I ate this", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun NutritionTable(plan: DayPlan) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Nutrition table for this day", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
            Spacer(Modifier.height(6.dp))
            TableRow(listOf("Meal", "kcal", "Protein", "Carbs", "Fat", "Fibre"), bold = true)
            plan.meals.forEach { m ->
                TableRow(listOf(DietPlanner.slotName(m.slot), "${m.kcal}", "${m.protein} g", "${m.carbs} g", "${m.fat} g", "${m.fiber} g"))
            }
            TableRow(listOf("Total", "${plan.kcal}", "${plan.protein} g", "${plan.carbs} g", "${plan.fat} g", "${plan.fiber} g"), bold = true)
        }
    }
}
