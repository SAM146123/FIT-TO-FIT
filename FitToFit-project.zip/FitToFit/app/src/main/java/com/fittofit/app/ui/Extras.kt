package com.fittofit.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.ActivityItem
import com.fittofit.app.PhotoStore
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Things the new screens (photo, voice, coach) can ask the app to do. */
class ExtraActions(
    val setVoice: (Boolean) -> Unit,
    val speak: (String, Boolean) -> Unit,
    val stopSpeak: () -> Unit,
    val pickPhoto: () -> Unit,
    val removePhoto: () -> Unit,
    val finishWorkout: (String, Int, Int) -> Unit
)

/** Round profile picture. Shows the first letter of the name when there is no picture. */
@Composable
fun PhotoAvatar(photo: String, name: String, size: Dp, bg: Color, fg: Color) {
    val bitmap = remember(photo) { PhotoStore.decodeBase64(photo)?.asImageBitmap() }
    Box(
        Modifier.size(size).clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(
                name.firstOrNull()?.uppercase() ?: "?",
                fontWeight = FontWeight.Black, fontSize = (size.value * 0.42f).sp, color = fg
            )
        }
    }
}

private fun iconFor(title: String): ImageVector {
    val t = title.lowercase()
    return when {
        "walk" in t || "hik" in t -> Icons.Filled.DirectionsWalk
        "run" in t || "jog" in t || "knee" in t || "jack" in t || "climb" in t -> Icons.Filled.DirectionsRun
        "cycl" in t || "bik" in t -> Icons.Filled.DirectionsBike
        "yoga" in t || "pilates" in t || "plank" in t -> Icons.Filled.SelfImprovement
        else -> Icons.Filled.FitnessCenter
    }
}

private fun whenText(ms: Long): String {
    val time = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    val day = when (time.toLocalDate()) {
        LocalDate.now() -> "Today"
        LocalDate.now().minusDays(1) -> "Yesterday"
        else -> DateTimeFormatter.ofPattern("EEE d MMM").format(time)
    }
    return day + " · " + DateTimeFormatter.ofPattern("HH:mm").format(time)
}

/** Workouts from your watch / other apps (via Health Connect) and from this app. */
@Composable
fun ActivityFeedCard(items: List<ActivityItem>) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (items.isEmpty()) {
                Text(
                    "No workouts yet. Start a walk or a coach workout, or sync your watch app with Health Connect.",
                    fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
            }
            items.take(8).forEach { a ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(FitColors.Lime.copy(alpha = .5f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(iconFor(a.title), null, tint = FitColors.Ink, modifier = Modifier.size(22.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                        Text(whenText(a.startMs), fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${a.minutes} min", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FitColors.Ink)
                        val extra = buildList {
                            if (a.km > 0.0) add("%.2f km".format(a.km))
                            if (a.kcal > 0) add("${a.kcal} kcal")
                        }.joinToString(" · ")
                        if (extra.isNotEmpty()) Text(extra, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                    }
                }
            }
        }
    }
}
