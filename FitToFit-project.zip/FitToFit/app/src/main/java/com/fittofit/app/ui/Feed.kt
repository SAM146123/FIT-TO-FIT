package com.fittofit.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FeedPost
import com.fittofit.app.FitUiState
import com.fittofit.app.SocialState
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private fun ago(ms: Long): String {
    val m = (System.currentTimeMillis() - ms) / 60000
    return when {
        m < 1 -> "just now"
        m < 60 -> "${m} min ago"
        m < 60 * 24 -> "${m / 60} h ago"
        else -> DateTimeFormatter.ofPattern("d MMM").format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))
    }
}

/** Post your achievement for your friends, and see theirs. */
@Composable
fun FeedSection(state: FitUiState, social: SocialState, actions: SocialActions) {
    val starter = remember(state.today.steps, state.activity) {
        val goal = if (state.today.steps >= state.stepGoal) "I reached my daily goal! 🏆 " else ""
        val dayAgo = System.currentTimeMillis() - 24L * 3600 * 1000
        val w = state.activity.filter { it.km > 0.05 && it.minutes > 0 && it.startMs >= dayAgo }.maxByOrNull { it.startMs }
        if (w != null) {
            "$goal${w.title}: ${"%.2f".format(w.km)} km in ${w.minutes} min · pace ${com.fittofit.app.Pace.pace(w.km, w.minutes * 60L)} · ${com.fittofit.app.Pace.speed(w.km, w.minutes * 60L)} 💪"
        } else {
            "$goal${"%,d".format(state.today.steps)} steps and ${"%.2f".format(state.today.distanceKm)} km today 💪"
        }
    }
    var feedTab by remember { mutableStateOf(0) }
    var text by remember(starter) { mutableStateOf(starter) }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Post your achievement", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
            OutlinedTextField(
                text, { text = it.take(280) }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                textStyle = TextStyle(fontSize = 14.sp, color = FitColors.Ink)
            )
            PostPhotoPreview(social.draftPhoto)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (social.draftPhoto.isBlank()) "📷 Add photo" else "Change photo", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = FitColors.Ink,
                    modifier = Modifier.clip(CircleShape).background(FitColors.Chip).clickable { actions.pickPostPhoto() }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                )
                if (social.draftPhoto.isNotBlank()) {
                    Text("Remove", fontSize = 12.sp, color = FitColors.Red, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { actions.clearPostPhoto() }.padding(6.dp))
                }
            }
            Box(
                Modifier.clip(CircleShape).background(FitColors.Blue)
                    .clickable { if (!social.loading && text.isNotBlank()) actions.post(text) }
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            ) { Text("Post", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Friends & following", "Community").forEachIndexed { i, label ->
            Text(
                label, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = if (feedTab == i) FitColors.Surface else FitColors.Ink,
                modifier = Modifier.clip(CircleShape).background(if (feedTab == i) FitColors.Ink else FitColors.Chip)
                    .clickable { feedTab = i }.padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
    val list = if (feedTab == 0) social.feed else social.community
    if (list.isEmpty()) {
        Text(
            if (feedTab == 0) "No posts yet. Follow people from the Community tab, or share your own achievement."
            else "No community posts yet. Be the first to share!",
            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(4.dp)
        )
    }
    list.forEach { p -> PostCard(p, state, social, actions) }
}

@Composable
private fun PostCard(p: FeedPost, state: FitUiState, social: SocialState, actions: SocialActions) {
    val mine = p.authorId == social.myUid
    val photo = if (mine) state.photoB64 else social.friends.firstOrNull { it.uid == p.authorId }?.photo ?: ""
    val cheered = social.myUid in p.cheers
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PhotoAvatar(photo, p.name, 38.dp, if (mine) FitColors.Blue else FitColors.Purple, if (mine) Color.White else FitColors.Ink)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (mine) "You" else p.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                    Text(ago(p.createdAt), fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                }
                val isFriend = social.friends.any { it.uid == p.authorId }
                val following = p.authorId in social.following
                if (!mine && !isFriend) {
                    Text(
                        if (following) "Following ✓" else "+ Follow", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (following) FitColors.Ink else Color.White,
                        modifier = Modifier.clip(CircleShape)
                            .background(if (following) FitColors.Chip else FitColors.Blue)
                            .clickable { actions.follow(p.authorId, following) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                if (mine) {
                    Text(
                        "Remove", fontSize = 12.sp, color = FitColors.Red, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { actions.deletePost(p.id) }.padding(6.dp)
                    )
                }
            }
            Text(p.text, fontSize = 14.sp, color = FitColors.Ink)
            PostPhotoPreview(p.photo)
            Text(
                "${"%,d".format(p.steps)} steps · ${"%.2f".format(p.km)} km · ${p.kcal} kcal · 🔥 ${p.streak}",
                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f)
            )
            Box(
                Modifier.clip(CircleShape)
                    .background(if (cheered) FitColors.Orange else FitColors.Chip)
                    .clickable { actions.cheer(p.id, cheered) }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    "👏 ${p.cheers.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (cheered) Color.White else FitColors.Ink
                )
            }
        }
    }
}

/** Shows the picture of a post (or the picture chosen for a new post). Nothing when there is none. */
@Composable
private fun PostPhotoPreview(b64: String) {
    if (b64.isBlank()) return
    val bmp = remember(b64) { com.fittofit.app.PhotoStore.decodeBase64(b64)?.asImageBitmap() } ?: return
    androidx.compose.foundation.Image(
        bmp, null, contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
        modifier = Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
    )
}
