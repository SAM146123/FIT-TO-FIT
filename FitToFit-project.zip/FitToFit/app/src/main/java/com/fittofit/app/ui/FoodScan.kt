package com.fittofit.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FoodResult

data class FoodScanState(
    val hasKey: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val photo: Bitmap? = null,
    val result: FoodResult? = null,
    val portion: Float = 1f,
    val added: Boolean = false
)

class FoodActions(
    val saveKey: (String) -> Unit,
    val takePhoto: () -> Unit,
    val pickPhoto: () -> Unit,
    val setPortion: (Float) -> Unit,
    val addToToday: () -> Unit,
    val clear: () -> Unit
)

@Composable
private fun FoodButton(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(vertical = 11.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
fun FoodScanCard(s: FoodScanState, a: FoodActions) {
    var key by remember { mutableStateOf("") }
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Food photo scan", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
            if (!s.hasKey) {
                Text(
                    "Paste your free Gemini key once. Get it at aistudio.google.com > Get API key. It stays only on this phone.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
                OutlinedTextField(
                    key, { key = it }, label = { Text("Gemini API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
                val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                FoodButton("1. Open aistudio.google.com (get free key)", FitColors.Ink, Color.White, Modifier.fillMaxWidth()) {
                    try { uriHandler.openUri("https://aistudio.google.com/apikey") } catch (e: Exception) { }
                }
                FoodButton("2. Save key", FitColors.Blue, Color.White, Modifier.fillMaxWidth()) {
                    if (key.isNotBlank()) a.saveKey(key)
                }
                return@Column
            }

            if (s.photo != null) {
                Image(
                    s.photo.asImageBitmap(), "Food photo",
                    Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            if (s.loading) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Text("Analysing your food…", fontSize = 13.sp)
                }
            }
            s.error?.let { Text(it, color = FitColors.Red, fontSize = 12.sp) }

            val r = s.result
            if (r != null) {
                val f = s.portion
                r.items.forEach { it0 ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(it0.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "%.0f g · P %.0f · C %.0f · F %.0f".format(it0.grams * f, it0.protein * f, it0.carbs * f, it0.fat * f),
                                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f)
                            )
                        }
                        Text("%.0f kcal".format(it0.kcal * f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(2.dp))
                val kcal = r.items.sumOf { it.kcal } * f
                val protein = r.items.sumOf { it.protein } * f
                val carbs = r.items.sumOf { it.carbs } * f
                val fat = r.items.sumOf { it.fat } * f
                val fiber = r.items.sumOf { it.fiber } * f
                Text(
                    "Total: %.0f kcal".format(kcal), fontWeight = FontWeight.Black, fontSize = 18.sp, color = FitColors.Ink
                )
                Text(
                    "Protein %.0f g · Carbs %.0f g · Fat %.0f g · Fibre %.0f g".format(protein, carbs, fat, fiber),
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .75f)
                )
                Text("Portion size", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.5f to "½", 0.75f to "¾", 1f to "1×", 1.5f to "1½", 2f to "2×").forEach { (v, label) ->
                        FoodButton(
                            label, if (f == v) FitColors.Ink else FitColors.Chip,
                            if (f == v) Color.White else FitColors.Ink, Modifier.weight(1f)
                        ) { a.setPortion(v) }
                    }
                }
                if (r.note.isNotBlank()) Text(r.note, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f))
                Text(
                    "This is an AI estimate, not an exact lab value. Change the portion size if it looks wrong.",
                    fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f)
                )
                if (s.added) {
                    Text("Added to today's food ✓", color = FitColors.LimeDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                } else {
                    FoodButton("Add ${"%.0f".format(kcal)} kcal to today", FitColors.LimeDark, Color.White, Modifier.fillMaxWidth()) { a.addToToday() }
                }
            }

            if (!s.loading) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FoodButton("Take photo", FitColors.Blue, Color.White, Modifier.weight(1f)) { a.takePhoto() }
                    FoodButton("Choose photo", FitColors.Cream, FitColors.Ink, Modifier.weight(1f)) { a.pickPhoto() }
                }
            }
        }
    }
}
