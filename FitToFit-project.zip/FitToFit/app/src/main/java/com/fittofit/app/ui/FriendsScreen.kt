package com.fittofit.app.ui

import android.content.Intent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import com.fittofit.app.Friend
import com.fittofit.app.MAX_FRIENDS
import com.fittofit.app.SocialState

/** Actions the Friends tab can trigger. */
class SocialActions(
    val signUp: (String, String, String) -> Unit,
    val signIn: (String, String) -> Unit,
    val signOut: () -> Unit,
    val refresh: () -> Unit,
    val addFriend: (String) -> Unit,
    val removeFriend: (String) -> Unit,
    val clearNotice: () -> Unit,
    val post: (String) -> Unit,
    val deletePost: (String) -> Unit,
    val cheer: (String, Boolean) -> Unit,
    val pickPostPhoto: () -> Unit = {},
    val clearPostPhoto: () -> Unit = {},
    val google: () -> Unit = {},
    val follow: (String, Boolean) -> Unit = { _, _ -> }
)

private val FriendsBlue = Color(0xFF1565E8)
private val FriendsCoral = Color(0xFFFF7A66)

/** One person in the ranking / comparison (you or a friend). */
private class Person(
    val uid: String,
    val name: String,
    val steps: Long,
    val weekSteps: Long,
    val kcal: Int,
    val activeMin: Int,
    val streak: Int,
    val level: Int,
    val isMe: Boolean,
    val photo: String = ""
)

private fun myPerson(s: FitUiState) = Person(
    uid = "me",
    name = s.profile.name.ifBlank { "You" },
    steps = s.today.steps,
    weekSteps = s.weeklySteps.sum(),
    kcal = s.today.calories.toInt(),
    activeMin = activeMinutes(s),
    streak = s.streakDays,
    level = s.level,
    isMe = true,
    photo = s.photoB64
)

private fun Friend.toPerson() = Person(
    uid = uid, name = name, steps = steps, weekSteps = weekSteps, kcal = kcal,
    activeMin = activeMin, streak = streak, level = level, isMe = false, photo = photo
)

private fun n(v: Long): String = "%,d".format(v)

/* ================= entry point ================= */

@Composable
fun FriendsTab(state: FitUiState, social: SocialState, actions: SocialActions) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FriendsHero()
        val inviteCtx = androidx.compose.ui.platform.LocalContext.current
        InviteCard { Sharer.invite(inviteCtx, social.myCode, state.profile.name) }
        if (!social.signedIn) {
            AuthCard(social, actions)
        } else {
            SignedInContent(state, social, actions)
        }
    }
}

@Composable
private fun FriendsHero() {
    val t = rememberInfiniteTransition(label = "friends-hero")
    val bob by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    Box(
        Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFF9330), Color(0xFFEC407A))))
    ) {
        Column(Modifier.align(Alignment.CenterStart).padding(18.dp)) {
            Text("Friends Challenge", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Compete with up to $MAX_FRIENDS friends", fontSize = 13.sp, color = Color.White.copy(alpha = .92f))
        }
        Icon(
            Icons.Filled.EmojiEvents, null, tint = Color.White,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 20.dp)
                .size(68.dp).offset(y = (-6f * bob).dp)
        )
    }
}

/* ================= sign in / sign up ================= */

@Composable
private fun AuthCard(social: SocialState, actions: SocialActions) {
    var signUpMode by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (signUpMode) "Create your account" else "Welcome back",
                fontSize = 18.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink
            )
            Text(
                "One account lets you add friends with a short code and compare your activity.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
            )
            if (signUpMode) {
                OutlinedTextField(
                    name, { name = it }, label = { Text("Your name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedTextField(
                email, { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, capitalization = KeyboardCapitalization.None),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                password, { password = it }, label = { Text("Password (6+ characters)") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Notice(social, actions)
            FrButton(
                text = when {
                    social.loading -> "Please wait…"
                    signUpMode -> "Sign up"
                    else -> "Log in"
                },
                bg = FriendsBlue, fg = Color.White, modifier = Modifier.fillMaxWidth()
            ) {
                if (!social.loading) {
                    if (signUpMode) actions.signUp(name, email, password) else actions.signIn(email, password)
                }
            }
            FrButton(
                text = if (social.loading) "Please wait…" else "Continue with Google",
                bg = Color(0xFFEFEFEF), fg = Color(0xFF1B1F3B), modifier = Modifier.fillMaxWidth()
            ) { if (!social.loading) actions.google() }
            Text(
                "Google sign-in copies your Google name and photo into your profile. You can change them any time.",
                fontSize = 11.sp, color = Color(0xFF1B1F3B).copy(alpha = .55f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                if (signUpMode) "Already have an account? Log in" else "New here? Create an account",
                fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FriendsBlue,
                modifier = Modifier.fillMaxWidth().clickable {
                    actions.clearNotice()
                    signUpMode = !signUpMode
                }.padding(vertical = 6.dp),
                textAlign = TextAlign.Center
            )
        }
    }
    FrNote("Only your name and daily totals (steps, calories, active minutes, streak) are shared with friends. Your sleep, heart, cycle and body data never leave your phone.")
}

/* ================= main content once logged in ================= */

@Composable
private fun SignedInContent(state: FitUiState, social: SocialState, actions: SocialActions) {
    var section by remember { mutableIntStateOf(0) }
    val me = remember(state) { myPerson(state) }
    val friends = remember(social.friends) { social.friends.map { it.toPerson() } }

    MyCodeCard(social)

    // sections
    Row(
        Modifier.fillMaxWidth().clip(CircleShape).background(FitColors.Surface).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("Leaderboard", "Compare", "Friends", "Feed").forEachIndexed { i, label ->
            Box(
                Modifier.weight(1f).clip(CircleShape)
                    .background(if (section == i) FriendsBlue else Color.Transparent)
                    .clickable { section = i; actions.clearNotice() }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (section == i) Color.White else FitColors.Ink
                )
            }
        }
    }

    Notice(social, actions)

    when (section) {
        0 -> LeaderboardSection(me, friends)
        1 -> CompareSection(me, friends)
        3 -> FeedSection(state, social, actions)
        else -> FriendsSection(social, friends, actions)
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            if (social.loading) "Updating…" else "Refresh",
            fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FriendsBlue,
            modifier = Modifier.clickable { if (!social.loading) actions.refresh() }.padding(6.dp)
        )
        Text(
            "Log out", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FitColors.Red,
            modifier = Modifier.clickable { actions.signOut() }.padding(6.dp)
        )
    }
}

@Composable
private fun MyCodeCard(social: SocialState) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Your friend code", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    social.myCode.ifBlank { "······" },
                    fontSize = 34.sp, fontWeight = FontWeight.Black, color = FitColors.Ink,
                    letterSpacing = 4.sp, modifier = Modifier.weight(1f)
                )
                if (social.myCode.isNotBlank()) {
                    IconPill(Icons.Filled.ContentCopy) { clipboard.setText(AnnotatedString(social.myCode)) }
                    Spacer(Modifier.width(8.dp))
                    IconPill(Icons.Filled.Share) {
                        Sharer.invite(context, social.myCode, "")
                    }
                }
            }
            Text(
                "${social.friendCount} / $MAX_FRIENDS friends",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
            )
        }
    }
}

/* ================= leaderboard ================= */

@Composable
private fun LeaderboardSection(me: Person, friends: List<Person>) {
    var weekly by remember { mutableStateOf(false) }
    var shown by remember { mutableIntStateOf(20) }

    fun value(p: Person) = if (weekly) p.weekSteps else p.steps
    val ranked = (friends + me).sortedByDescending { value(it) }
    val myRank = ranked.indexOfFirst { it.isMe } + 1
    val top = ranked.firstOrNull()?.let { value(it) }?.coerceAtLeast(1L) ?: 1L

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FrButton("Today", if (!weekly) FitColors.Ink else Color.White, if (!weekly) Color.White else FitColors.Ink, Modifier.weight(1f)) { weekly = false }
        FrButton("This week", if (weekly) FitColors.Ink else Color.White, if (weekly) Color.White else FitColors.Ink, Modifier.weight(1f)) { weekly = true }
    }

    if (friends.isEmpty()) {
        FrNote("You have no friends yet. Open the Friends tab and add someone with their code to start a challenge!")
    } else {
        val leader = ranked.first()
        val message = when {
            leader.isMe -> "🏆 You are #1 ${if (weekly) "this week" else "today"}! Keep it up!"
            else -> {
                val gap = value(leader) - value(me)
                "You are #$myRank · ${n(gap)} steps behind ${leader.name}"
            }
        }
        Text(message, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink, modifier = Modifier.padding(horizontal = 4.dp))
    }

    ranked.take(shown).forEachIndexed { i, p ->
        LeaderRow(rank = i + 1, p = p, value = value(p), top = top)
    }
    if (ranked.size > shown) {
        FrButton("Show more", Color.White, FitColors.Ink, Modifier.fillMaxWidth()) { shown += 20 }
    }
}

@Composable
private fun LeaderRow(rank: Int, p: Person, value: Long, top: Long) {
    val medal = when (rank) {
        1 -> "🥇"
        2 -> "🥈"
        3 -> "🥉"
        else -> "$rank"
    }
    val progress by animateFloatAsState(
        targetValue = (value.toFloat() / top).coerceIn(0f, 1f),
        animationSpec = tween(800, easing = FastOutSlowInEasing), label = "rank-bar"
    )
    FitCard(if (p.isMe) FitColors.Highlight else FitColors.Surface, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(medal, fontSize = if (rank <= 3) 24.sp else 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(38.dp), textAlign = TextAlign.Center)
            Avatar(p.name, p.isMe, p.photo)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row {
                    Text(
                        if (p.isMe) "${p.name} (You)" else p.name,
                        fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink,
                        maxLines = 1, modifier = Modifier.weight(1f)
                    )
                    Text(n(value), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                }
                Spacer(Modifier.height(5.dp))
                LinearBar(progress, if (p.isMe) FriendsBlue else FriendsCoral, FitColors.Ink.copy(alpha = .08f), Modifier.fillMaxWidth())
                Text("Level ${p.level} · 🔥 ${p.streak}", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f), modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

@Composable
private fun Avatar(name: String, isMe: Boolean, photo: String = "") {
    PhotoAvatar(
        photo, name, 38.dp,
        if (isMe) FriendsBlue else FitColors.Purple,
        if (isMe) Color.White else FitColors.Ink
    )
}

/* ================= compare ================= */

@Composable
private fun CompareSection(me: Person, friends: List<Person>) {
    var selected by remember { mutableStateOf<String?>(null) }
    if (friends.isEmpty()) {
        FrNote("Add a friend first, then you can compare your activity with theirs.")
        return
    }
    val other = friends.firstOrNull { it.uid == selected } ?: friends.first()

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(friends, key = { it.uid }) { f ->
            val on = f.uid == other.uid
            Text(
                f.name, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = if (on) Color.White else FitColors.Ink,
                modifier = Modifier.clip(CircleShape)
                    .background(if (on) FriendsCoral else FitColors.Surface)
                    .clickable { selected = f.uid }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }

    val rows = listOf(
        Triple("Steps today", me.steps, other.steps),
        Triple("Steps this week", me.weekSteps, other.weekSteps),
        Triple("Calories burned", me.kcal.toLong(), other.kcal.toLong()),
        Triple("Active minutes", me.activeMin.toLong(), other.activeMin.toLong()),
        Triple("Streak (days)", me.streak.toLong(), other.streak.toLong())
    )
    val myWins = rows.count { it.second > it.third }
    val theirWins = rows.count { it.third > it.second }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(me.name, true, me.photo)
                    Text("You", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text("VS", fontSize = 20.sp, fontWeight = FontWeight.Black, color = FitColors.Ink.copy(alpha = .4f))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(other.name, false, other.photo)
                    Text(other.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            Text(
                when {
                    myWins > theirWins -> "🏆 You lead in $myWins of ${rows.size} categories!"
                    theirWins > myWins -> "${other.name} leads in $theirWins of ${rows.size}. Time to catch up! 💪"
                    else -> "It's a tie so far. Push a little harder! 🔥"
                },
                fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            rows.forEach { (label, a, b) -> CompareRow(label, a, b) }
        }
    }
}

@Composable
private fun CompareRow(label: String, mine: Long, theirs: Long) {
    val top = maxOf(mine, theirs, 1L).toFloat()
    val a by animateFloatAsState(mine / top, tween(800, easing = FastOutSlowInEasing), label = "cmp-a")
    val b by animateFloatAsState(theirs / top, tween(800, easing = FastOutSlowInEasing), label = "cmp-b")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
        CompareBar(a, n(mine), FriendsBlue, mine > theirs)
        CompareBar(b, n(theirs), FriendsCoral, theirs > mine)
    }
}

@Composable
private fun CompareBar(fraction: Float, valueText: String, color: Color, winner: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(14.dp).clip(CircleShape).background(FitColors.Ink.copy(alpha = .07f))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0.02f, 1f)).clip(CircleShape).background(color))
        }
        Text(
            (if (winner) "👑 " else "") + valueText,
            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink,
            modifier = Modifier.width(86.dp).padding(start = 8.dp), textAlign = TextAlign.End
        )
    }
}

/* ================= friends list ================= */

@Composable
private fun FriendsSection(social: SocialState, friends: List<Person>, actions: SocialActions) {
    var code by remember { mutableStateOf("") }
    var toRemove by remember { mutableStateOf<Person?>(null) }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Add a friend", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            OutlinedTextField(
                code, { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) },
                label = { Text("Friend code (6 characters)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth()
            )
            FrButton(
                if (social.loading) "Please wait…" else "Add friend",
                FriendsBlue, Color.White, Modifier.fillMaxWidth()
            ) {
                if (!social.loading) {
                    actions.addFriend(code)
                    code = ""
                }
            }
        }
    }

    Text(
        "Your friends (${social.friendCount} / $MAX_FRIENDS)",
        fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp)
    )
    if (friends.isEmpty()) {
        FrNote("No friends yet. Share your code with someone and ask them to add it too.")
    }
    friends.sortedBy { it.name.lowercase() }.take(100).forEach { f ->
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(f.name, false, f.photo)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                    Text("Today ${n(f.steps)} steps · Level ${f.level}", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f))
                }
                Icon(
                    Icons.Filled.Close, "Remove", tint = FitColors.Ink.copy(alpha = .5f),
                    modifier = Modifier.clip(CircleShape).clickable { toRemove = f }.padding(6.dp).size(20.dp)
                )
            }
        }
    }
    if (friends.size > 100) FrNote("Showing the first 100 friends alphabetically. The leaderboard includes everyone.")

    toRemove?.let { f ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            containerColor = FitColors.Surface,
            title = { Text("Remove ${f.name}?") },
            text = { Text("You will stop seeing each other's activity.") },
            confirmButton = {
                TextButton(onClick = { actions.removeFriend(f.uid); toRemove = null }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { toRemove = null }) { Text("Cancel") } }
        )
    }
}

/* ================= small helpers ================= */

@Composable
private fun Notice(social: SocialState, actions: SocialActions) {
    val error = social.error
    val message = social.message
    if (error != null) {
        Text(
            error, color = FitColors.Red, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(FitColors.Red.copy(alpha = .1f)).clickable { actions.clearNotice() }.padding(12.dp)
        )
    } else if (message != null) {
        Text(
            message, color = FitColors.LimeDark, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(FitColors.Lime.copy(alpha = .3f)).clickable { actions.clearNotice() }.padding(12.dp)
        )
    }
}

@Composable
private fun FrNote(text: String) {
    Text(text, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(horizontal = 4.dp))
}

@Composable
private fun FrButton(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable
private fun IconPill(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(FitColors.Cream).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = FitColors.Ink, modifier = Modifier.size(20.dp)) }
}
