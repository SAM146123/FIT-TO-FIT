package com.fittofit.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.RestaurantMenu
import com.fittofit.app.DietPlanner
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import com.fittofit.app.HealthMath
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import com.fittofit.app.HealthContent
import kotlin.math.max

/** Actions the health pages can trigger. */
class HealthActions(
    val addWater: (Int) -> Unit,
    val addFood: (Int) -> Unit,
    val logPeriod: () -> Unit,
    val undoPeriod: () -> Unit,
    val setCycle: (Int, Int) -> Unit,
    val toggleMeal: (String, Int, Int, Int, Int) -> Unit,
    val saveProfile: (com.fittofit.app.Profile) -> Unit,
    val food: FoodActions,
    val addEaten: (String, Int, Int, Int, Int) -> Unit = { _, _, _, _, _ -> },
    val removeEaten: (Int) -> Unit = {},
    val addWeight: (Float) -> Unit = {},
    val removeWeight: (String) -> Unit = {}
)

enum class HealthKind(
    val title: String,
    val tagline: String,
    val icon: ImageVector,
    val c1: Color,
    val c2: Color
) {
    Calories("Calories", "Burned vs eaten", Icons.Filled.LocalFireDepartment, Color(0xFFFF9330), Color(0xFFFF5A4D)),
    Heart("Heart & Respiratory", "Pulse, SpO₂, breathing", Icons.Filled.Favorite, Color(0xFFFF4D5A), Color(0xFF8E1B4A)),
    Bmi("BMI", "Weight vs height", Icons.Filled.MonitorWeight, Color(0xFF7C4DFF), Color(0xFF3F51B5)),
    Nutrition("Nutrition & Water", "Food, macros, hydration", Icons.Filled.Restaurant, Color(0xFF7DA11A), Color(0xFF2E7D32)),
    Sleep("Sleep & Stress", "Rest and recovery", Icons.Filled.Bedtime, Color(0xFF3F51B5), Color(0xFF141A3A)),
    Body("Body Fat & Muscle", "Body composition", Icons.Filled.AccessibilityNew, Color(0xFF00ACC1), Color(0xFF1565E8)),
    Active("Active Minutes", "Move more every day", Icons.Filled.Timer, Color(0xFFFFC93C), Color(0xFFFF9330)),
    Women("Women's Health", "Menstrual cycle tracking", Icons.Filled.Female, Color(0xFFEC407A), Color(0xFFAB47BC)),
    Diet("Diet Plan", "7 days of healthy local food", Icons.Filled.RestaurantMenu, Color(0xFF2E7D32), Color(0xFF7DA11A)),
    Tips("Health Tips", "First aid, home care, my conditions", Icons.Filled.MedicalServices, Color(0xFF00897B), Color(0xFF1565E8)),
    Weight("Weight Tracker", "Log weight and see progress", Icons.Filled.Scale, Color(0xFF5C6BC0), Color(0xFF26A69A)),
    Reminders("Reminders", "Water and medicine", Icons.Filled.Alarm, Color(0xFFEF6C00), Color(0xFFD81B60)),
    Ai("AI Assistant", "Ask questions, weekly report", Icons.Filled.AutoAwesome, Color(0xFF6A1B9A), Color(0xFF1565E8)),
    Records("Sugar & BP Log", "Readings, trend, share", Icons.Filled.MonitorHeart, Color(0xFFC62828), Color(0xFFEF6C00)),
    AppData("App & Data", "Backup, updates, privacy", Icons.Filled.CloudSync, Color(0xFF455A64), Color(0xFF1565E8)),
    Wallpapers("Wallpapers", "Free 4K, new every day", Icons.Filled.Wallpaper, Color(0xFF8E24AA), Color(0xFF1E88E5))
}

internal fun activeMinutes(s: FitUiState): Int =
    max(s.extras.exerciseMinutes, (s.today.steps / 100).toInt())

/* ---------------- Illustration banner (drawn, gently animated) ---------------- */

@Composable
fun HeroBanner(kind: HealthKind, height: Dp, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "hero")
    val float by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float"
    )
    Box(
        modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(kind.c1, kind.c2)))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color.White.copy(alpha = .12f), radius = size.height * 0.9f, center = Offset(size.width * 0.85f, size.height * 0.2f))
            drawCircle(Color.White.copy(alpha = .10f), radius = size.height * 0.5f, center = Offset(size.width * 0.1f, size.height * 1.0f))
            drawCircle(Color.White.copy(alpha = .18f), radius = size.height * 0.14f * (1f + 0.2f * float), center = Offset(size.width * 0.6f, size.height * 0.72f))
            drawCircle(Color.White.copy(alpha = .14f), radius = size.height * 0.07f * (1.2f - 0.2f * float), center = Offset(size.width * 0.45f, size.height * 0.3f))
        }
        Icon(
            kind.icon, null, tint = Color.White.copy(alpha = .95f),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp)
                .size(height * 0.6f).offset(y = (-6f * float).dp)
        )
    }
}

/* ---------------- Entry point ---------------- */

@Composable
fun HealthTab(
    state: FitUiState,
    bpm: Int,
    page: HealthKind?,
    onPage: (HealthKind?) -> Unit,
    actions: HealthActions
) {
    if (page == null) {
        HealthHub(state, bpm, onPage)
    } else {
        HealthDetail(page, onBack = { onPage(null) }) {
            when (page) {
                HealthKind.Calories -> CaloriesPage(state, actions)
                HealthKind.Heart -> HeartPage(state, bpm)
                HealthKind.Bmi -> BmiPage(state)
                HealthKind.Nutrition -> NutritionPage(state, actions)
                HealthKind.Sleep -> SleepPage(state)
                HealthKind.Body -> BodyPage(state)
                HealthKind.Active -> ActivePage(state)
                HealthKind.Women -> WomenPage(state, actions)
                HealthKind.Diet -> DietPage(state, actions)
                HealthKind.Tips -> TipsPage(state, actions.saveProfile)
                HealthKind.Weight -> WeightPage(state, actions.addWeight, actions.removeWeight)
                HealthKind.Reminders -> RemindersPage(state)
                HealthKind.Ai -> AiPage(state)
                HealthKind.Records -> RecordsPage()
                HealthKind.Wallpapers -> WallpaperPage()
                HealthKind.AppData -> {
                    val appCtx = androidx.compose.ui.platform.LocalContext.current
                    AppDataPage { actions.saveProfile(com.fittofit.app.ProfileStore(appCtx).load()) }
                }
            }
        }
    }
}

@Composable
private fun HealthHub(state: FitUiState, bpm: Int, onPage: (HealthKind) -> Unit) {
    val kinds = HealthKind.values().filter { it != HealthKind.Women || state.profile.sex == "F" }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        kinds.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { k ->
                    HubTile(k, hubValue(k, state, bpm), Modifier.weight(1f)) { onPage(k) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (state.profile.sex.isBlank()) {
            Note("Choose Female in your profile to unlock Women's Health and cycle tracking.")
        }
    }
}

private fun hubValue(k: HealthKind, s: FitUiState, bpm: Int): String = when (k) {
    HealthKind.Calories -> "${s.today.calories.toInt()} kcal burned"
    HealthKind.Heart -> when {
        bpm > 0 -> "$bpm bpm live"
        s.extras.restingHr > 0 -> "${s.extras.restingHr} bpm resting"
        else -> "Connect a watch"
    }
    HealthKind.Bmi -> {
        val b = HealthMath.bmi(s.profile.heightCm, s.profile.weightKg)
        if (b > 0) "%.1f · %s".format(b, HealthMath.bmiLabel(b)) else "Add height & weight"
    }
    HealthKind.Nutrition -> "${s.foodKcal} kcal · ${s.waterMl} ml"
    HealthKind.Diet -> if (s.profile.country.isBlank()) "Choose your country" else "${DietPlanner.targetKcal(s.profile)} kcal/day · ${s.profile.country}"
    HealthKind.Weight -> s.weights.lastOrNull()?.let { "%.1f kg".format(it.second) } ?: "Log your weight"
    HealthKind.Reminders -> "Water · Medicine"
    HealthKind.Ai -> "Ask · Weekly report"
    HealthKind.Records -> "Sugar · BP"
    HealthKind.AppData -> "Backup · Updates"
    HealthKind.Wallpapers -> "New daily · add yours"
    HealthKind.Tips -> {
        val n = HealthContent.conditions.count { HealthContent.has(s.profile, it.id) }
        if (n > 0) "$n condition(s) · first aid" else "First aid · home care"
    }
    HealthKind.Sleep -> {
        val m = s.extras.sleepMinutes
        if (m > 0) "${m / 60}h ${m % 60}m" else "No data yet"
    }
    HealthKind.Body -> {
        val bf = if (s.extras.bodyFatPct > 0) s.extras.bodyFatPct else HealthMath.bodyFatEstimate(s.profile)
        if (bf > 0) "%.1f%% body fat".format(bf) else "Add profile details"
    }
    HealthKind.Active -> "${activeMinutes(s)} min today"
    HealthKind.Women -> {
        val c = HealthMath.cycle(s.periodStarts, s.cycleLength, s.periodLength)
        if (c != null) "Cycle day ${c.cycleDay}" else "Log your cycle"
    }
}

@Composable
private fun HubTile(kind: HealthKind, value: String, modifier: Modifier, onClick: () -> Unit) {
    FitCard(Color.White, modifier.clickable { onClick() }) {
        Column {
            HeroBanner(kind, 92.dp)
            Column(Modifier.padding(12.dp)) {
                Text(kind.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                Text(value, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
            }
        }
    }
}

@Composable
private fun HealthDetail(kind: HealthKind, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.clip(CircleShape).clickable { onBack() }.padding(vertical = 4.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = FitColors.Ink)
            Spacer(Modifier.width(6.dp))
            Text("Health", fontWeight = FontWeight.Bold, color = FitColors.Ink)
        }
        Box {
            HeroBanner(kind, 130.dp)
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                Text(kind.title, fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(kind.tagline, fontSize = 13.sp, color = Color.White.copy(alpha = .9f))
            }
        }
        content()
    }
}

/* ---------------- Small building blocks ---------------- */

@Composable
private fun Metric(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    unit: String = "",
    note: String? = null,
    accent: Color = FitColors.Ink
) {
    FitCard(Color.White, modifier) {
        Column(Modifier.padding(14.dp).fillMaxWidth()) {
            Text(label, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = accent)
                if (unit.isNotEmpty()) {
                    Text(" $unit", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(bottom = 4.dp))
                }
            }
            if (note != null) Text(note, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f))
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(horizontal = 4.dp))
}

@Composable
private fun BigProgress(label: String, valueText: String, progress: Float, color: Color) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text(label, fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .7f), modifier = Modifier.weight(1f))
                Text(valueText, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
            }
            Spacer(Modifier.height(8.dp))
            LinearBar(progress, color, color.copy(alpha = .2f), Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ActionButton(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White,
        modifier = Modifier.clip(CircleShape).background(color).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
private fun Stepper(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
            ActionButton("−", FitColors.Cream, FitColors.Ink) { if (value > range.first) onChange(value - 1) }
            Text("$value days", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
            ActionButton("+", FitColors.Cream, FitColors.Ink) { if (value < range.last) onChange(value + 1) }
        }
    }
}

/* ---------------- Pages ---------------- */

@Composable
private fun CaloriesPage(s: FitUiState, a: HealthActions) {
    val bmr = HealthMath.bmr(s.profile)
    val active = s.today.calories
    val burned = bmr + active
    val eaten = s.foodKcal
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Active burned", "${active.toInt()}", Modifier.weight(1f), "kcal")
        Metric(
            "Resting (BMR)", if (bmr > 0) "${bmr.toInt()}" else "—", Modifier.weight(1f), "kcal",
            note = if (bmr <= 0) "Add age, height, weight" else null
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Total burned", if (bmr > 0) "${burned.toInt()}" else "—", Modifier.weight(1f), "kcal")
        Metric("Eaten today", "$eaten", Modifier.weight(1f), "kcal")
    }
    if (bmr > 0) {
        val net = eaten - burned.toInt()
        BigProgress(
            "Energy balance", if (net >= 0) "+$net kcal" else "$net kcal",
            (eaten / burned).toFloat().coerceIn(0f, 1f), FitColors.Orange
        )
    }
    FoodScanCard(s.foodScan, a.food)
    Text("Quick add food", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(100, 250, 500).forEach { k ->
            ActionButton("+$k kcal", FitColors.Orange, Color.White, Modifier.weight(1f)) { a.addFood(k) }
        }
    }
    Note("Eaten calories = what you add here + food apps that sync to Health Connect.")
}

private fun restingNote(v: Int): String? = when {
    v <= 0 -> null
    v < 60 -> "Low / athletic"
    v <= 100 -> "Normal (60–100)"
    else -> "High — rest and recheck"
}

private fun respNote(v: Double): String? = when {
    v <= 0 -> null
    v < 12 -> "Slow"
    v <= 20 -> "Normal (12–20)"
    else -> "Fast"
}

private fun spo2Note(v: Double): String? = when {
    v <= 0 -> null
    v >= 95 -> "Normal"
    v >= 90 -> "Low — monitor"
    else -> "Very low — seek medical advice"
}

@Composable
private fun HeartPage(s: FitUiState, bpm: Int) {
    val e = s.extras
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric(
            "Live heart rate", if (bpm > 0) "$bpm" else "—", Modifier.weight(1f), "bpm",
            note = if (bpm > 0) "From your watch" else "Connect a watch in Profile"
        )
        Metric(
            "Resting heart rate", if (e.restingHr > 0) "${e.restingHr}" else "—", Modifier.weight(1f), "bpm",
            note = restingNote(e.restingHr)
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric(
            "Respiratory rate", if (e.respRate > 0) "%.0f".format(e.respRate) else "—", Modifier.weight(1f), "br/min",
            note = respNote(e.respRate)
        )
        Metric(
            "Blood oxygen (SpO₂)", if (e.spo2 > 0) "%.0f".format(e.spo2) else "—", Modifier.weight(1f), "%",
            note = spo2Note(e.spo2)
        )
    }
    Metric(
        "Heart-rate variability (HRV)", if (e.hrvMs > 0) "%.0f".format(e.hrvMs) else "—",
        Modifier.fillMaxWidth(), "ms", note = "Higher usually means better recovery"
    )
    Note("Values come from your watch through Health Connect. This is general information, not a medical diagnosis.")
}

@Composable
private fun BmiPage(s: FitUiState) {
    val b = HealthMath.bmi(s.profile.heightCm, s.profile.weightKg)
    if (b <= 0) {
        Note("Add your height and weight in your profile (tap the profile card on Home).")
        return
    }
    val label = HealthMath.bmiLabel(b)
    val color = when {
        b < 18.5 -> FitColors.Teal
        b < 25 -> FitColors.LimeDark
        b < 30 -> FitColors.Orange
        else -> FitColors.Red
    }
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("%.1f".format(b), fontSize = 44.sp, fontWeight = FontWeight.Black, color = FitColors.Ink)
                Spacer(Modifier.width(12.dp))
                StatusPill(label, color)
            }
            Spacer(Modifier.height(14.dp))
            Canvas(Modifier.fillMaxWidth().height(22.dp)) {
                val min = 15f
                val range = 25f
                val segments = listOf(15f to 18.5f, 18.5f to 25f, 25f to 30f, 30f to 40f)
                val colors = listOf(FitColors.Teal, FitColors.Lime, FitColors.Orange, FitColors.Red)
                segments.forEachIndexed { i, seg ->
                    val x0 = (seg.first - min) / range * size.width
                    val x1 = (seg.second - min) / range * size.width
                    drawRect(colors[i], Offset(x0, size.height * 0.25f), Size(x1 - x0 - 2f, size.height * 0.5f))
                }
                val mx = (b.toFloat().coerceIn(15f, 40f) - min) / range * size.width
                drawCircle(Color.White, size.height * 0.5f, Offset(mx, size.height * 0.5f))
                drawCircle(FitColors.Ink, size.height * 0.34f, Offset(mx, size.height * 0.5f))
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("15", fontSize = 10.sp); Text("18.5", fontSize = 10.sp); Text("25", fontSize = 10.sp)
                Text("30", fontSize = 10.sp); Text("40", fontSize = 10.sp)
            }
        }
    }
    val m = s.profile.heightCm / 100.0
    Metric(
        "Healthy weight for your height", "%.0f – %.0f".format(18.5 * m * m, 24.9 * m * m),
        Modifier.fillMaxWidth(), "kg"
    )
    Note("BMI is a rough guide. It does not separate muscle from fat.")
}

@Composable
private fun NutritionPage(s: FitUiState, a: HealthActions) {
    val e = s.extras
    val goalMl = if (s.profile.weightKg > 0) (s.profile.weightKg * 35).coerceIn(1500, 4500) else 2500
    Metric("Calories eaten today", "${s.foodKcal}", Modifier.fillMaxWidth(), "kcal")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Protein", if (e.proteinG > 0) "%.0f".format(e.proteinG) else "—", Modifier.weight(1f), "g")
        Metric("Carbs", if (e.carbsG > 0) "%.0f".format(e.carbsG) else "—", Modifier.weight(1f), "g")
        Metric("Fat", if (e.fatG > 0) "%.0f".format(e.fatG) else "—", Modifier.weight(1f), "g")
    }
    BigProgress(
        "Water", "${s.waterMl} / $goalMl ml",
        (s.waterMl.toFloat() / goalMl).coerceIn(0f, 1f), FitColors.Blue
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(150, 250, 500).forEach { ml ->
            ActionButton("+$ml ml", FitColors.Blue, Color.White, Modifier.weight(1f)) { a.addWater(ml) }
        }
    }
    Text("Quick add food", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(100, 250, 500).forEach { k ->
            ActionButton("+$k kcal", FitColors.LimeDark, Color.White, Modifier.weight(1f)) { a.addFood(k) }
        }
    }
    Note("Protein, carbs and fat appear when a food-logging app syncs to Health Connect. Your daily water goal is based on your weight.")
}

@Composable
private fun SleepPage(s: FitUiState) {
    val e = s.extras
    if (e.sleepMinutes <= 0) {
        Note("No sleep data yet. Wear your watch to bed and turn on sync to Health Connect in the watch's own app.")
    } else {
        val score = HealthMath.sleepScore(e.sleepMinutes, e.deepMinutes, e.remMinutes)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric("Last night", "${e.sleepMinutes / 60}h ${e.sleepMinutes % 60}m", Modifier.weight(1f))
            Metric("Sleep score", "$score", Modifier.weight(1f), "/100")
        }
        val total = e.deepMinutes + e.remMinutes + e.lightMinutes
        if (total > 0) {
            FitCard(Color.White, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Sleep stages", fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .7f))
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().height(16.dp).clip(CircleShape)) {
                        if (e.deepMinutes > 0) Box(Modifier.weight(e.deepMinutes.toFloat()).fillMaxHeight().background(Color(0xFF3F51B5)))
                        if (e.remMinutes > 0) Box(Modifier.weight(e.remMinutes.toFloat()).fillMaxHeight().background(Color(0xFF7C4DFF)))
                        if (e.lightMinutes > 0) Box(Modifier.weight(e.lightMinutes.toFloat()).fillMaxHeight().background(FitColors.Teal))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Deep ${e.deepMinutes} min · REM ${e.remMinutes} min · Light ${e.lightMinutes} min",
                        fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .7f)
                    )
                }
            }
        }
    }
    val level = HealthMath.stressLevel(e.hrvMs, e.restingHr)
    BigProgress(
        "Stress (estimated)", HealthMath.stressLabel(level),
        if (level < 0) 0f else level / 100f,
        when {
            level < 35 -> FitColors.LimeDark
            level < 65 -> FitColors.Orange
            else -> FitColors.Red
        }
    )
    Note("Stress is only estimated from HRV or resting heart rate. It is a rough guide, not a diagnosis.")
}

@Composable
private fun BodyPage(s: FitUiState) {
    val p = s.profile
    val e = s.extras
    val b = HealthMath.bmi(p.heightCm, p.weightKg)
    val measured = e.bodyFatPct > 0
    val bf = if (measured) e.bodyFatPct else HealthMath.bodyFatEstimate(p)
    val fatKg = if (bf > 0 && p.weightKg > 0) p.weightKg * bf / 100.0 else 0.0
    val leanKg = when {
        e.leanMassKg > 0 -> e.leanMassKg
        fatKg > 0 -> p.weightKg - fatKg
        else -> 0.0
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Weight", if (p.weightKg > 0) "${p.weightKg}" else "—", Modifier.weight(1f), "kg")
        Metric("BMI", if (b > 0) "%.1f".format(b) else "—", Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric(
            "Body fat", if (bf > 0) "%.1f".format(bf) else "—", Modifier.weight(1f), "%",
            note = if (bf > 0) (if (measured) "Measured" else "Estimated") else null
        )
        Metric("Fat mass", if (fatKg > 0) "%.1f".format(fatKg) else "—", Modifier.weight(1f), "kg")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric(
            "Lean body mass", if (leanKg > 0) "%.1f".format(leanKg) else "—", Modifier.weight(1f), "kg",
            note = "Muscle, bone, water"
        )
        Metric(
            "Muscle (approx.)", if (leanKg > 0) "%.1f".format(leanKg * 0.5) else "—", Modifier.weight(1f), "kg",
            note = "Rough estimate"
        )
    }
    Note("Readings from a smart scale (via Health Connect) are used when available. Otherwise values are estimated from BMI, age and sex and can be off by several percent.")
}

@Composable
private fun ActivePage(s: FitUiState) {
    val minutes = activeMinutes(s)
    val goal = 30
    BigProgress("Active minutes today", "$minutes / $goal min", (minutes / goal.toFloat()).coerceIn(0f, 1f), FitColors.Orange)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Workout sessions", "${s.extras.exerciseMinutes}", Modifier.weight(1f), "min")
        Metric("From steps (est.)", "${(s.today.steps / 100).toInt()}", Modifier.weight(1f), "min", note = "≈100 steps = 1 min")
    }
    Note("Health experts suggest at least 150 minutes of moderate activity every week (about 30 minutes a day).")
}

@Composable
private fun WomenPage(s: FitUiState, a: HealthActions) {
    val info = HealthMath.cycle(s.periodStarts, s.cycleLength, s.periodLength)
    val fmt = DateTimeFormatter.ofPattern("d MMM")
    val today = LocalDate.now()
    if (info == null) {
        Note("Tap \"Period started today\" when your period begins. The app will then estimate your next period and fertile window.")
    } else {
        val inFertile = !today.isBefore(info.fertileStart) && !today.isAfter(info.fertileEnd)
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Cycle day ${info.cycleDay}", fontSize = 32.sp, fontWeight = FontWeight.Black, color = FitColors.Ink)
                Spacer(Modifier.height(6.dp))
                StatusPill(
                    when {
                        info.inPeriod -> "Period days"
                        inFertile -> "Fertile window (estimate)"
                        else -> "Regular days"
                    },
                    when {
                        info.inPeriod -> Color(0xFFEC407A)
                        inFertile -> Color(0xFFAB47BC)
                        else -> FitColors.LimeDark
                    }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric(
                "Next period", fmt.format(info.nextPeriod), Modifier.weight(1f),
                note = if (info.daysToNext == 0L) "Expected today" else "in ${info.daysToNext} days"
            )
            Metric(
                "Fertile window", "${fmt.format(info.fertileStart)} – ${fmt.format(info.fertileEnd)}",
                Modifier.weight(1f), note = "Estimate only"
            )
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ActionButton("Period started today", Color(0xFFEC407A), Color.White, Modifier.weight(1f)) { a.logPeriod() }
        if (s.periodStarts.isNotEmpty()) {
            ActionButton("Undo last", FitColors.Cream, FitColors.Ink) { a.undoPeriod() }
        }
    }
    Stepper("Cycle length", s.cycleLength, 21..40) { a.setCycle(it, s.periodLength) }
    Stepper("Period length", s.periodLength, 2..10) { a.setCycle(s.cycleLength, it) }
    if (s.periodStarts.isNotEmpty()) {
        Note("Recent periods: " + s.periodStarts.takeLast(5).reversed().joinToString(", ") { fmt.format(it) })
    }
    Note("Your cycle data stays on this phone. Predictions are estimates only — not for contraception or medical diagnosis.")
}
