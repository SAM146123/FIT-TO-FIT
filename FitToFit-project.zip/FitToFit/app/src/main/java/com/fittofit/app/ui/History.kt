package com.fittofit.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import java.text.NumberFormat
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun Long.nf(): String = NumberFormat.getInstance(Locale.US).format(this)

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Black, color = FitColors.Ink)
        Text(label, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f))
    }
}

/** Lifetime totals from Google Fit / Health Connect. Tap to open the full history. */
@Composable
fun LifetimeCard(s: FitUiState, onClick: () -> Unit) {
    val l = s.lifetime
    FitCard(Color.White, Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Lifetime activity", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
            if (!s.healthConnected) {
                Text("Connect Google Fit / Health Connect to see all your past activity.", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
            } else if (!l.loaded) {
                Text("Loading your history…", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
            } else {
                Row(Modifier.fillMaxWidth()) {
                    Stat("steps", l.steps.nf(), Modifier.weight(1f))
                    Stat("km", "%,.0f".format(l.km), Modifier.weight(1f))
                    Stat("kcal burned", l.kcal.toLong().nf(), Modifier.weight(1f))
                }
                Text("Tap for daily steps history", fontSize = 11.sp, color = FitColors.Blue, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StepsHistoryDialog(s: FitUiState, onGrant: () -> Unit, onDismiss: () -> Unit) {
    var range by remember { mutableIntStateOf(7) }
    val rows = s.stepHist.takeLast(range)
    val total = rows.sumOf { it.steps }
    val avg = if (rows.isEmpty()) 0L else total / rows.size
    val best = rows.maxByOrNull { it.steps }
    val km = rows.sumOf { it.km }
    val fmt = remember { DateTimeFormatter.ofPattern("EEE, d MMM", Locale.ENGLISH) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text("Steps history", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Data from Google Fit / Health Connect", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(7 to "7 days", 30 to "30 days", 90 to "90 days").forEach { (d, label) ->
                        Text(
                            label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = if (range == d) FitColors.Surface else FitColors.Ink,
                            modifier = Modifier.clip(CircleShape)
                                .background(if (range == d) FitColors.Ink else FitColors.Chip)
                                .clickable { range = d }.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
                if (rows.isEmpty()) {
                    Text("Loading…", color = FitColors.Ink)
                } else {
                    Row(Modifier.fillMaxWidth()) {
                        Stat("total steps", total.nf(), Modifier.weight(1f))
                        Stat("per day", avg.nf(), Modifier.weight(1f))
                        Stat("distance km", "%.1f".format(km), Modifier.weight(1f))
                    }
                    if (best != null && best.steps > 0) {
                        Text("Best day: ${best.date.format(fmt)} — ${best.steps.nf()} steps", fontSize = 12.sp, color = FitColors.LimeDark, fontWeight = FontWeight.Bold)
                    }
                    val goal = s.stepGoal.toFloat()
                    val maxV = maxOf(rows.maxOf { it.steps }.toFloat(), goal, 1f)
                    val barColor = FitColors.Blue
                    val goalColor = FitColors.LimeDark
                    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                        val n = rows.size
                        val gap = if (n > 40) 1.dp.toPx() else 3.dp.toPx()
                        val w = (size.width - gap * (n - 1)) / n
                        rows.forEachIndexed { i, r ->
                            val h = size.height * (r.steps / maxV)
                            drawRoundRect(
                                barColor.copy(alpha = if (r.steps >= goal) 1f else .55f),
                                Offset(i * (w + gap), size.height - h), Size(w, h), CornerRadius(w / 3)
                            )
                        }
                        val gy = size.height * (1f - goal / maxV)
                        drawLine(goalColor, Offset(0f, gy), Offset(size.width, gy), 2.dp.toPx())
                    }
                    Text("Green line = your daily goal", fontSize = 10.sp, color = FitColors.Ink.copy(alpha = .5f))
                    rows.reversed().forEach { r ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(r.date.format(fmt), fontSize = 12.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                            Text(
                                "${r.steps.nf()} steps · ${"%.1f".format(r.km)} km", fontSize = 12.sp,
                                fontWeight = if (r.steps >= s.stepGoal) FontWeight.Bold else FontWeight.Normal,
                                color = if (r.steps >= s.stepGoal) FitColors.LimeDark else FitColors.Ink
                            )
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                val l = s.lifetime
                if (l.loaded) {
                    Text("Lifetime (since ${l.sinceYear})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                    Row(Modifier.fillMaxWidth()) {
                        Stat("steps", l.steps.nf(), Modifier.weight(1f))
                        Stat("km", "%,.0f".format(l.km), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("kcal burned", l.kcal.toLong().nf(), Modifier.weight(1f))
                        Stat("workout hours", "%.1f".format(l.activeMinutes / 60.0), Modifier.weight(1f))
                    }
                    TextButton(onClick = onGrant) { Text("Allow full history access") }
                    Text(
                        "Google Fit / Health Connect decides how far back data goes. If you see only recent days, allow \"Past data\" access when asked.",
                        fontSize = 10.sp, color = FitColors.Ink.copy(alpha = .5f)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
