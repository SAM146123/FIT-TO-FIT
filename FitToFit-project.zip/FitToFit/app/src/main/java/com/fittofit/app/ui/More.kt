package com.fittofit.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.ActivityItem
import com.fittofit.app.FitUiState
import com.fittofit.app.Quotes
import com.fittofit.app.Settings

/* ---------------- daily motivation ---------------- */

@Composable
fun QuoteCard(onShare: () -> Unit) {
    val quote = Quotes.today(Settings.lang)
    FitCard(FitColors.Blue, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("Today's motivation", fontSize = 12.sp, color = Color.White.copy(alpha = .8f), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text("“$quote”", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, lineHeight = 24.sp)
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.clip(CircleShape).background(Color.White).clickable { onShare() }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) { Text("Share my progress", color = FitColors.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
    }
}

/* ---------------- achievements dashboard ---------------- */

private class AchBadge(val id: String, val title: String, val hint: String, val icon: ImageVector)

private val allBadges = listOf(
    AchBadge("first1k", "First 1,000", "1,000 steps in a day", Icons.Filled.DirectionsWalk),
    AchBadge("five_k", "5K Day", "5,000 steps in a day", Icons.Filled.Star),
    AchBadge("ten_k", "10K Day", "10,000 steps in a day", Icons.Filled.Bolt),
    AchBadge("goal", "Goal Crusher", "Reach your daily goal", Icons.Filled.EmojiEvents),
    AchBadge("streak3", "3-Day Streak", "3 active days in a row", Icons.Filled.LocalFireDepartment),
    AchBadge("streak7", "7-Day Streak", "7 active days in a row", Icons.Filled.WorkspacePremium),
    AchBadge("level5", "Level 5", "Reach level 5", Icons.Filled.MilitaryTech),
    AchBadge("km10", "10 km Week", "Cover 10 km in a week", Icons.Filled.Route),
    AchBadge("workouts5", "5 Workouts", "Log 5 workouts", Icons.Filled.Verified),
    AchBadge("water2l", "Hydrated", "Drink 2 litres in a day", Icons.Filled.LocalDrink)
)

@Composable
fun AchievementsDashboard(unlocked: Set<String>, onShare: () -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Your badges", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
                    Text("${unlocked.size} / ${allBadges.size}", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                }
                Box(
                    Modifier.clip(CircleShape).background(FitColors.Blue).clickable { onShare() }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text("Share", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
            allBadges.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { b ->
                        val on = b.id in unlocked
                        Row(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                .background(if (on) FitColors.Lime.copy(alpha = .55f) else FitColors.Chip)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (on) b.icon else Icons.Filled.Lock, null,
                                tint = if (on) FitColors.Ink else FitColors.Ink.copy(alpha = .4f),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(Modifier.size(8.dp))
                            Column {
                                Text(b.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = if (on) 1f else .55f))
                                Text(b.hint, fontSize = 10.sp, color = FitColors.Ink.copy(alpha = .55f), lineHeight = 12.sp)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/* ---------------- details of a workout / of today ---------------- */

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .65f), modifier = Modifier.weight(1f))
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
    }
}

private fun hm(minutes: Int): String = if (minutes >= 60) "${minutes / 60} h ${minutes % 60} min" else "$minutes min"

@Composable
fun ActivityDetailDialog(a: ActivityItem, onDismiss: () -> Unit) {
    val pace = if (a.km > 0.05 && a.minutes > 0) a.minutes / a.km else 0.0
    val speed = if (a.minutes > 0 && a.km > 0) a.km / (a.minutes / 60.0) else 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text(a.title, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (a.route) {
                    val ctx = LocalContext.current
                    val pts = remember(a.startMs) { com.fittofit.app.RouteStore.load(ctx, a.startMs) }
                    if (pts.size >= 2) {
                        RouteMap(pts, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp)))
                        Spacer(Modifier.height(8.dp))
                    }
                }
                DetailRow("Duration", hm(a.minutes))
                DetailRow("Calories burned", if (a.kcal > 0) "${a.kcal} kcal" else "—")
                DetailRow("Distance", if (a.km > 0) "%.2f km".format(a.km) else "—")
                DetailRow("Average pace", if (pace > 0) "%d:%02d min/km".format(pace.toInt(), ((pace - pace.toInt()) * 60).toInt()) else "—")
                DetailRow("Average speed", if (speed > 0) "%.1f km/h".format(speed) else "—")
                DetailRow("Started", whenLabel(a.startMs))
                if (a.source.isNotBlank()) DetailRow("Source", a.source)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun TodayDetailDialog(s: FitUiState, onDismiss: () -> Unit) {
    val active = activeMinutes(s)
    val speed = if (active > 0 && s.today.distanceKm > 0) s.today.distanceKm / (active / 60.0) else 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text("Today's workout", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                DetailRow("Steps", "%,d".format(s.today.steps))
                DetailRow("Distance", "%.2f km".format(s.today.distanceKm))
                DetailRow("Calories burned", "${s.today.calories.toInt()} kcal")
                DetailRow("Active minutes", hm(active))
                DetailRow("Average speed", if (speed > 0) "%.1f km/h".format(speed) else "—")
                DetailRow("Heart rate", if (s.today.lastHeartRate > 0) "${s.today.lastHeartRate} bpm" else "—")
                DetailRow("Goal", "${s.stepGoal} steps")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/* ---------------- settings: theme, language, share link ---------------- */

@Composable
private fun Choice(label: String, on: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(if (on) FitColors.Blue else FitColors.Chip)
            .clickable { onClick() }.padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (on) Color.White else FitColors.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
fun SettingsCard() {
    val ctx = LocalContext.current
    var link by remember { mutableStateOf(Settings.appLink) }
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Theme", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "Phone setting", 1 to "Light", 2 to "Dark").forEach { (m, label) ->
                    Choice(label, Settings.themeMode == m, Modifier.weight(1f)) { Settings.setTheme(ctx, m) }
                }
            }
            Text("Language", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                languageChoices.forEach { (code, label) ->
                    Choice(label, Settings.lang == code, Modifier.weight(1f)) { Settings.setLang(ctx, code) }
                }
            }
            Text("Link shared with your posts", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
            OutlinedTextField(
                link, { link = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = FitColors.Ink)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("Save", false, Modifier.weight(1f)) {
                    Settings.setLink(ctx, link)
                    Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

/* ---------------- invite ---------------- */

@Composable
fun InviteCard(onInvite: () -> Unit) {
    FitCard(FitColors.Orange, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Groups, null, tint = Color.White, modifier = Modifier.size(44.dp))
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Invite friends", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                Text("Send the app link and compete together", fontSize = 12.sp, color = Color.White.copy(alpha = .9f))
            }
            Box(
                Modifier.clip(CircleShape).background(Color.White).clickable { onInvite() }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text("Invite", color = FitColors.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
    }
}
