package com.fittofit.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import com.fittofit.app.Med
import com.fittofit.app.MedStore
import com.fittofit.app.Notifier

/* ---------------- Weight tracker ---------------- */

@Composable
fun WeightPage(s: FitUiState, onAdd: (Float) -> Unit, onRemove: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val entries = s.weights
    val latest = entries.lastOrNull()?.second
    val first = entries.firstOrNull()?.second

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Log today's weight", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    text, { text = it.filter { c -> c.isDigit() || c == '.' }.take(6) },
                    label = { Text("Weight (kg)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier.clip(CircleShape).background(FitColors.Blue)
                        .clickable {
                            val kg = text.toFloatOrNull()
                            if (kg != null && kg in 20f..300f) {
                                onAdd(kg)
                                text = ""
                            }
                        }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Save", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Text(
                "Best: once a week, in the morning, before eating. Saving also updates your profile weight.",
                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f)
            )
        }
    }

    if (latest != null) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FitCard(Color.White, Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Now", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                    Text("%.1f kg".format(latest), fontSize = 22.sp, fontWeight = FontWeight.Black, color = FitColors.Ink)
                }
            }
            FitCard(Color.White, Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    val diff = latest - (first ?: latest)
                    Text("Change since first entry", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                    Text(
                        (if (diff > 0) "+" else "") + "%.1f kg".format(diff),
                        fontSize = 22.sp, fontWeight = FontWeight.Black,
                        color = if (diff <= 0f) FitColors.LimeDark else FitColors.Orange
                    )
                }
            }
        }
    }

    val h = s.profile.heightCm
    if (h > 0) {
        val m = h / 100.0
        val lo = 18.5 * m * m
        val hi = 24.9 * m * m
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Healthy weight for your height", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                Text("%.0f - %.0f kg".format(lo, hi), fontSize = 20.sp, fontWeight = FontWeight.Black, color = FitColors.Ink)
                Text("Based on a healthy BMI of 18.5 to 24.9. It is a guide, not a rule.", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
            }
        }
    } else {
        Text("Add your height in the profile to see your healthy weight range.", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
    }

    if (entries.size >= 2) {
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("Progress", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                WeightChart(entries.map { it.second }, FitColors.Blue, Modifier.fillMaxWidth().height(160.dp).padding(top = 10.dp))
                Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text(entries.first().first, fontSize = 10.sp, color = FitColors.Ink.copy(alpha = .55f), modifier = Modifier.weight(1f))
                    Text(entries.last().first, fontSize = 10.sp, color = FitColors.Ink.copy(alpha = .55f))
                }
            }
        }
    } else if (entries.size == 1) {
        Text("Add one more weight on another day to see your chart.", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
    }

    if (entries.isNotEmpty()) {
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("History", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                entries.reversed().take(12).forEach { (date, kg) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(date, fontSize = 13.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                        Text("%.1f kg".format(kg), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink)
                        Text(
                            "Remove", fontSize = 12.sp, color = FitColors.Coral, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onRemove(date) }.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun WeightChart(points: List<Float>, color: Color, modifier: Modifier) {
    val grid = FitColors.Ink.copy(alpha = .12f)
    Canvas(modifier) {
        if (points.size < 2) return@Canvas
        val lo = points.minOrNull() ?: 0f
        val hi = points.maxOrNull() ?: 1f
        val min = lo - 1f
        val max = hi + 1f
        val w = size.width
        val h = size.height
        val n = points.size - 1
        drawLine(grid, Offset(0f, h), Offset(w, h), 2f)
        drawLine(grid, Offset(0f, h / 2f), Offset(w, h / 2f), 2f)
        val path = Path()
        points.forEachIndexed { i, v ->
            val x = w * i / n
            val y = h - (v - min) / (max - min) * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 6f))
        points.forEachIndexed { i, v ->
            val x = w * i / n
            val y = h - (v - min) / (max - min) * h
            drawCircle(color, 8f, Offset(x, y))
        }
    }
}

/* ---------------- Reminders: water, medicine, goal ---------------- */

@Composable
fun RemindersPage(s: FitUiState) {
    val ctx = LocalContext.current
    var water by remember { mutableStateOf(Notifier.waterEnabled(ctx)) }
    var hourly by remember { mutableStateOf(Notifier.hourlyEnabled(ctx)) }
    var meds by remember { mutableStateOf(MedStore.list(ctx)) }
    var showAdd by remember { mutableStateOf(false) }
    val goalMl = Notifier.waterGoalMl(s.profile)

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("💧 Water reminders", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
                Text(
                    "Every 2 hours (8 AM - 8 PM) until you drink $goalMl ml. You have had ${s.waterMl} ml today. Add water on the Nutrition page.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
            }
            Switch(checked = water, onCheckedChange = { water = it; Notifier.setWater(ctx, it) })
        }
    }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("🚶 Step goal motivation", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
                Text(
                    "A motivation message every hour (7 AM - 9 PM) until you reach your step goal.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
            }
            Switch(checked = hourly, onCheckedChange = { hourly = it; Notifier.setHourly(ctx, it) })
        }
    }

    Text("💊 Medicine reminders", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
    if (meds.isEmpty()) {
        Text(
            "No medicine added yet. Add the name and the time, and you will get a reminder every day.",
            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f), modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
    meds.forEach { m ->
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
                    Text(timeText(m.hour, m.minute) + " · every day", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
                }
                Text(
                    "Remove", fontSize = 12.sp, color = FitColors.Coral, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { meds = MedStore.remove(ctx, m.id) }.padding(8.dp)
                )
            }
        }
    }
    Box(
        Modifier.fillMaxWidth().clip(CircleShape).background(FitColors.Blue)
            .clickable { showAdd = true }.padding(vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) { Text("+ Add medicine", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
    Text(
        "Android can move a reminder by a few minutes to save battery. Do not rely on this alone for important medicines. Keep the app's notifications switched on.",
        fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f), modifier = Modifier.padding(horizontal = 4.dp)
    )

    if (showAdd) {
        AddMedDialog(
            onDismiss = { showAdd = false },
            onSave = { name, h, m ->
                meds = MedStore.add(ctx, name, h, m)
                showAdd = false
            }
        )
    }
}

private fun timeText(hour: Int, minute: Int): String {
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    return "%d:%02d %s".format(h12, minute, if (hour < 12) "AM" else "PM")
}

@Composable
private fun AddMedDialog(onDismiss: () -> Unit, onSave: (String, Int, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var hour by remember { mutableIntStateOf(8) }
    var minute by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text("Add medicine", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Medicine name") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StepButton("−") { hour = (hour + 23) % 24 }
                    Text(timeText(hour, minute), fontWeight = FontWeight.Black, fontSize = 22.sp, color = FitColors.Ink)
                    StepButton("+") { hour = (hour + 1) % 24 }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Minutes", fontSize = 13.sp, color = FitColors.Ink)
                    StepButton("−") { minute = (minute + 55) % 60 }
                    Text("%02d".format(minute), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FitColors.Ink)
                    StepButton("+") { minute = (minute + 5) % 60 }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onSave(name, hour, minute) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(FitColors.Chip).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FitColors.Ink) }
}
