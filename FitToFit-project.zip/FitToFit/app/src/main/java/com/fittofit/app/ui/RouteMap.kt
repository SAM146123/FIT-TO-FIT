package com.fittofit.app.ui

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

private fun setupOsm(ctx: Context) {
    val c = Configuration.getInstance()
    c.load(ctx, ctx.getSharedPreferences("osm", Context.MODE_PRIVATE))
    c.userAgentValue = ctx.packageName
}

/** Shows the path travelled on an OpenStreetMap map (needs internet to draw the map tiles). */
@Composable
fun RouteMap(points: List<Pair<Double, Double>>, modifier: Modifier = Modifier, follow: Boolean = false) {
    val ctx = LocalContext.current
    remember { setupOsm(ctx); true }
    AndroidView(
        modifier = modifier,
        factory = { c ->
            MapView(c).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(!follow)
                controller.setZoom(16.0)
                if (follow) setOnTouchListener { _, _ -> true }
            }
        },
        update = { map ->
            map.overlays.clear()
            if (points.isNotEmpty()) {
                val geo = points.map { GeoPoint(it.first, it.second) }
                if (geo.size >= 2) {
                    val line = Polyline().apply {
                        setPoints(geo)
                        outlinePaint.color = 0xFF1565E8.toInt()
                        outlinePaint.strokeWidth = 12f
                    }
                    map.overlays.add(line)
                }
                val start = Marker(map).apply {
                    position = geo.first(); title = "Start"
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                }
                map.overlays.add(start)
                if (geo.size >= 2) {
                    val end = Marker(map).apply {
                        position = geo.last(); title = "Finish"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    }
                    map.overlays.add(end)
                }
                if (follow || geo.size < 2) {
                    map.controller.setZoom(17.0)
                    map.controller.setCenter(geo.last())
                } else {
                    val box = BoundingBox.fromGeoPoints(geo)
                    map.post { map.zoomToBoundingBox(box.increaseByScale(1.4f), false) }
                }
            }
            map.invalidate()
        },
        onRelease = { it.onDetach() }
    )
}
