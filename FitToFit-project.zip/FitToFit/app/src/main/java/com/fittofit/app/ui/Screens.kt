package com.fittofit.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.*

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Outlined.Home),
    Activity("Activity", Icons.Outlined.MonitorHeart),
    Progress("Progress", Icons.Outlined.BarChart),
    Goals("Goals", Icons.Outlined.Flag),
    Profile("Profile", Icons.Outlined.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FitApp(
    state: FitUiState,
    bpm: Int,
    history: List<Int>,
    watchStatus: WatchStatus,
    watchName: String?,
    devices: List<WatchDevice>,
    onConnectHealth: () -> Unit,
    onScan: () -> Unit,
    onStopScan: () -> Unit,
    onPickDevice: (WatchDevice) -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit
) {
    var tab by remember { mutableStateOf(Tab.Home) }
    var category by remember { mutableIntStateOf(0) }
    var showDevices by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = FitColors.Cream,
        bottomBar = { BottomNav(tab) { tab = it } }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("FIT TO FIT", fontSize = 30.sp, fontWeight = FontWeight.Black, color = FitColors.Ink, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Filled.Refresh, "Refresh", tint = FitColors.Ink) }
            }

            val heart = @Composable {
                HeartRateCard(bpm, history, watchName.takeIf { watchStatus == WatchStatus.Connected }) { showDevices = true }
            }

            when (tab) {
                Tab.Home -> {
                    ProfileCard(state.userName, state.level, Modifier.fillMaxWidth())
                    SectionLabel("Daily activity")
                    DailyActivityCard(state, onConnectHealth)
                    SectionLabel("Weekly progress")
                    WeeklyProgressCard(state.weeklySteps, state.today.distanceKm)
                    SectionLabel("Workout")
                    WorkoutCard(state.streakDays)
                    SectionLabel("Heart rate")
                    heart()
                }
                Tab.Activity -> {
                    SectionLabel("Workout")
                    WorkoutCard(state.streakDays)
                    SectionLabel("Categories")
                    CategoryTabs(category) { category = it }
                    SectionLabel("Exercises")
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ExerciseCard("Push-ups", "3 sets = 15", "3 sets", Modifier.weight(1f))
                        ExerciseCard("Plank", "2 mins", "2 mins", Modifier.weight(1f))
                    }
                    SectionLabel("Heart rate")
                    heart()
                }
                Tab.Progress -> {
                    SectionLabel("Weekly progress")
                    WeeklyProgressCard(state.weeklySteps, state.today.distanceKm)
                    SectionLabel("Achievements")
                    AchievementCard()
                }
                Tab.Goals -> {
                    SectionLabel("Goal tracker")
                    GoalTrackerCard(state.today.steps, state.stepGoal)
                    SectionLabel("Achievements")
                    AchievementCard()
                }
                Tab.Profile -> {
                    ProfileCard(state.userName, state.level, Modifier.fillMaxWidth())
                    SectionLabel("Connections")
                    ConnectionRow(
                        Icons.Filled.Watch, "Smartwatch (Bluetooth)",
                        when (watchStatus) {
                            WatchStatus.Connected -> "Connected: ${watchName ?: ""}"
                            WatchStatus.Scanning -> "Scanning…"
                            WatchStatus.Connecting -> "Connecting…"
                            WatchStatus.NoHeartRateService -> "This device has no heart-rate service"
                            WatchStatus.Failed -> "Connection failed — try again"
                            WatchStatus.Idle -> "Tap to connect"
                        }
                    ) { showDevices = true }
                    ConnectionRow(
                        Icons.Filled.Favorite, "Google Fit / Health Connect",
                        when {
                            state.healthConnected -> "Synced"
                            !state.healthAvailable -> "Health Connect not installed"
                            else -> "Tap to allow access"
                        },
                        onConnectHealth
                    )
                    Spacer(Modifier.height(8.dp))
                    heart()
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (showDevices) {
        ModalBottomSheet(
            onDismissRequest = { onStopScan(); showDevices = false },
            containerColor = Color.White
        ) {
            DeviceSheet(watchStatus, watchName, devices, onScan, onPickDevice, onDisconnect)
        }
    }
}

@Composable
private fun ConnectionRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = FitColors.Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
            }
        }
    }
}

@Composable
private fun DeviceSheet(
    status: WatchStatus,
    connectedName: String?,
    devices: List<WatchDevice>,
    onScan: () -> Unit,
    onPick: (WatchDevice) -> Unit,
    onDisconnect: () -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
        Text("Connect smartwatch", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Turn on Bluetooth and heart-rate broadcast / pairing mode on your watch, then scan.",
            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
        )
        Spacer(Modifier.height(14.dp))
        if (status == WatchStatus.Connected) {
            Text("Connected to $connectedName", color = FitColors.LimeDark, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDisconnect, colors = ButtonDefaults.buttonColors(containerColor = FitColors.Coral)) { Text("Disconnect") }
        } else {
            Button(onClick = onScan, colors = ButtonDefaults.buttonColors(containerColor = FitColors.Blue)) {
                Text(if (status == WatchStatus.Scanning) "Scanning…" else "Scan for devices")
            }
            if (status == WatchStatus.NoHeartRateService) {
                Text("This device does not share live heart rate over Bluetooth. Pick another.", color = FitColors.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(devices, key = { it.address }) { d ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(d) }.padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Watch, null, tint = FitColors.Ink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.Medium)
                            Text(d.address, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f))
                        }
                        Text("${d.rssi} dBm", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f))
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Surface(
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = Color.White, shadowElevation = 12.dp
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
            Tab.values().forEach { t ->
                val on = t == selected
                Column(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable { onSelect(t) }.padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(t.icon, t.label, tint = if (on) FitColors.Ink else FitColors.Ink.copy(alpha = .55f))
                    Text(t.label, fontSize = 11.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, color = if (on) FitColors.Ink else FitColors.Ink.copy(alpha = .55f))
                }
            }
        }
    }
}
