package com.fittofit.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.HealthAndSafety
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.FitUiState
import com.fittofit.app.SocialState
import com.fittofit.app.Profile
import com.fittofit.app.WatchDevice
import com.fittofit.app.WatchStatus

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Outlined.Home),
    Activity("Activity", Icons.Outlined.MonitorHeart),
    Health("Health", Icons.Outlined.HealthAndSafety),
    Friends("Friends", Icons.Outlined.Groups),
    Progress("Progress", Icons.Outlined.BarChart),
    Profile("Profile", Icons.Outlined.Person)
}

private fun profileSubtitle(p: Profile): String {
    val parts = buildList {
        if (p.age > 0) add("${p.age} yrs")
        if (p.heightCm > 0) add("${p.heightCm} cm")
        if (p.weightKg > 0) add("${p.weightKg} kg")
    }
    return if (parts.isEmpty()) "Tap to add your details" else parts.joinToString(" · ")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FitApp(
    state: FitUiState,
    bpm: Int,
    history: List<Int>,
    watchStatus: WatchStatus,
    watchName: String?,
    devices: List<WatchDevice>,
    onConnectHealth: () -> Unit,
    onScan: () -> Unit,
    onStopScan: () -> Unit,
    onPickDevice: (WatchDevice) -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit,
    onStartWalk: (String) -> Unit,
    onStopWalk: () -> Unit,
    onSaveProfile: (Profile) -> Unit,
    actions: HealthActions,
    onWelcomed: () -> Unit,
    onCelebrated: () -> Unit,
    social: SocialState,
    socialActions: SocialActions,
    extra: ExtraActions
) {
    var tab by remember { mutableStateOf(Tab.Home) }
    var category by remember { mutableIntStateOf(0) }
    var showDevices by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var healthPage by remember { mutableStateOf<HealthKind?>(null) }
    var detail by remember { mutableStateOf<com.fittofit.app.ActivityItem?>(null) }
    var showToday by remember { mutableStateOf(false) }
    var showSteps by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(state.healthConnected) { if (state.healthConnected) extra.loadHistory() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var coachEx by remember { mutableStateOf<Exercise?>(null) }

    BackHandler(enabled = tab == Tab.Health && healthPage != null) { healthPage = null }
    BackHandler(enabled = tab == Tab.Activity && coachEx != null) { extra.stopSpeak(); coachEx = null }

    // first launch: ask for the user's details
    LaunchedEffect(Unit) {
        if (state.profile.name.isBlank()) showProfile = true
    }

    Scaffold(
        containerColor = FitColors.Cream,
        contentColor = FitColors.Ink,
        bottomBar = { BottomNav(tab) { tab = it } }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "FIT TO FIT", fontSize = 30.sp, fontWeight = FontWeight.Black,
                    color = FitColors.Ink, modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onRefresh) { Icon(Icons.Filled.Refresh, "Refresh", tint = FitColors.Ink) }
            }

            val profileCard = @Composable {
                ProfileCard(
                    name = state.profile.name,
                    level = state.level,
                    subtitle = profileSubtitle(state.profile),
                    modifier = Modifier.fillMaxWidth(),
                    photo = state.photoB64
                ) { showProfile = true }
            }
            val heart = @Composable {
                HeartRateCard(bpm, history, watchName.takeIf { watchStatus == WatchStatus.Connected }) { showDevices = true }
            }

            when (tab) {
                Tab.Home -> {
                    profileCard()
                    SectionLabel("Daily activity")
                    DailyActivityCard(state, onConnectHealth, onSteps = { showSteps = true; extra.loadHistory() })
                    if (state.stepsSource.isNotBlank()) {
                        Text(
                            "Steps from: ${state.stepsSource}",
                            fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f),
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                    SectionLabel("Weekly progress")
                    WeeklyProgressCard(state.weeklySteps, state.weekDistanceKm)
                    LifetimeCard(state) { showSteps = true; extra.loadHistory() }
                    SectionLabel("Workout")
                    WalkingTodayCard(state, onDetails = { showToday = true }) {
                        category = 0
                        tab = Tab.Activity
                    }
                    SectionLabel("Today's motivation")
                    QuoteCard { Sharer.achievement(ctx, state) }
                    SectionLabel("Achievements")
                    AchievementsDashboard(state.badges) { Sharer.achievement(ctx, state) }
                    SectionLabel("Recent activity")
                    ActivityFeedCard(state.activity) { detail = it }
                    SectionLabel("Heart rate")
                    heart()
                }
                Tab.Activity -> {
                    val ex = coachEx
                    if (ex != null) {
                        CoachPlayer(ex, state.voiceOn, state.voiceProblem, extra) { coachEx = null }
                    } else {
                        SectionLabel("Walking")
                        WalkCard(state.walk, state.sensorAvailable, state.voiceOn, extra.setVoice, onStartWalk, onStopWalk)
                        SectionLabel("Video Coach")
                        CoachHub { coachEx = it }
                        SectionLabel("Recent activity")
                        ActivityFeedCard(state.activity) { detail = it }
                        SectionLabel("Heart rate")
                        heart()
                    }
                }
                Tab.Health -> {
                    HealthTab(state, bpm, healthPage, { healthPage = it }, actions)
                }
                Tab.Friends -> {
                    FriendsTab(state, social, socialActions)
                }
                Tab.Progress -> {
                    SectionLabel("Weekly progress")
                    WeeklyProgressCard(state.weeklySteps, state.weekDistanceKm)
                    SectionLabel("Goal tracker")
                    GoalTrackerCard(state.today.steps, state.stepGoal)
                    SectionLabel("Achievements")
                    AchievementCard(state.today.steps, state.stepGoal, state.streakDays)
                    SectionLabel("Your badges")
                    AchievementsDashboard(state.badges) { Sharer.achievement(ctx, state) }
                    SectionLabel("Today's motivation")
                    QuoteCard { Sharer.achievement(ctx, state) }
                }
                Tab.Profile -> {
                    profileCard()
                    SectionLabel("Connections")
                    ConnectionRow(
                        Icons.Filled.Watch, "Smartwatch (Bluetooth)",
                        when (watchStatus) {
                            WatchStatus.Connected -> "Paired & connected: ${watchName ?: ""}"
                            WatchStatus.Scanning -> "Scanning…"
                            WatchStatus.Connecting -> "Connecting…"
                            WatchStatus.NoHeartRateService -> "This device has no heart-rate service"
                            WatchStatus.Failed -> "Connection failed — try again"
                            WatchStatus.Idle ->
                                if (state.pairedWatch.isNotBlank()) "Paired: ${state.pairedWatch} (reconnects automatically)" else "Tap to connect"
                        }
                    ) { showDevices = true }
                    ConnectionRow(
                        Icons.Filled.Favorite, "Google Fit / Health Connect",
                        when {
                            state.healthConnected -> "Synced"
                            !state.healthAvailable -> "Health Connect not installed"
                            else -> "Tap to allow access"
                        },
                        onConnectHealth
                    )
                    Text(
                        "Watch steps reach this app through Health Connect: open your watch's own app " +
                            "(Mi Fitness, Zepp, Galaxy Wearable, Fitbit, Google Fit…) and turn on " +
                            "\"sync to Health Connect\".",
                        fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    heart()
                    SectionLabel("Watch wallpaper")
                    WatchWallpaperCard(state.profile.name)
                    SectionLabel("Settings")
                    SettingsCard()
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (showDevices) {
        ModalBottomSheet(
            onDismissRequest = { onStopScan(); showDevices = false },
            containerColor = FitColors.Surface
        ) {
            DeviceSheet(watchStatus, watchName, devices, onScan, onPickDevice, onDisconnect)
        }
    }

    if (state.showWelcome) {
        WelcomeBackDialog(state.profile.name, state.today.steps, state.stepGoal, state.streakDays, onWelcomed)
    } else if (state.showCelebration) {
        GoalCelebrationDialog(
            state.profile.name, state.today.steps, state.stepGoal, state.streakDays,
            onShare = { Sharer.achievement(ctx, state) }, onDismiss = onCelebrated
        )
    }

    detail?.let { ActivityDetailDialog(it) { detail = null } }
    if (showToday) TodayDetailDialog(state) { showToday = false }
    if (showSteps) StepsHistoryDialog(state, onGrant = onConnectHealth) { showSteps = false }

    if (showProfile) {
        ProfileDialog(
            initial = state.profile,
            photo = state.photoB64,
            extra = extra,
            onDismiss = { showProfile = false },
            onSave = {
                onSaveProfile(it)
                showProfile = false
            }
        )
    }
}

@Composable
private fun ProfileDialog(initial: Profile, photo: String, extra: ExtraActions, onDismiss: () -> Unit, onSave: (Profile) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var age by remember { mutableStateOf(if (initial.age > 0) initial.age.toString() else "") }
    var height by remember { mutableStateOf(if (initial.heightCm > 0) initial.heightCm.toString() else "") }
    var weight by remember { mutableStateOf(if (initial.weightKg > 0) initial.weightKg.toString() else "") }
    var goal by remember { mutableStateOf(initial.stepGoal.toString()) }
    var sex by remember { mutableStateOf(initial.sex) }
    var country by remember { mutableStateOf(initial.country) }
    var dietGoal by remember { mutableStateOf(initial.goal) }
    var veg by remember { mutableStateOf(initial.veg) }
    var pickCountry by remember { mutableStateOf(false) }
    val numbers = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FitColors.Surface,
        title = { Text("Your profile", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PhotoAvatar(photo, name.ifBlank { "?" }, 64.dp, FitColors.Purple, FitColors.Ink)
                    Column {
                        TextButton(onClick = extra.pickPhoto) { Text(if (photo.isBlank()) "Add photo" else "Change photo") }
                        if (photo.isNotBlank()) TextButton(onClick = extra.removePhoto) { Text("Remove photo") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("M" to "Male", "F" to "Female").forEach { (code, label) ->
                        Text(
                            label,
                            color = if (sex == code) Color.White else FitColors.Ink,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clip(CircleShape)
                                .background(if (sex == code) FitColors.Blue else FitColors.Chip)
                                .clickable { sex = code }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(age, { age = it.filter(Char::isDigit) }, label = { Text("Age") }, singleLine = true, keyboardOptions = numbers)
                OutlinedTextField(height, { height = it.filter(Char::isDigit) }, label = { Text("Height (cm)") }, singleLine = true, keyboardOptions = numbers)
                OutlinedTextField(weight, { weight = it.filter(Char::isDigit) }, label = { Text("Weight (kg)") }, singleLine = true, keyboardOptions = numbers)
                OutlinedTextField(goal, { goal = it.filter(Char::isDigit) }, label = { Text("Daily step goal") }, singleLine = true, keyboardOptions = numbers)
                Text(
                    "Country: " + country.ifBlank { "Choose your country" } + "  ›",
                    color = FitColors.Ink, fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth().clip(CircleShape).background(FitColors.Chip)
                        .clickable { pickCountry = true }.padding(horizontal = 16.dp, vertical = 12.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("lose" to "Lose weight", "maintain" to "Maintain", "gain" to "Gain muscle").forEach { (k, label) ->
                        Text(
                            label, fontSize = 12.sp,
                            color = if (dietGoal == k) Color.White else FitColors.Ink,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clip(CircleShape)
                                .background(if (dietGoal == k) FitColors.Blue else FitColors.Chip)
                                .clickable { dietGoal = k }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                Text(
                    if (veg) "Vegetarian ✓" else "Eat everything (tap for vegetarian)",
                    color = if (veg) Color.White else FitColors.Ink, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (veg) FitColors.LimeDark else FitColors.Chip)
                        .clickable { veg = !veg }.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    Profile(
                        name = name.trim(),
                        age = age.toIntOrNull() ?: 0,
                        heightCm = height.toIntOrNull() ?: 0,
                        weightKg = weight.toIntOrNull() ?: 0,
                        stepGoal = (goal.toIntOrNull() ?: 10_000).coerceIn(1000, 100_000),
                        sex = sex,
                        country = country,
                        goal = dietGoal,
                        veg = veg
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (pickCountry) CountryPickerDialog(country, onPick = { country = it; pickCountry = false }) { pickCountry = false }
}

@Composable
private fun ConnectionRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = FitColors.Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
            }
        }
    }
}

@Composable
private fun DeviceSheet(
    status: WatchStatus,
    connectedName: String?,
    devices: List<WatchDevice>,
    onScan: () -> Unit,
    onPick: (WatchDevice) -> Unit,
    onDisconnect: () -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
        Text("Connect smartwatch", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Turn on Bluetooth and heart-rate broadcast / pairing mode on your watch, then scan.",
            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f)
        )
        Spacer(Modifier.height(14.dp))
        if (status == WatchStatus.Connected) {
            Text("Paired with $connectedName", color = FitColors.LimeDark, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDisconnect, colors = ButtonDefaults.buttonColors(containerColor = FitColors.Coral)) { Text("Forget watch") }
        } else {
            Button(onClick = onScan, colors = ButtonDefaults.buttonColors(containerColor = FitColors.Blue)) {
                Text(if (status == WatchStatus.Scanning) "Scanning…" else "Scan for devices")
            }
            if (status == WatchStatus.NoHeartRateService) {
                Text(
                    "This device does not share live heart rate over Bluetooth. Pick another.",
                    color = FitColors.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(devices, key = { it.address }) { d ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(d) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Watch, null, tint = FitColors.Ink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.Medium)
                            Text(d.address, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f))
                        }
                        Text("${d.rssi} dBm", fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .5f))
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Surface(
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = FitColors.Surface, shadowElevation = 12.dp
    ) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Tab.values().forEach { t ->
                val on = t == selected
                Column(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable { onSelect(t) }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(t.icon, t.label, tint = if (on) FitColors.Ink else FitColors.Ink.copy(alpha = .55f))
                    Text(
                        t.label, fontSize = 10.sp, maxLines = 1,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) FitColors.Ink else FitColors.Ink.copy(alpha = .55f)
                    )
                }
            }
        }
    }
}
