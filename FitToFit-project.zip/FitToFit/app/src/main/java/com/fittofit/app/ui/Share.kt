package com.fittofit.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.fittofit.app.FitUiState
import com.fittofit.app.Quotes
import com.fittofit.app.Settings
import java.io.File

/** Sharing progress and invites, always with the app's download link. */
object Sharer {

    private fun link() = Settings.appLink

    /** Draws a 1080 x 1350 picture with today's numbers. */
    private fun card(s: FitUiState, quote: String): Bitmap {
        val w = 1080
        val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF1565E8.toInt(), 0xFF4CCFD0.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null
        p.color = 0x22FFFFFF
        c.drawCircle(w * 0.9f, h * 0.1f, 380f, p)
        c.drawCircle(w * 0.05f, h * 0.9f, 320f, p)

        p.textAlign = Paint.Align.CENTER
        p.color = 0xFFFFFFFF.toInt()
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = 64f
        c.drawText("FIT TO FIT", w / 2f, 130f, p)

        val name = s.profile.name
        p.typeface = Typeface.DEFAULT
        p.textSize = 42f
        p.color = 0xDDFFFFFF.toInt()
        c.drawText(if (name.isNotBlank()) "$name's day" else "My day", w / 2f, 200f, p)

        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = 230f
        p.color = 0xFFFFFFFF.toInt()
        c.drawText("%,d".format(s.today.steps), w / 2f, 520f, p)
        p.textSize = 52f
        c.drawText("STEPS TODAY", w / 2f, 590f, p)

        val stats = listOf(
            "%.2f".format(s.today.distanceKm) to "KM",
            "${s.today.calories.toInt()}" to "KCAL",
            "${s.streakDays}" to "DAY STREAK"
        )
        stats.forEachIndexed { i, (v, l) ->
            val x = w * (0.2f + 0.3f * i)
            p.textSize = 78f
            p.color = 0xFFFFFFFF.toInt()
            c.drawText(v, x, 760f, p)
            p.textSize = 34f
            p.typeface = Typeface.DEFAULT
            p.color = 0xCCFFFFFF.toInt()
            c.drawText(l, x, 810f, p)
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        if (s.today.steps >= s.stepGoal) {
            p.textSize = 46f
            p.color = 0xFFFFE066.toInt()
            c.drawText("🏆 Daily goal complete!", w / 2f, 910f, p)
        }

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        val layout = StaticLayout.Builder.obtain("“$quote”", 0, quote.length + 2, tp, w - 200)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        c.save()
        c.translate(100f, 990f)
        layout.draw(c)
        c.restore()

        p.typeface = Typeface.DEFAULT
        p.textSize = 32f
        p.color = 0xDDFFFFFF.toInt()
        c.drawText(link().removePrefix("https://").removePrefix("http://").take(60), w / 2f, h - 60f, p)
        return bmp
    }

    private fun start(ctx: Context, text: String, bmp: Bitmap?, title: String) {
        val send = Intent(Intent.ACTION_SEND)
        send.putExtra(Intent.EXTRA_TEXT, text)
        var done = false
        if (bmp != null) {
            try {
                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                val f = File(dir, "fit_to_fit_${System.currentTimeMillis()}.png")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                send.type = "image/png"
                send.putExtra(Intent.EXTRA_STREAM, uri)
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                done = true
            } catch (e: Exception) {
                done = false
            }
        }
        if (!done) send.type = "text/plain"
        ctx.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Share today's achievement as a picture plus text and the download link. */
    fun achievement(ctx: Context, s: FitUiState) {
        val quote = Quotes.today("en")
        val goal = if (s.today.steps >= s.stepGoal) "I completed my daily goal! 🏆 " else ""
        val text = "$goal🏃 ${"%,d".format(s.today.steps)} steps, ${"%.2f".format(s.today.distanceKm)} km and " +
            "${s.today.calories.toInt()} kcal today with FIT TO FIT!\n\"$quote\"\n\nGet the app: ${link()}"
        start(ctx, text, card(s, quote), "Share your achievement")
    }

    /** Invite friends: message with the app link and (if signed in) your friend code. */
    fun invite(ctx: Context, code: String, name: String) {
        val who = if (name.isNotBlank()) "$name invites you" else "Join me"
        val codeLine = if (code.isNotBlank()) "\nAdd my friend code: $code and let's compete! 💪" else "\nLet's compete on daily steps! 💪"
        val text = "$who to FIT TO FIT, the fitness app with friend challenges. 🏃$codeLine\n\nDownload: ${link()}"
        start(ctx, text, null, "Invite friends")
    }
}
