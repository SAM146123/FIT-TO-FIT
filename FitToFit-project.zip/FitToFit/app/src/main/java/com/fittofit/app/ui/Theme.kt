package com.fittofit.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.fittofit.app.Settings
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object FitColors {
    /** True while the dark theme is showing. */
    val dark = mutableStateOf(false)
    private val d get() = dark.value

    val Cream: Color get() = if (d) Color(0xFF11131F) else Color(0xFFFAF3E7)
    val Surface: Color get() = if (d) Color(0xFF1D2036) else Color.White
    val Chip: Color get() = if (d) Color(0xFF2C3050) else Color(0xFFEFEFEF)
    val Highlight: Color get() = if (d) Color(0xFF22305A) else Color(0xFFE6F0FF)
    val Ink: Color get() = if (d) Color(0xFFEDEEF5) else Color(0xFF1B1F3B)
    val Navy = Color(0xFF141A3A)
    val Coral: Color get() = if (d) Color(0xFFB5503F) else Color(0xFFFF7A66)
    val Lime: Color get() = if (d) Color(0xFF5E7A12) else Color(0xFFCDEB4E)
    val LimeDark: Color get() = if (d) Color(0xFF8DB82A) else Color(0xFF7DA11A)
    val Blue = Color(0xFF1565E8)
    val Yellow: Color get() = if (d) Color(0xFF9A7410) else Color(0xFFFFC93C)
    val Teal: Color get() = if (d) Color(0xFF1E7F80) else Color(0xFF4CCFD0)
    val Orange: Color get() = if (d) Color(0xFFB5601A) else Color(0xFFFF9330)
    val Purple: Color get() = if (d) Color(0xFF6A5AA8) else Color(0xFFC9B8F5)
    val Red = Color(0xFFFF4D5A)
}

private val FitTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 34.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp)
)

@Composable
fun FitTheme(content: @Composable () -> Unit) {
    val dark = when (Settings.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    remember(dark) { FitColors.dark.value = dark; dark }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }
        }
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = FitColors.Blue, background = FitColors.Cream, surface = FitColors.Surface,
            onBackground = FitColors.Ink, onSurface = FitColors.Ink
        )
    } else {
        lightColorScheme(
            primary = FitColors.Blue, background = FitColors.Cream, surface = Color.White,
            onBackground = FitColors.Ink, onSurface = FitColors.Ink
        )
    }
    MaterialTheme(colorScheme = scheme, typography = FitTypography, content = content)
}
