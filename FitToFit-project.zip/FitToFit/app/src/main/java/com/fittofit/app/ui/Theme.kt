package com.fittofit.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object FitColors {
    val Cream = Color(0xFFFAF3E7)
    val Ink = Color(0xFF1B1F3B)
    val Navy = Color(0xFF141A3A)
    val Coral = Color(0xFFFF7A66)
    val Lime = Color(0xFFCDEB4E)
    val LimeDark = Color(0xFF7DA11A)
    val Blue = Color(0xFF1565E8)
    val Yellow = Color(0xFFFFC93C)
    val Teal = Color(0xFF4CCFD0)
    val Orange = Color(0xFFFF9330)
    val Purple = Color(0xFFC9B8F5)
    val Red = Color(0xFFFF4D5A)
}

private val FitTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 34.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp)
)

@Composable
fun FitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = FitColors.Blue,
            background = FitColors.Cream,
            surface = Color.White,
            onBackground = FitColors.Ink,
            onSurface = FitColors.Ink
        ),
        typography = FitTypography,
        content = content
    )
}
