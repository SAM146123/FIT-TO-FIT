package com.fittofit.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.Condition
import com.fittofit.app.FirstAid
import com.fittofit.app.FitUiState
import com.fittofit.app.HealthContent
import com.fittofit.app.HomeTip
import com.fittofit.app.L
import com.fittofit.app.Notifier
import com.fittofit.app.Profile

/* ---------------- small helpers ---------------- */

@Composable
private fun TipPill(text: String, on: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(if (on) FitColors.Ink else FitColors.Chip)
            .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (on) FitColors.Surface else FitColors.Ink)
    }
}

@Composable
private fun Bullets(title: String, items: List<L>, color: Color) {
    if (items.isEmpty()) return
    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color, modifier = Modifier.padding(top = 6.dp))
    items.forEach {
        Row(Modifier.padding(top = 3.dp)) {
            Text("•", fontSize = 13.sp, color = color, modifier = Modifier.width(14.dp))
            Text(it.t(), fontSize = 13.sp, color = FitColors.Ink)
        }
    }
}

@Composable
private fun Disclaimer() {
    Text(
        HealthContent.disclaimer.t(),
        fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f),
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}

/* ---------------- choose your health conditions ---------------- */

@Composable
fun ConditionChips(p: Profile, onSave: (Profile) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HealthContent.conditions.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { c ->
                    TipPill(
                        c.emoji + " " + c.title.t(), HealthContent.has(p, c.id), Modifier.weight(1f)
                    ) { onSave(HealthContent.toggle(p, c.id)) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Diet advice for one health condition. */
@Composable
fun ConditionAdvice(c: Condition, veg: Boolean, showHome: Boolean) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(c.emoji + " " + c.title.t(), fontWeight = FontWeight.Black, fontSize = 17.sp, color = FitColors.Ink)
            Text(c.intro.t(), fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .75f))
            Bullets(tr("Eat more"), c.eat + (if (veg) emptyList() else c.nonVeg), FitColors.LimeDark)
            Bullets(tr("Avoid or limit"), c.avoid, FitColors.Red)
            if (c.meals.isNotEmpty()) {
                Text(tr("A day of meals"), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FitColors.Blue, modifier = Modifier.padding(top = 8.dp))
                c.meals.forEach { (label, food) ->
                    Row(Modifier.padding(top = 4.dp)) {
                        Text(label.t(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink, modifier = Modifier.weight(0.34f))
                        Text(food.t(), fontSize = 12.sp, color = FitColors.Ink, modifier = Modifier.weight(0.66f))
                    }
                }
            }
            Bullets(tr("Daily habits"), c.lifestyle, FitColors.Blue)
            if (showHome) Bullets(tr("Home care"), c.home, FitColors.Orange)
        }
    }
}

/** Used on the Diet Plan page: pick conditions and see the matching diet. */
@Composable
fun ConditionDietSection(p: Profile, onSave: (Profile) -> Unit) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("Health conditions"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            Text(
                tr("Tap the ones that apply to you. The diet advice below changes for each one."),
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
            )
            ConditionChips(p, onSave)
        }
    }
    val chosen = HealthContent.conditions.filter { HealthContent.has(p, it.id) }
    chosen.forEach { ConditionAdvice(it, p.veg, showHome = false) }
    if (chosen.isNotEmpty()) {
        Text(
            tr("The 7-day plan below is a general healthy plan. Use the advice above to pick the right dishes from it."),
            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f), modifier = Modifier.padding(horizontal = 4.dp)
        )
        Disclaimer()
    }
}

/* ---------------- the Health Tips page ---------------- */

@Composable
fun TipsPage(s: FitUiState, onSave: (Profile) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("My health", "First aid", "Home tips", "Healthy living")
    val ctx = LocalContext.current
    var hourly by remember { mutableStateOf(Notifier.hourlyEnabled(ctx)) }

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        tabs.forEachIndexed { i, t -> TipPill(tr(t), tab == i, Modifier.weight(1f)) { tab = i } }
    }

    when (tab) {
        0 -> {
            val p = s.profile
            FitCard(Color.White, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Do you have any of these?"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
                    Text(
                        tr("Tap to choose. You will get diet advice, daily habits and safe home care for each one."),
                        fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                    )
                    ConditionChips(p, onSave)
                }
            }
            val chosen = HealthContent.conditions.filter { HealthContent.has(p, it.id) }
            if (chosen.isEmpty()) {
                Text(
                    tr("Nothing chosen yet. Choose a condition above to see your plan."),
                    fontSize = 13.sp, color = FitColors.Ink.copy(alpha = .65f), modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
            chosen.forEach { ConditionAdvice(it, p.veg, showHome = true) }
            Disclaimer()
        }
        1 -> {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(FitColors.Red).padding(14.dp)
            ) {
                Text(HealthContent.emergency.t(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            HealthContent.firstAid.forEach { FirstAidCard(it) }
            Disclaimer()
        }
        2 -> {
            Text(tr("Easy home tips"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            HealthContent.homeTips.forEach { HomeTipCard(it) }
            Text(tr("Skin, hair and eye home care"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink, modifier = Modifier.padding(top = 6.dp))
            HealthContent.conditions.filter { it.id == "skin" || it.id == "hair" || it.id == "eye" }.forEach { c ->
                var open by remember { mutableStateOf(false) }
                FitCard(Color.White, Modifier.fillMaxWidth().clickable { open = !open }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(c.emoji + " " + c.title.t(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                            Text(if (open) "▲" else "▼", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .5f))
                        }
                        if (open) c.home.forEach {
                            Row(Modifier.padding(top = 4.dp)) {
                                Text("•", fontSize = 13.sp, color = FitColors.Orange, modifier = Modifier.width(14.dp))
                                Text(it.t(), fontSize = 13.sp, color = FitColors.Ink)
                            }
                        }
                    }
                }
            }
            Disclaimer()
        }
        else -> {
            FitCard(Color.White, Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Hourly motivation"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink)
                        Text(
                            tr("A motivation message every hour (7 AM to 9 PM) until you reach your step goal."),
                            fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                        )
                    }
                    Switch(checked = hourly, onCheckedChange = { hourly = it; Notifier.setHourly(ctx, it) })
                }
            }
            Text(tr("Workout tips"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            HealthContent.workoutTips.forEach { TipRow(it, FitColors.Blue) }
            Text(tr("Food tips"), fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink, modifier = Modifier.padding(top = 6.dp))
            HealthContent.foodTips.forEach { TipRow(it, FitColors.LimeDark) }
            Disclaimer()
        }
    }
}

@Composable
private fun TipRow(t: L, color: Color) {
    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp)) {
            Box(Modifier.padding(top = 5.dp).width(8.dp).height(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(t.t(), fontSize = 13.sp, color = FitColors.Ink)
        }
    }
}

@Composable
private fun FirstAidCard(f: FirstAid) {
    var open by remember { mutableStateOf(false) }
    FitCard(Color.White, Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(f.emoji + " " + f.title.t(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                Text(if (open) "▲" else "▼", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .5f))
            }
            if (open) {
                f.steps.forEachIndexed { i, st ->
                    Row(Modifier.padding(top = 4.dp)) {
                        Text("${i + 1}.", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FitColors.Blue, modifier = Modifier.width(22.dp))
                        Text(st.t(), fontSize = 13.sp, color = FitColors.Ink)
                    }
                }
                Text(f.hospital.t(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Red, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun HomeTipCard(t: HomeTip) {
    var open by remember { mutableStateOf(false) }
    FitCard(Color.White, Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.emoji + " " + t.title.t(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                Text(if (open) "▲" else "▼", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .5f))
            }
            if (open) Text(t.text.t(), fontSize = 13.sp, color = FitColors.Ink)
        }
    }
}
