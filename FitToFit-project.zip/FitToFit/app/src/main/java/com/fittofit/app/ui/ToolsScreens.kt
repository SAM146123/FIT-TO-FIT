package com.fittofit.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fittofit.app.AiCoach
import com.fittofit.app.BackupManager
import com.fittofit.app.CrashLog
import com.fittofit.app.FitUiState
import com.fittofit.app.FoodAI
import com.fittofit.app.FoodAiException
import com.fittofit.app.HealthLogStore
import com.fittofit.app.L
import com.fittofit.app.LogEntry
import com.fittofit.app.MedStore
import com.fittofit.app.Settings
import com.fittofit.app.UpdateChecker
import com.fittofit.app.UpdateInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/* ---------------- shared small pieces ---------------- */

@Composable
private fun ToolButton(text: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun ToolNote(text: String) {
    Text(text, fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(horizontal = 4.dp))
}

private fun fmtTime(ms: Long): String =
    java.text.SimpleDateFormat("dd MMM, h:mm a", java.util.Locale.getDefault()).format(java.util.Date(ms))

/* ---------------- AI health assistant ---------------- */

@Composable
fun AiPage(s: FitUiState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var hasKey by remember { mutableStateOf(FoodAI.key(ctx).isNotBlank()) }
    var keyText by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun send(question: String) {
        if (question.isBlank() || busy) return
        val history = messages.toList()
        messages.add("user" to question)
        input = ""
        busy = true
        error = ""
        scope.launch {
            try {
                val system = AiCoach.systemPrompt(s.profile, s.today.steps.toLong(), Settings.lang == "ta")
                val answer = withContext(Dispatchers.IO) { AiCoach.ask(FoodAI.key(ctx), system, history, question) }
                messages.add("model" to answer)
            } catch (e: FoodAiException) {
                error = e.message ?: "Something went wrong."
            } catch (e: Exception) {
                error = "Something went wrong. Please try again."
            }
            busy = false
        }
    }

    if (!hasKey) {
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🤖 AI Health Assistant", fontWeight = FontWeight.Black, fontSize = 17.sp, color = FitColors.Ink)
                Text(
                    "Ask about food, exercise and healthy habits, and get a weekly report. It uses your own free Gemini key (the same one as the food photo scan).",
                    fontSize = 13.sp, color = FitColors.Ink
                )
                ToolButton("1. Open aistudio.google.com (free key)", FitColors.Ink, Modifier.fillMaxWidth()) {
                    try { uri.openUri("https://aistudio.google.com/apikey") } catch (e: Exception) { }
                }
                OutlinedTextField(
                    keyText, { keyText = it.trim() }, label = { Text("Paste your Gemini key") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                ToolButton("2. Save key", FitColors.Blue, Modifier.fillMaxWidth()) {
                    if (keyText.length > 20) {
                        FoodAI.saveKey(ctx, keyText)
                        hasKey = true
                    }
                }
            }
        }
        return
    }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🤖 AI Health Assistant", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            Text("Try one of these, or type your own question:", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f))
            val ideas = listOf(
                "📊 My weekly report" to (
                    "Make my weekly health report. My steps for the last 7 days: " + s.weeklySteps.joinToString(", ") +
                        ". Daily goal: ${s.stepGoal}. Streak: ${s.streakDays} days. Water today: ${s.waterMl} ml. " +
                        "Calories eaten today: ${s.foodKcal}. Recent weights: " +
                        (s.weights.takeLast(5).joinToString(", ") { "%.1f kg".format(it.second) }.ifBlank { "not logged" }) +
                        ". Tell me 1) what went well 2) what to improve 3) three simple actions for next week."
                    ),
                "🍽️ What should I eat today?" to "Suggest a simple healthy meal plan for today (breakfast, lunch, snack, dinner) for me.",
                "🦵 Easy exercises for me" to "Suggest a safe 15 minute home workout for me, with simple steps.",
                "😴 Sleep better" to "Give me 5 simple tips to sleep better tonight."
            )
            ideas.forEach { (label, prompt) ->
                Box(
                    Modifier.fillMaxWidth().clip(CircleShape).background(FitColors.Chip)
                        .clickable { send(prompt) }.padding(horizontal = 14.dp, vertical = 10.dp)
                ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink) }
            }
        }
    }

    messages.forEach { (role, text) ->
        val mine = role == "user"
        FitCard(if (mine) FitColors.Blue else Color.White, Modifier.fillMaxWidth()) {
            Text(
                text, fontSize = 13.sp, color = if (mine) Color.White else FitColors.Ink,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
    if (busy) Text("Thinking...", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f), modifier = Modifier.padding(horizontal = 4.dp))
    if (error.isNotBlank()) Text(error, fontSize = 12.sp, color = FitColors.Red, modifier = Modifier.padding(horizontal = 4.dp))

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            input, { input = it.take(500) }, label = { Text("Ask a health question") },
            modifier = Modifier.weight(1f)
        )
        ToolButton("Send", FitColors.Blue) { send(input) }
    }
    ToolNote(
        "AI can make mistakes and is not a doctor. For serious or lasting problems, see a doctor. " +
            "Your question and basic profile (age, height, weight, goal, health conditions) are sent to Google Gemini using your own key. Your name is not sent."
    )
    if (messages.isNotEmpty()) {
        Text(
            "Clear chat", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Coral,
            modifier = Modifier.clickable { messages.clear(); error = "" }.padding(8.dp)
        )
    }
}

/* ---------------- sugar and blood pressure log ---------------- */

private fun sugarStatus(v: Int, afterMeal: Boolean): Pair<L, Color> = when {
    v < 70 -> L("Low - take some sugar now and check again", "குறைவு - உடனே சர்க்கரை சாப்பிட்டு மீண்டும் பாருங்கள்") to FitColors.Red
    afterMeal -> when {
        v < 140 -> L("Normal", "இயல்பு") to FitColors.LimeDark
        v < 200 -> L("A little high", "சற்று அதிகம்") to FitColors.Orange
        else -> L("High - tell your doctor", "அதிகம் - மருத்துவரிடம் சொல்லுங்கள்") to FitColors.Red
    }
    else -> when {
        v < 100 -> L("Normal", "இயல்பு") to FitColors.LimeDark
        v < 126 -> L("A little high", "சற்று அதிகம்") to FitColors.Orange
        else -> L("High - tell your doctor", "அதிகம் - மருத்துவரிடம் சொல்லுங்கள்") to FitColors.Red
    }
}

private fun bpStatus(sys: Int, dia: Int): Pair<L, Color> = when {
    sys >= 180 || dia >= 120 -> L("Very high - see a doctor today. Chest pain or breathlessness: emergency", "மிக அதிகம் - இன்றே மருத்துவரைப் பாருங்கள். நெஞ்சு வலி / மூச்சுத் திணறல் என்றால் அவசரம்") to FitColors.Red
    sys < 90 || dia < 60 -> L("Low - sit down, drink water. See a doctor if dizzy", "குறைவு - அமர்ந்து தண்ணீர் குடியுங்கள். தலைச்சுற்றல் இருந்தால் மருத்துவரைப் பாருங்கள்") to FitColors.Orange
    sys >= 140 || dia >= 90 -> L("High - tell your doctor", "அதிகம் - மருத்துவரிடம் சொல்லுங்கள்") to FitColors.Red
    sys >= 130 || dia >= 80 -> L("A little high", "சற்று அதிகம்") to FitColors.Orange
    else -> L("Normal", "இயல்பு") to FitColors.LimeDark
}

@Composable
fun RecordsPage() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var entries by remember { mutableStateOf(HealthLogStore.all(ctx)) }
    var v1 by remember { mutableStateOf("") }
    var v2 by remember { mutableStateOf("") }
    var afterMeal by remember { mutableStateOf(false) }
    var warn by remember { mutableStateOf("") }
    val type = if (tab == 0) "sugar" else "bp"
    val shown = entries.filter { it.type == type }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("🩸 Sugar", "❤️ Blood pressure").forEachIndexed { i, t ->
            Box(
                Modifier.weight(1f).clip(CircleShape).background(if (tab == i) FitColors.Ink else FitColors.Chip)
                    .clickable { tab = i; v1 = ""; v2 = ""; warn = "" }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text(t, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tab == i) FitColors.Surface else FitColors.Ink) }
        }
    }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (tab == 0) "Add a sugar reading" else "Add a blood pressure reading", fontWeight = FontWeight.Black, fontSize = 15.sp, color = FitColors.Ink)
            if (tab == 0) {
                OutlinedTextField(
                    v1, { v1 = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("Sugar (mg/dL)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Fasting" to false, "After meal" to true).forEach { (label, am) ->
                        Box(
                            Modifier.weight(1f).clip(CircleShape).background(if (afterMeal == am) FitColors.Blue else FitColors.Chip)
                                .clickable { afterMeal = am }.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (afterMeal == am) Color.White else FitColors.Ink) }
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        v1, { v1 = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("Upper (SYS)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        v2, { v2 = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("Lower (DIA)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                    )
                }
            }
            if (warn.isNotBlank()) Text(warn, fontSize = 12.sp, color = FitColors.Red)
            ToolButton("Save reading", FitColors.Blue, Modifier.fillMaxWidth()) {
                val a = v1.toIntOrNull()
                val b = v2.toIntOrNull()
                if (tab == 0) {
                    if (a == null || a < 20 || a > 700) warn = "Enter a sugar value between 20 and 700."
                    else {
                        HealthLogStore.add(ctx, "sugar", a, if (afterMeal) 1 else 0)
                        entries = HealthLogStore.all(ctx); v1 = ""; warn = ""
                    }
                } else {
                    if (a == null || b == null || a < 60 || a > 280 || b < 30 || b > 180 || b >= a) warn = "Enter both values, for example 120 and 80."
                    else {
                        HealthLogStore.add(ctx, "bp", a, b)
                        entries = HealthLogStore.all(ctx); v1 = ""; v2 = ""; warn = ""
                    }
                }
            }
        }
    }

    if (shown.size >= 2) {
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text(if (tab == 0) "Sugar trend" else "Upper pressure trend", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                WeightChart(
                    shown.takeLast(20).map { it.a.toFloat() }, if (tab == 0) FitColors.Orange else FitColors.Coral,
                    Modifier.fillMaxWidth().height(140.dp).padding(top = 10.dp)
                )
            }
        }
    }

    if (shown.isEmpty()) {
        ToolNote("No readings yet. Add your first reading above.")
    } else {
        FitCard(Color.White, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Recent readings", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink)
                shown.reversed().take(10).forEach { e ->
                    val (status, color) = if (e.type == "sugar") sugarStatus(e.a, e.b == 1) else bpStatus(e.a, e.b)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (e.type == "sugar") "${e.a} mg/dL (" + (if (e.b == 1) "after meal" else "fasting") + ")" else "${e.a}/${e.b} mmHg",
                                fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FitColors.Ink
                            )
                            Text(fmtTime(e.ms), fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f))
                            Text(status.t(), fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "Remove", fontSize = 12.sp, color = FitColors.Coral, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { HealthLogStore.remove(ctx, e.ms); entries = HealthLogStore.all(ctx) }.padding(8.dp)
                        )
                    }
                }
            }
        }
        ToolButton("Share with my doctor (text)", FitColors.Ink, Modifier.fillMaxWidth()) {
            val sb = StringBuilder("FIT TO FIT - my ").append(if (tab == 0) "sugar" else "blood pressure").append(" readings\n")
            shown.takeLast(30).forEach { e: LogEntry ->
                sb.append(fmtTime(e.ms)).append(": ")
                if (e.type == "sugar") sb.append(e.a).append(" mg/dL ").append(if (e.b == 1) "(after meal)" else "(fasting)")
                else sb.append(e.a).append("/").append(e.b).append(" mmHg")
                sb.append("\n")
            }
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString())
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    ToolNote("This only shows general ranges and is not a diagnosis. Follow your doctor's advice. Low sugar below 70 needs quick sugar. Chest pain or severe breathlessness is an emergency.")
}

/* ---------------- app and data: backup, updates, privacy, crash log ---------------- */

@Composable
fun AppDataPage(onRestored: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var backupMsg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    var updateMsg by remember { mutableStateOf("") }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var showPrivacy by remember { mutableStateOf(false) }
    var crashText by remember { mutableStateOf(CrashLog.text(ctx)) }
    val signedIn = BackupManager.signedIn

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("☁️ Cloud backup", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            Text(
                "Saves your profile, weight, medicine reminders, sugar / BP readings and logs in your own private space online. " +
                    "If you change phone or re-install the app, log in and tap Restore.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .7f)
            )
            if (!signedIn) {
                Text("First sign up or log in on the Friends tab. Then come back here.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitColors.Orange)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton(if (busy) "Please wait..." else "Back up now", FitColors.Blue, Modifier.weight(1f)) {
                        if (!busy) {
                            busy = true
                            backupMsg = ""
                            scope.launch {
                                backupMsg = try {
                                    BackupManager.backup(ctx)
                                    "Backup saved ✓"
                                } catch (e: Exception) {
                                    "Backup failed: " + (e.message ?: "check your internet and Firestore rules")
                                }
                                busy = false
                            }
                        }
                    }
                    ToolButton("Restore", FitColors.Ink, Modifier.weight(1f)) { if (!busy) confirmRestore = true }
                }
            }
            if (backupMsg.isNotBlank()) Text(backupMsg, fontSize = 12.sp, color = FitColors.Ink)
        }
    }

    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            containerColor = FitColors.Surface,
            title = { Text("Restore from cloud?", fontWeight = FontWeight.Bold) },
            text = { Text("This replaces the data on this phone with your last backup.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = false
                    busy = true
                    backupMsg = ""
                    scope.launch {
                        backupMsg = try {
                            if (BackupManager.restore(ctx)) {
                                MedStore.scheduleAll(ctx)
                                onRestored()
                                "Restored ✓"
                            } else "No backup found yet."
                        } catch (e: Exception) {
                            "Restore failed: " + (e.message ?: "check your internet and Firestore rules")
                        }
                        busy = false
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text("Cancel") } }
        )
    }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("⬆️ App update", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            Text("Installed on: " + fmtTime(UpdateChecker.installedAt(ctx)), fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .7f))
            ToolButton("Check for update", FitColors.Blue, Modifier.fillMaxWidth()) {
                updateMsg = "Checking..."
                scope.launch {
                    val r = withContext(Dispatchers.IO) { UpdateChecker.check(ctx) }
                    update = r
                    updateMsg = when {
                        r == null -> "Could not check. Check your internet."
                        r.available -> "A newer version is available."
                        else -> "You have the latest version ✓"
                    }
                }
            }
            if (updateMsg.isNotBlank()) Text(updateMsg, fontSize = 12.sp, color = FitColors.Ink)
            if (update?.available == true) {
                ToolButton("Download the new APK", FitColors.LimeDark, Modifier.fillMaxWidth()) {
                    try { uri.openUri(UpdateChecker.APK_URL) } catch (e: Exception) { }
                }
                ToolNote("After it downloads, tap the file and install over the old app. Your data stays.")
            }
        }
    }

    FitCard(Color.White, Modifier.fillMaxWidth().clickable { showPrivacy = !showPrivacy }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔒 Privacy policy", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                Text(if (showPrivacy) "▲" else "▼", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .5f))
            }
            if (showPrivacy) privacyPolicy.forEach { Text(it.t(), fontSize = 12.sp, color = FitColors.Ink) }
        }
    }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🛠️ Problem report", fontWeight = FontWeight.Black, fontSize = 16.sp, color = FitColors.Ink)
            if (crashText.isBlank()) {
                Text("No crash recorded on this phone ✓", fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .7f))
            } else {
                Text("The app closed unexpectedly on " + fmtTime(CrashLog.time(ctx)) + ". You can send the details to the developer.", fontSize = 12.sp, color = FitColors.Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton("Share report", FitColors.Blue, Modifier.weight(1f)) {
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, "FIT TO FIT crash report\n\n" + crashText)
                        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    ToolButton("Clear", FitColors.Ink, Modifier.weight(1f)) { CrashLog.clear(ctx); crashText = "" }
                }
            }
            ToolNote("Nothing is sent automatically. It is shared only if you tap Share.")
        }
    }
}

private val privacyPolicy: List<L> = listOf(
    L("FIT TO FIT keeps your health data mainly on your own phone.", "FIT TO FIT உங்கள் உடல்நலத் தரவை முக்கியமாக உங்கள் ஃபோனிலேயே வைத்திருக்கிறது."),
    L("On your phone: profile, steps, weight, water, food, medicine reminders, sugar and BP readings.", "ஃபோனில்: profile, அடிகள், எடை, தண்ணீர், உணவு, மருந்து நினைவூட்டல், சர்க்கரை, BP பதிவுகள்."),
    L("Online (Firebase), only if you sign up: your name, friend code, daily totals (steps, calories, active time) and posts you choose to share. Friends can see these.", "இணையத்தில் (Firebase), நீங்கள் பதிவு செய்தால் மட்டும்: பெயர், நண்பர் குறியீடு, தினசரி மொத்தங்கள் (அடிகள், கலோரி, சுறுசுறுப்பு நேரம்), நீங்கள் பகிரும் பதிவுகள். நண்பர்கள் இவற்றைப் பார்க்கலாம்."),
    L("Cloud backup is stored in a private folder that only you can read.", "Cloud backup உங்களால் மட்டுமே படிக்கக்கூடிய தனிப்பட்ட இடத்தில் சேமிக்கப்படும்."),
    L("Health Connect / Google Fit data is read only on your phone, with your permission. It is not uploaded, except the daily totals above if you use Friends.", "Health Connect / Google Fit தரவு உங்கள் அனுமதியுடன் ஃபோனில் மட்டுமே படிக்கப்படும். Friends பயன்படுத்தினால் மேலே உள்ள தினசரி மொத்தங்கள் தவிர மற்றவை பதிவேற்றப்படாது."),
    L("Food photo scan and the AI assistant send your photo or question (and basic profile for the assistant, without your name) to Google Gemini using your own key.", "உணவுப் புகைப்பட scan மற்றும் AI உதவியாளர் உங்கள் புகைப்படம் / கேள்வியை (உதவியாளருக்கு பெயர் இல்லாத அடிப்படை profile உடன்) உங்கள் சொந்த key மூலம் Google Gemini-க்கு அனுப்பும்."),
    L("Location is used only while you track a walk, run or ride, and the route stays on your phone.", "நடை, ஓட்டம், சைக்கிள் பதிவின்போது மட்டுமே இருப்பிடம் பயன்படுத்தப்படும்; வழித்தடம் ஃபோனிலேயே இருக்கும்."),
    L("We do not sell your data and show no ads.", "உங்கள் தரவை விற்பதில்லை; விளம்பரங்கள் இல்லை."),
    L("This app gives general information and is not medical advice.", "இந்த app பொதுவான தகவலை மட்டும் தருகிறது; மருத்துவ ஆலோசனை அல்ல.")
)

/* ---------------- banner on the Home screen when a newer APK exists ---------------- */

@Composable
fun UpdateBanner() {
    val ctx = LocalContext.current
    val uri = LocalUriHandler.current
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        try {
            val prefs = ctx.getSharedPreferences("update", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            if (now - prefs.getLong("checked", 0L) > 6 * 3_600_000L) {
                val r = withContext(Dispatchers.IO) { UpdateChecker.check(ctx) }
                if (r != null) {
                    prefs.edit().putLong("checked", now).putBoolean("avail", r.available)
                        .putLong("installed", UpdateChecker.installedAt(ctx)).apply()
                }
            }
            // an old "update available" answer is ignored once the app has been updated
            show = prefs.getBoolean("avail", false) && prefs.getLong("installed", -1L) == UpdateChecker.installedAt(ctx)
        } catch (e: Exception) {
            show = false
        }
    }
    if (show) {
        FitCard(FitColors.Blue, Modifier.fillMaxWidth().clickable { try { uri.openUri(UpdateChecker.APK_URL) } catch (e: Exception) { } }) {
            Column(Modifier.padding(14.dp)) {
                Text("⬆️ A new version of FIT TO FIT is ready", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                Text("Tap to download. Install it over the old app; your data stays.", fontSize = 12.sp, color = Color.White.copy(alpha = .9f))
            }
        }
    }
}
