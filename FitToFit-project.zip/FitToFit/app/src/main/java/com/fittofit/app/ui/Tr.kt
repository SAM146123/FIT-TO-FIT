package com.fittofit.app.ui

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import com.fittofit.app.Settings

/** Languages the user can pick. */
val languageChoices = listOf("en" to "English", "ta" to "தமிழ்", "hi" to "हिन्दी")

private val dict: Map<String, Pair<String, String>> = mapOf(
    // navigation + headings
    "Home" to ("முகப்பு" to "होम"),
    "Activity" to ("செயல்பாடு" to "गतिविधि"),
    "Health" to ("ஆரோக்கியம்" to "स्वास्थ्य"),
    "Friends" to ("நண்பர்கள்" to "दोस्त"),
    "Progress" to ("முன்னேற்றம்" to "प्रगति"),
    "Profile" to ("சுயவிவரம்" to "प्रोफ़ाइल"),
    "Daily activity" to ("தினசரி செயல்பாடு" to "दैनिक गतिविधि"),
    "Weekly progress" to ("வாராந்திர முன்னேற்றம்" to "साप्ताहिक प्रगति"),
    "Workout" to ("உடற்பயிற்சி" to "वर्कआउट"),
    "Heart rate" to ("இதயத் துடிப்பு" to "हृदय गति"),
    "Recent activity" to ("சமீபத்திய செயல்பாடுகள்" to "हाल की गतिविधि"),
    "Goal tracker" to ("இலக்கு கண்காணிப்பு" to "लक्ष्य ट्रैकर"),
    "Achievements" to ("சாதனைகள்" to "उपलब्धियाँ"),
    "Connections" to ("இணைப்புகள்" to "कनेक्शन"),
    "Walking" to ("நடைப்பயிற்சி" to "पैदल चलना"),
    "WALKING" to ("நடைப்பயிற்சி" to "पैदल चलना"),
    "WALKING SESSION" to ("நடை அமர்வு" to "वॉक सेशन"),
    "TODAY'S WORKOUT" to ("இன்றைய உடற்பயிற்சி" to "आज का वर्कआउट"),
    "Video Coach" to ("வீடியோ கோச்" to "वीडियो कोच"),
    "Watch wallpaper" to ("வாட்ச் வால்பேப்பர்" to "वॉच वॉलपेपर"),
    "Settings" to ("அமைப்புகள்" to "सेटिंग्स"),
    "Today's motivation" to ("இன்றைய ஊக்கம்" to "आज की प्रेरणा"),
    "Your profile" to ("உங்கள் சுயவிவரம்" to "आपकी प्रोफ़ाइल"),
    "Set up your profile" to ("சுயவிவரத்தை அமைக்கவும்" to "प्रोफ़ाइल सेट करें"),
    // buttons
    "Save" to ("சேமி" to "सहेजें"),
    "Cancel" to ("ரத்து" to "रद्द करें"),
    "Remove" to ("நீக்கு" to "हटाएं"),
    "Share" to ("பகிர்" to "शेयर"),
    "Back" to ("பின்" to "वापस"),
    "Stop" to ("நிறுத்து" to "रोकें"),
    "Start walk" to ("நடையைத் தொடங்கு" to "वॉक शुरू करें"),
    "Start walking" to ("நடையைத் தொடங்கு" to "चलना शुरू करें"),
    "Start workout" to ("பயிற்சியைத் தொடங்கு" to "वर्कआउट शुरू करें"),
    "Start again" to ("மீண்டும் தொடங்கு" to "फिर से शुरू करें"),
    "Add photo" to ("படம் சேர்" to "फोटो जोड़ें"),
    "Change photo" to ("படத்தை மாற்று" to "फोटो बदलें"),
    "Remove photo" to ("படத்தை நீக்கு" to "फोटो हटाएं"),
    "Take photo" to ("படம் எடு" to "फोटो लें"),
    "Choose photo" to ("படம் தேர்வு" to "फोटो चुनें"),
    "Save key" to ("கீயை சேமி" to "की सहेजें"),
    "Refresh" to ("புதுப்பி" to "रिफ्रेश"),
    "Log in" to ("உள்நுழை" to "लॉग इन"),
    "Log out" to ("வெளியேறு" to "लॉग आउट"),
    "Sign up" to ("பதிவு செய்" to "साइन अप"),
    "Show more" to ("மேலும் காட்டு" to "और दिखाएं"),
    "Forget watch" to ("வாட்சை மறந்துவிடு" to "वॉच भूलें"),
    "Scan for devices" to ("சாதனங்களைத் தேடு" to "डिवाइस खोजें"),
    "Save to gallery" to ("கேலரியில் சேமி" to "गैलरी में सहेजें"),
    "Undo last" to ("கடைசியை நீக்கு" to "आखिरी हटाएं"),
    "Add friend" to ("நண்பரைச் சேர்" to "दोस्त जोड़ें"),
    "Invite friends" to ("நண்பர்களை அழை" to "दोस्तों को बुलाएं"),
    "Share my progress" to ("என் சாதனையைப் பகிர்" to "मेरी प्रगति शेयर करें"),
    // fields
    "Name" to ("பெயர்" to "नाम"),
    "Age" to ("வயது" to "उम्र"),
    "Email" to ("மின்னஞ்சல்" to "ईमेल"),
    "Height (cm)" to ("உயரம் (செ.மீ)" to "ऊंचाई (सेमी)"),
    "Weight (kg)" to ("எடை (கி.கி)" to "वज़न (किलो)"),
    "Daily step goal" to ("தினசரி அடி இலக்கு" to "दैनिक कदम लक्ष्य"),
    "Male" to ("ஆண்" to "पुरुष"),
    "Female" to ("பெண்" to "महिला"),
    // stats
    "Steps" to ("அடிகள்" to "कदम"),
    "steps" to ("அடிகள்" to "कदम"),
    "Steps today" to ("இன்றைய அடிகள்" to "आज के कदम"),
    "Steps this week" to ("இந்த வார அடிகள்" to "इस हफ्ते के कदम"),
    "Today" to ("இன்று" to "आज"),
    "Yesterday" to ("நேற்று" to "कल"),
    "This week" to ("இந்த வாரம்" to "इस हफ्ते"),
    "Calories" to ("கலோரிகள்" to "कैलोरी"),
    "Calories burned" to ("எரித்த கலோரிகள்" to "जली कैलोरी"),
    "Active Minutes" to ("செயலில் நிமிடங்கள்" to "सक्रिय मिनट"),
    "Active minutes" to ("செயலில் நிமிடங்கள்" to "सक्रिय मिनट"),
    "Total distance" to ("மொத்த தூரம்" to "कुल दूरी"),
    "time" to ("நேரம்" to "समय"),
    "km" to ("கி.மீ" to "किमी"),
    "kcal" to ("கிலோ கலோரி" to "किलो कैलोरी"),
    "Goal reached!" to ("இலக்கு முடிந்தது!" to "लक्ष्य पूरा!"),
    "Halfway there!" to ("பாதி வழி வந்துவிட்டீர்கள்!" to "आधा रास्ता पूरा!"),
    // health pages
    "BMI" to ("பி.எம்.ஐ" to "बीएमआई"),
    "Nutrition & Water" to ("உணவு & தண்ணீர்" to "पोषण और पानी"),
    "Heart & Respiratory" to ("இதயம் & சுவாசம்" to "हृदय और श्वसन"),
    "Sleep & Stress" to ("தூக்கம் & மன அழுத்தம்" to "नींद और तनाव"),
    "Body Fat & Muscle" to ("உடல் கொழுப்பு & தசை" to "शरीर की चर्बी और मांसपेशी"),
    "Women's Health" to ("பெண்கள் ஆரோக்கியம்" to "महिला स्वास्थ्य"),
    "Burned vs eaten" to ("எரித்தது vs உண்டது" to "जली बनाम खाई"),
    "Pulse, SpO₂, breathing" to ("நாடி, SpO₂, சுவாசம்" to "नाड़ी, SpO₂, सांस"),
    "Weight vs height" to ("எடை vs உயரம்" to "वज़न बनाम ऊंचाई"),
    "Food, macros, hydration" to ("உணவு, சத்துகள், நீர்" to "भोजन, पोषक तत्व, पानी"),
    "Rest and recovery" to ("ஓய்வு மற்றும் மீட்பு" to "आराम और रिकवरी"),
    "Body composition" to ("உடல் அமைப்பு" to "शरीर संरचना"),
    "Move more every day" to ("தினமும் அதிகம் நகருங்கள்" to "रोज़ ज़्यादा चलें"),
    "Menstrual cycle tracking" to ("மாதவிடாய் சுழற்சி கண்காணிப்பு" to "मासिक चक्र ट्रैकिंग"),
    "Water" to ("தண்ணீர்" to "पानी"),
    "Protein" to ("புரதம்" to "प्रोटीन"),
    "Carbs" to ("கார்போஹைட்ரேட்" to "कार्ब्स"),
    "Fat" to ("கொழுப்பு" to "वसा"),
    "Calories eaten today" to ("இன்று உண்ட கலோரிகள்" to "आज खाई कैलोरी"),
    "Quick add food" to ("உணவை விரைவாகச் சேர்" to "खाना जल्दी जोड़ें"),
    "Food photo scan" to ("உணவு படம் ஸ்கேன்" to "खाने की फोटो स्कैन"),
    "Portion size" to ("அளவு" to "मात्रा"),
    "Last night" to ("நேற்று இரவு" to "बीती रात"),
    "Sleep score" to ("தூக்க மதிப்பெண்" to "नींद स्कोर"),
    "Sleep stages" to ("தூக்க நிலைகள்" to "नींद के चरण"),
    "Resting heart rate" to ("ஓய்வு இதயத் துடிப்பு" to "विश्राम हृदय गति"),
    "Next period" to ("அடுத்த மாதவிடாய்" to "अगला पीरियड"),
    "Period started today" to ("இன்று மாதவிடாய் தொடங்கியது" to "आज पीरियड शुरू हुआ"),
    // friends
    "Friends Challenge" to ("நண்பர்கள் போட்டி" to "दोस्तों की चुनौती"),
    "Leaderboard" to ("தரவரிசை" to "लीडरबोर्ड"),
    "Compare" to ("ஒப்பிடு" to "तुलना"),
    "Your friend code" to ("உங்கள் நண்பர் குறியீடு" to "आपका फ्रेंड कोड"),
    "Add a friend" to ("நண்பரைச் சேர்" to "दोस्त जोड़ें"),
    "You" to ("நீங்கள்" to "आप"),
    "VS" to ("எதிர்" to "बनाम"),
    "Create your account" to ("கணக்கை உருவாக்கு" to "अपना खाता बनाएं"),
    "Already have an account? Log in" to ("ஏற்கனவே கணக்கு உள்ளதா? உள்நுழை" to "पहले से खाता है? लॉग इन"),
    "New here? Create an account" to ("புதியவரா? கணக்கை உருவாக்கு" to "नए हैं? खाता बनाएं"),
    // coach
    "Coach" to ("பயிற்சியாளர்" to "कोच"),
    "Coach tips" to ("பயிற்சி குறிப்புகள்" to "कोच टिप्स"),
    "How to do it" to ("செய்யும் முறை" to "कैसे करें"),
    "All" to ("அனைத்தும்" to "सभी"),
    "Cardio" to ("கார்டியோ" to "कार्डियो"),
    "Strength" to ("வலிமை" to "ताकत"),
    "Core" to ("மையம்" to "कोर"),
    "Beginner" to ("தொடக்கம்" to "शुरुआती"),
    "Intermediate" to ("இடைநிலை" to "मध्यम"),
    "Brisk Walk" to ("வேக நடை" to "तेज़ चाल"),
    "Jumping Jacks" to ("ஜம்பிங் ஜாக்ஸ்" to "जंपिंग जैक्स"),
    "Squats" to ("குந்துதல்" to "स्क्वाट्स"),
    "Push-ups" to ("புஷ்-அப்ஸ்" to "पुश-अप्स"),
    "Plank Hold" to ("பிளாங்க்" to "प्लैंक"),
    "Lunges" to ("லஞ்சஸ்" to "लंजेस"),
    "High Knees" to ("ஹை நீஸ்" to "हाई नीज़"),
    "Mountain Climbers" to ("மவுண்டன் கிளைம்பர்ஸ்" to "माउंटेन क्लाइंबर्स"),
    "Voice coach (English)" to ("குரல் பயிற்சியாளர் (ஆங்கிலம்)" to "वॉइस कोच (अंग्रेज़ी)"),
    "Voice updates every 0.5 km" to ("ஒவ்வொரு 0.5 கி.மீட்டருக்கும் குரல் அறிவிப்பு" to "हर 0.5 किमी पर आवाज़ अपडेट"),
    "English voice, off by default" to ("ஆங்கிலக் குரல், தொடக்கத்தில் நிறுத்தம்" to "अंग्रेज़ी आवाज़, शुरू में बंद"),
    // connections
    "Smartwatch (Bluetooth)" to ("ஸ்மார்ட்வாட்ச் (புளூடூத்)" to "स्मार्टवॉच (ब्लूटूथ)"),
    "Google Fit / Health Connect" to ("Google Fit / Health Connect" to "Google Fit / Health Connect"),
    "Connect smartwatch" to ("ஸ்மார்ட்வாட்சை இணை" to "स्मार्टवॉच कनेक्ट करें"),
    "Tap to connect" to ("இணைக்க தொடவும்" to "कनेक्ट करने के लिए टैप करें"),
    "Synced" to ("ஒத்திசைந்தது" to "सिंक हो गया"),
    "Tap to allow access" to ("அனுமதிக்க தொடவும்" to "अनुमति देने के लिए टैप करें"),
    "Tap to add your details" to ("விவரங்களைச் சேர்க்க தொடவும்" to "विवरण जोड़ने के लिए टैप करें"),
    // new screens
    "Theme" to ("தீம்" to "थीम"),
    "Language" to ("மொழி" to "भाषा"),
    "Phone setting" to ("போன் அமைப்பு" to "फ़ोन सेटिंग"),
    "Light" to ("வெளிச்சம்" to "लाइट"),
    "Dark" to ("இருள்" to "डार्क"),
    "Link shared with your posts" to ("பகிர்வுடன் செல்லும் இணைப்பு" to "शेयर के साथ जाने वाला लिंक"),
    "Today's wallpaper" to ("இன்றைய வால்பேப்பர்" to "आज का वॉलपेपर"),
    "Details" to ("விவரங்கள்" to "विवरण"),
    "Duration" to ("நேரம்" to "अवधि"),
    "Distance" to ("தூரம்" to "दूरी"),
    "Average pace" to ("சராசரி வேகம் (நிமி/கி.மீ)" to "औसत गति (मिनट/किमी)"),
    "Average speed" to ("சராசரி வேகம் (கி.மீ/ம)" to "औसत गति (किमी/घं)"),
    "Close" to ("மூடு" to "बंद करें"),
    "Unlocked" to ("திறக்கப்பட்டது" to "अनलॉक"),
    "Locked" to ("பூட்டியது" to "लॉक"),
    "Your badges" to ("உங்கள் பேட்ஜ்கள்" to "आपके बैज"),
    "Source" to ("மூலம்" to "स्रोत"),
    "Started" to ("தொடக்கம்" to "शुरू"),
    "Calories burned today" to ("இன்று எரித்த கலோரிகள்" to "आज जली कैलोरी"),
    "Tap for full details" to ("முழு விவரத்திற்கு தொடவும்" to "पूरे विवरण के लिए टैप करें")
)

fun tr(text: String): String {
    val lang = Settings.lang
    if (lang == "en") return text
    val p = dict[text] ?: return text
    return if (lang == "ta") p.first else p.second
}

/** Same as the normal Text, but shows the chosen language when a translation exists. */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        tr(text), modifier, color, fontSize, fontStyle, fontWeight, fontFamily, letterSpacing,
        textDecoration, textAlign, lineHeight, overflow, softWrap, maxLines, minLines, onTextLayout, style
    )
}
