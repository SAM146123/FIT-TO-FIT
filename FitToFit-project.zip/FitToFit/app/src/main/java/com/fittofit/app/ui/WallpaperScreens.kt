package com.fittofit.app.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.fittofit.app.CommunityWalls
import com.fittofit.app.Wall
import com.fittofit.app.WallStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun WallButton(text: String, bg: Color, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(if (enabled) bg else bg.copy(alpha = .35f))
            .clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun WallTile(w: Wall, modifier: Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, w.id) {
        value = withContext(Dispatchers.IO) { WallStore.thumb(ctx, w) }
    }
    Box(
        modifier.aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp))
            .background(FitColors.Chip).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), w.author, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("🖼️", fontSize = 30.sp)
    }
}

@Composable
private fun WallGrid(list: List<Wall>, onPick: (Wall) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { w -> WallTile(w, Modifier.weight(1f)) { onPick(w) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun WallDialog(w: Wall, onClose: () -> Unit, onDelete: (() -> Unit)?, onReport: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var failed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val loaded by produceState<Pair<File, Bitmap?>?>(null, w.id) {
        val f = withContext(Dispatchers.IO) { WallStore.fullFile(ctx, w) }
        if (f == null) { failed = true; value = null } else {
            value = f to withContext(Dispatchers.IO) { WallStore.preview(f) }
        }
    }
    fun toast(t: String) = Toast.makeText(ctx, tr(t), Toast.LENGTH_SHORT).show()
    fun doSet(which: Int) {
        val f = loaded?.first ?: return
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) { WallStore.setWallpaper(ctx, f, which) }
            busy = false
            toast(if (ok) "Wallpaper set" else "Could not set the wallpaper")
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B0D17)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val b = loaded?.second
                when {
                    b != null -> Image(
                        b.asImageBitmap(), w.author,
                        Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Fit
                    )
                    failed -> Text("Could not download. Check your internet and try again.", color = Color.White, fontSize = 14.sp)
                    else -> Text("Downloading 4K picture…", color = Color.White, fontSize = 14.sp)
                }
            }
            if (w.thumbUrl != null) {
                Text("Photo by ${w.author} · free to use (Unsplash licence)", color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
            } else if (w.community) {
                Text("Shared by ${w.author}", color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
            }
            val ready = loaded?.second != null && !busy
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WallButton("Home", FitColors.Blue, Modifier.weight(1f), ready) { doSet(1) }
                WallButton("Lock", FitColors.Blue, Modifier.weight(1f), ready) { doSet(2) }
                WallButton("Both", FitColors.Blue, Modifier.weight(1f), ready) { doSet(3) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WallButton("Save to gallery", FitColors.LimeDark, Modifier.weight(1f), ready) {
                    val f = loaded?.first
                    if (f != null) scope.launch {
                        val ok = withContext(Dispatchers.IO) { WallStore.saveToGallery(ctx, f, w.id) }
                        toast(if (ok) "Saved in Pictures/FitToFit" else "Saving needs Android 10 or newer. Use Home or Lock instead.")
                    }
                }
                WallButton("Close", Color(0xFF455A64), Modifier.weight(1f)) { onClose() }
            }
            if (onDelete != null || onReport != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (onDelete != null) WallButton("Delete", Color(0xFFC62828), Modifier.weight(1f)) { onDelete() }
                    if (onReport != null) WallButton("Report this picture", Color(0xFF8D6E63), Modifier.weight(1f)) { onReport() }
                }
            }
        }
    }
}

@Composable
fun WallpaperPage(userName: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Wall?>(null) }
    var askShare by remember { mutableStateOf(false) }
    var sharing by remember { mutableStateOf(false) }
    val today by produceState<List<Wall>?>(null, reload) {
        value = withContext(Dispatchers.IO) { WallStore.today(ctx) }
    }
    var mineKey by remember { mutableIntStateOf(0) }
    val mine by produceState<List<Wall>>(emptyList(), mineKey) {
        value = withContext(Dispatchers.IO) { WallStore.mine(ctx) }
    }
    var comKey by remember { mutableIntStateOf(0) }
    var comError by remember { mutableStateOf(false) }
    val community by produceState<List<Wall>?>(null, comKey) {
        comError = false
        value = try { CommunityWalls.list() } catch (e: Exception) { comError = true; emptyList() }
    }
    fun toast(t: String) = Toast.makeText(ctx, tr(t), Toast.LENGTH_LONG).show()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { WallStore.addFromUri(ctx, uri) }
            toast(if (ok) "Added to My pictures" else "Could not add this picture")
            mineKey++
            if (ok) tab = 2
        }
    }
    val sharePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            sharing = true
            scope.launch {
                val err = withContext(Dispatchers.IO) { CommunityWalls.upload(ctx, uri, userName) }
                sharing = false
                toast(err ?: "Shared! Everyone can use it now.")
                if (err == null) comKey++
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("New today", "Community", "My pictures").forEachIndexed { i, label ->
                Box(
                    Modifier.clip(CircleShape)
                        .background(if (tab == i) FitColors.Blue else FitColors.Chip)
                        .clickable { tab = i }.padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (tab == i) Color.White else FitColors.Ink)
                }
            }
        }
        when (tab) {
            0 -> {
                Text(
                    "20 new free 4K wallpapers every day. Tap one to preview, then set it as your Home or Lock screen.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
                val list = today
                when {
                    list == null -> Text("Loading today's wallpapers…", fontSize = 13.sp, color = FitColors.Ink)
                    list.isEmpty() -> {
                        Text("Could not load wallpapers. Check your internet.", fontSize = 13.sp, color = FitColors.Ink)
                        WallButton("Try again", FitColors.Blue) { reload++ }
                    }
                    else -> WallGrid(list) { open = it }
                }
                Text(
                    "Photos are free to use from Unsplash via Picsum Photos. Each photo shows its photographer.",
                    fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f)
                )
            }
            1 -> {
                Text(
                    "Pictures shared by FIT TO FIT users. Share yours and everyone can use it as a wallpaper.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
                if (!CommunityWalls.signedIn) {
                    Text("Sign up or log in on the Friends tab to see and share community wallpapers.", fontSize = 13.sp, color = FitColors.Ink)
                } else {
                    WallButton(
                        if (sharing) "Sharing…" else "+ Share my picture with everyone",
                        FitColors.LimeDark, Modifier.fillMaxWidth(), enabled = !sharing
                    ) { askShare = true }
                    val list = community
                    when {
                        list == null -> Text("Loading…", fontSize = 13.sp, color = FitColors.Ink)
                        comError -> {
                            Text("Could not load. Check your internet.", fontSize = 13.sp, color = FitColors.Ink)
                            WallButton("Try again", FitColors.Blue) { comKey++ }
                        }
                        list.isEmpty() -> Text("No shared pictures yet. Be the first!", fontSize = 13.sp, color = FitColors.Ink)
                        else -> WallGrid(list) { open = it }
                    }
                }
            }
            else -> {
                Text(
                    "Add your own pictures. They stay on your phone and you can set them as wallpaper any time.",
                    fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
                )
                WallButton("+ Add my picture", FitColors.LimeDark, Modifier.fillMaxWidth()) { picker.launch("image/*") }
                if (mine.isEmpty()) {
                    Text("No pictures yet.", fontSize = 13.sp, color = FitColors.Ink)
                } else {
                    WallGrid(mine) { open = it }
                }
            }
        }
    }

    if (askShare) {
        AlertDialog(
            onDismissRequest = { askShare = false },
            title = { Text("Share with everyone?") },
            text = {
                Text(
                    "Everyone using FIT TO FIT will see this picture, use it as a wallpaper and save it. " +
                        "Your name is shown with it. Share only pictures you own, that are suitable for all ages, " +
                        "and do not show other people without their permission. You can delete it any time."
                )
            },
            confirmButton = { TextButton(onClick = { askShare = false; sharePicker.launch("image/*") }) { Text("Choose picture") } },
            dismissButton = { TextButton(onClick = { askShare = false }) { Text("Cancel") } }
        )
    }

    open?.let { w ->
        val mineShared = w.community && w.ownerUid == CommunityWalls.myUid
        WallDialog(
            w, onClose = { open = null },
            onDelete = when {
                w.file != null -> ({ WallStore.remove(w); open = null; mineKey++ })
                mineShared -> ({
                    scope.launch {
                        val ok = CommunityWalls.delete(w)
                        toast(if (ok) "Deleted" else "Could not delete")
                        if (ok) { open = null; comKey++ }
                    }
                })
                else -> null
            },
            onReport = if (w.community && !mineShared) ({
                scope.launch {
                    val ok = CommunityWalls.report(w)
                    toast(if (ok) "Thank you. We will review it." else "Could not report")
                    if (ok) { open = null; comKey++ }
                }
            }) else null
        )
    }
}

@Composable
fun WallpaperEntry(onClick: () -> Unit) {
    FitCard(Color(0xFF6A1B9A), Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("🖼️", fontSize = 34.sp)
            Column(Modifier.weight(1f)) {
                Text("Wallpapers", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color.White)
                Text("Free 4K, new every day. Share yours with everyone.", fontSize = 12.sp, color = Color.White.copy(alpha = .85f))
            }
            Text("›", fontSize = 26.sp, color = Color.White)
        }
    }
}

@Composable
fun WallpaperScreenDialog(userName: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(FitColors.Cream).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("🖼️ Wallpapers", fontWeight = FontWeight.Black, fontSize = 22.sp, color = FitColors.Ink, modifier = Modifier.weight(1f))
                Box(
                    Modifier.clip(CircleShape).background(FitColors.Chip).clickable { onClose() }.padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text("✕", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = FitColors.Ink) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { WallpaperPage(userName) }
        }
    }
}
