package com.fittofit.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Makes a FIT TO FIT picture you can use as a custom watch background. */
object WallpaperMaker {

    val themeNames = listOf("Ocean", "Sunset", "Night", "Lime")

    private val themeColors = listOf(
        intArrayOf(0xFF1565E8.toInt(), 0xFF4CCFD0.toInt()),
        intArrayOf(0xFFFF9330.toInt(), 0xFFEC407A.toInt()),
        intArrayOf(0xFF141A3A.toInt(), 0xFF5B3FD0.toInt()),
        intArrayOf(0xFF7DA11A.toInt(), 0xFFCDEB4E.toInt())
    )

    val previewColors = themeColors.map { Color(it[0]) }

    fun render(theme: Int, name: String, size: Int = 454): Bitmap {
        val s = size.toFloat()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val colors = themeColors[theme.coerceIn(0, themeColors.lastIndex)]
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // background
        paint.shader = LinearGradient(0f, 0f, s, s, colors[0], colors[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)
        paint.shader = null

        // soft circles
        paint.color = 0x22FFFFFF
        c.drawCircle(s * 0.85f, s * 0.15f, s * 0.35f, paint)
        c.drawCircle(s * 0.10f, s * 0.95f, s * 0.30f, paint)

        // heart
        val cx = s / 2f
        val cy = s * 0.40f
        val r = s * 0.20f
        val heart = Path().apply {
            moveTo(cx, cy + r * 0.95f)
            cubicTo(cx - r * 1.55f, cy - r * 0.10f, cx - r * 0.95f, cy - r * 1.25f, cx, cy - r * 0.45f)
            cubicTo(cx + r * 0.95f, cy - r * 1.25f, cx + r * 1.55f, cy - r * 0.10f, cx, cy + r * 0.95f)
            close()
        }
        paint.color = 0xFFFFFFFF.toInt()
        c.drawPath(heart, paint)

        // heartbeat line
        val line = Path().apply {
            moveTo(cx - r * 0.95f, cy + r * 0.05f)
            lineTo(cx - r * 0.35f, cy + r * 0.05f)
            lineTo(cx - r * 0.12f, cy - r * 0.45f)
            lineTo(cx + r * 0.18f, cy + r * 0.55f)
            lineTo(cx + r * 0.38f, cy + r * 0.05f)
            lineTo(cx + r * 0.95f, cy + r * 0.05f)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.016f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = 0xFFFF4D5A.toInt()
        c.drawPath(line, paint)

        // text
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = s * 0.085f
        c.drawText("FIT TO FIT", cx, s * 0.76f, paint)
        paint.typeface = Typeface.DEFAULT
        paint.textSize = s * 0.04f
        paint.color = 0xCCFFFFFF.toInt()
        val sub = if (name.isNotBlank()) "Stay active, $name" else "Stay active"
        c.drawText(sub, cx, s * 0.84f, paint)
        return bmp
    }

    /** Saves the picture in Pictures/FitToFit. Returns its address, or null if it could not be saved. */
    fun save(ctx: Context, bmp: Bitmap, fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$fileName.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FitToFit")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            uri
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun WatchWallpaperCard(name: String) {
    val context = LocalContext.current
    var theme by remember { mutableIntStateOf(0) }
    val bitmap = remember(theme, name) { WallpaperMaker.render(theme, name) }
    val image = remember(bitmap) { bitmap.asImageBitmap() }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Watch wallpaper", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
            Text(
                "Make a FIT TO FIT picture, save it, then set it as the background from your watch's own app.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Image(
                    image, "Wallpaper preview",
                    Modifier.size(130.dp).clip(CircleShape)
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WallpaperMaker.previewColors.forEachIndexed { i, col ->
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(col)
                                    .border(if (i == theme) 3.dp else 0.dp, FitColors.Ink, CircleShape)
                                    .clickable { theme = i }
                            )
                        }
                    }
                    Text(WallpaperMaker.themeNames[theme], fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WallButton("Save to gallery", FitColors.Blue, Color.White, Modifier.weight(1f)) {
                    val uri = WallpaperMaker.save(context, bitmap, "FitToFit_${WallpaperMaker.themeNames[theme]}")
                    val msg = if (uri != null) "Saved in Pictures/FitToFit" else "Saving needs Android 10 or newer"
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
                WallButton("Share", FitColors.Cream, FitColors.Ink, Modifier.weight(1f)) {
                    val uri = WallpaperMaker.save(context, bitmap, "FitToFit_${WallpaperMaker.themeNames[theme]}")
                    if (uri == null) {
                        Toast.makeText(context, "Sharing needs Android 10 or newer", Toast.LENGTH_LONG).show()
                    } else {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "image/png"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, "Share wallpaper"))
                    }
                }
            }
            Text(
                "Then open your watch app (Mi Fitness, Zepp, Galaxy Wearable, Fitbit, Wear OS...) > Watch faces > Custom / Photo and pick this image. " +
                    "Apps cannot change a watch face by themselves, because every watch brand uses its own system.",
                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f)
            )
        }
    }
}

@Composable
private fun WallButton(text: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}
