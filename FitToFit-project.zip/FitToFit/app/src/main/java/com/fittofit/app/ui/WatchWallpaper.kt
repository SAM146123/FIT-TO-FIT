package com.fittofit.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Makes high-quality FIT TO FIT pictures (a new design every day) for use as a watch or phone background. */
object WallpaperMaker {

    val themeNames = listOf("Heart", "Sunrise", "Waves", "Mountains", "Rings", "Bokeh", "Aurora", "Geometry")

    private val grads = listOf(
        intArrayOf(0xFF1565E8.toInt(), 0xFF4CCFD0.toInt()),
        intArrayOf(0xFFFF9330.toInt(), 0xFFEC407A.toInt()),
        intArrayOf(0xFF0B3D91.toInt(), 0xFF2EC4B6.toInt()),
        intArrayOf(0xFF141A3A.toInt(), 0xFF5B3FD0.toInt()),
        intArrayOf(0xFF0E1330.toInt(), 0xFF1B2A6B.toInt()),
        intArrayOf(0xFF7DA11A.toInt(), 0xFFCDEB4E.toInt()),
        intArrayOf(0xFF021B1A.toInt(), 0xFF0B6E4F.toInt()),
        intArrayOf(0xFF5B3FD0.toInt(), 0xFF1565E8.toInt())
    )

    val previewColors = grads.map { Color(it[0]) }

    /** Today's design number (changes every day). */
    fun todayIndex(): Int = java.time.LocalDate.now().dayOfYear % grads.size

    fun render(theme: Int, name: String, quote: String = "", size: Int = 1080): Bitmap {
        val s = size.toFloat()
        val t = theme.coerceIn(0, grads.lastIndex)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val colors = grads[t]
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rnd = java.util.Random(java.time.LocalDate.now().toEpochDay() * 31 + t)

        paint.shader = LinearGradient(0f, 0f, s * 0.6f, s, colors[0], colors[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)
        paint.shader = null

        when (t) {
            0 -> { // heart
                paint.color = 0x22FFFFFF
                c.drawCircle(s * 0.85f, s * 0.15f, s * 0.35f, paint)
                c.drawCircle(s * 0.10f, s * 0.95f, s * 0.30f, paint)
                val cx = s / 2f
                val cy = s * 0.38f
                val r = s * 0.20f
                val heart = Path().apply {
                    moveTo(cx, cy + r * 0.95f)
                    cubicTo(cx - r * 1.55f, cy - r * 0.10f, cx - r * 0.95f, cy - r * 1.25f, cx, cy - r * 0.45f)
                    cubicTo(cx + r * 0.95f, cy - r * 1.25f, cx + r * 1.55f, cy - r * 0.10f, cx, cy + r * 0.95f)
                    close()
                }
                paint.color = 0xFFFFFFFF.toInt()
                c.drawPath(heart, paint)
                val line = Path().apply {
                    moveTo(cx - r * 0.95f, cy + r * 0.05f)
                    lineTo(cx - r * 0.35f, cy + r * 0.05f)
                    lineTo(cx - r * 0.12f, cy - r * 0.45f)
                    lineTo(cx + r * 0.18f, cy + r * 0.55f)
                    lineTo(cx + r * 0.38f, cy + r * 0.05f)
                    lineTo(cx + r * 0.95f, cy + r * 0.05f)
                }
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.016f
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
                paint.color = 0xFFFF4D5A.toInt()
                c.drawPath(line, paint)
                paint.style = Paint.Style.FILL
            }
            1 -> { // sunrise
                paint.color = 0xFFFFE066.toInt()
                c.drawCircle(s / 2f, s * 0.52f, s * 0.17f, paint)
                paint.color = 0x33FFFFFF
                c.drawCircle(s / 2f, s * 0.52f, s * 0.24f, paint)
                listOf(0xFF8E2D6B.toInt() to 0.62f, 0xFF5E1F55.toInt() to 0.72f, 0xFF3A1445.toInt() to 0.83f).forEach { (col, base) ->
                    val hill = Path().apply {
                        moveTo(0f, s)
                        lineTo(0f, s * base)
                        cubicTo(s * 0.25f, s * (base - 0.12f), s * 0.55f, s * (base + 0.08f), s, s * (base - 0.06f))
                        lineTo(s, s)
                        close()
                    }
                    paint.color = col
                    c.drawPath(hill, paint)
                }
            }
            2 -> { // waves
                for (k in 0 until 5) {
                    val base = s * (0.45f + 0.1f * k)
                    val wave = Path().apply {
                        moveTo(0f, s)
                        lineTo(0f, base)
                        var x = 0f
                        while (x <= s) {
                            lineTo(x, base + kotlin.math.sin((x / s) * 6.28f * (1.2f + k * 0.2f) + k) * s * 0.035f)
                            x += s / 60f
                        }
                        lineTo(s, s)
                        close()
                    }
                    paint.color = Color.White.copy(alpha = 0.10f + 0.04f * k).toArgb()
                    c.drawPath(wave, paint)
                }
            }
            3 -> { // mountains + moon
                paint.color = 0xFFFFF3C4.toInt()
                c.drawCircle(s * 0.72f, s * 0.24f, s * 0.08f, paint)
                listOf(0xFF2A2468.toInt() to 0.60f, 0xFF1B1750.toInt() to 0.70f, 0xFF100E34.toInt() to 0.80f).forEachIndexed { n, (col, base) ->
                    val m = Path().apply {
                        moveTo(0f, s)
                        lineTo(0f, s * base)
                        var x = 0f
                        while (x < s) {
                            val peak = s * (base - 0.10f - rnd.nextFloat() * 0.10f)
                            lineTo(x + s * 0.12f, peak)
                            lineTo(x + s * 0.24f, s * (base + 0.02f))
                            x += s * 0.24f
                        }
                        lineTo(s, s)
                        close()
                    }
                    paint.color = col
                    c.drawPath(m, paint)
                }
                paint.color = 0xAAFFFFFF.toInt()
                for (k in 0 until 40) c.drawCircle(rnd.nextFloat() * s, rnd.nextFloat() * s * 0.5f, 2f + rnd.nextFloat() * 3f, paint)
            }
            4 -> { // activity rings
                val cx = s / 2f
                val cy = s * 0.40f
                paint.style = Paint.Style.STROKE
                paint.strokeCap = Paint.Cap.ROUND
                val ringCols = intArrayOf(0xFFFF7A66.toInt(), 0xFFCDEB4E.toInt(), 0xFF4CCFD0.toInt())
                val sweeps = floatArrayOf(300f, 240f, 190f)
                for (k in 0 until 3) {
                    val r = s * (0.24f - 0.06f * k)
                    paint.strokeWidth = s * 0.04f
                    paint.color = (ringCols[k] and 0x00FFFFFF) or 0x33000000
                    c.drawCircle(cx, cy, r, paint)
                    paint.color = ringCols[k]
                    c.drawArc(cx - r, cy - r, cx + r, cy + r, -90f, sweeps[k], false, paint)
                }
                paint.style = Paint.Style.FILL
            }
            5 -> { // bokeh
                for (k in 0 until 26) {
                    paint.color = Color.White.copy(alpha = 0.08f + rnd.nextFloat() * 0.18f).toArgb()
                    c.drawCircle(rnd.nextFloat() * s, rnd.nextFloat() * s, s * (0.03f + rnd.nextFloat() * 0.11f), paint)
                }
            }
            6 -> { // aurora
                val cols = intArrayOf(0x4400FFAA, 0x4400C8FF, 0x44B388FF)
                for (k in 0 until 3) {
                    val ribbon = Path().apply {
                        moveTo(0f, s * (0.25f + 0.10f * k))
                        cubicTo(s * 0.3f, s * (0.05f + 0.1f * k), s * 0.6f, s * (0.45f + 0.05f * k), s, s * (0.2f + 0.1f * k))
                        lineTo(s, s * (0.45f + 0.1f * k))
                        cubicTo(s * 0.6f, s * (0.7f + 0.05f * k), s * 0.3f, s * (0.3f + 0.1f * k), 0f, s * (0.5f + 0.1f * k))
                        close()
                    }
                    paint.color = cols[k]
                    c.drawPath(ribbon, paint)
                }
                paint.color = 0xAAFFFFFF.toInt()
                for (k in 0 until 50) c.drawCircle(rnd.nextFloat() * s, rnd.nextFloat() * s * 0.6f, 1.5f + rnd.nextFloat() * 3f, paint)
            }
            else -> { // geometry
                val n = 6
                val cell = s / n
                for (i in 0 until n) for (j in 0 until n) {
                    paint.color = Color.White.copy(alpha = 0.04f + rnd.nextFloat() * 0.14f).toArgb()
                    val tri = Path().apply {
                        if (rnd.nextBoolean()) {
                            moveTo(i * cell, j * cell); lineTo((i + 1) * cell, j * cell); lineTo(i * cell, (j + 1) * cell)
                        } else {
                            moveTo((i + 1) * cell, j * cell); lineTo((i + 1) * cell, (j + 1) * cell); lineTo(i * cell, (j + 1) * cell)
                        }
                        close()
                    }
                    c.drawPath(tri, paint)
                }
            }
        }

        // brand + text
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = s * 0.085f
        c.drawText("FIT TO FIT", s / 2f, s * 0.80f, paint)
        paint.typeface = Typeface.DEFAULT
        paint.textSize = s * 0.034f
        paint.color = 0xDDFFFFFF.toInt()
        val sub = when {
            quote.isNotBlank() -> quote
            name.isNotBlank() -> "Stay active, $name"
            else -> "Stay active"
        }
        val tp = android.text.TextPaint(paint)
        val layout = android.text.StaticLayout.Builder.obtain(sub, 0, sub.length, tp, (s * 0.78f).toInt())
            .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER).build()
        c.save()
        c.translate(s * 0.11f, s * 0.835f)
        layout.draw(c)
        c.restore()
        return bmp
    }

    /** Saves the picture in Pictures/FitToFit. Returns its address, or null if it could not be saved. */
    fun save(ctx: Context, bmp: Bitmap, fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$fileName.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FitToFit")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            uri
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun WatchWallpaperCard(name: String) {
    val context = LocalContext.current
    val today = remember { WallpaperMaker.todayIndex() }
    var theme by remember { mutableIntStateOf(today) }
    val quote = com.fittofit.app.Quotes.today(com.fittofit.app.Settings.lang)
    // a smaller picture for the preview, full 1080 px quality when saving
    val preview = remember(theme, name, quote) { WallpaperMaker.render(theme, name, quote, 540) }
    val image = remember(preview) { preview.asImageBitmap() }

    FitCard(Color.White, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Today's wallpaper", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FitColors.Ink)
            Text(
                "A new design is ready every day. Save it, then set it as your watch background from your watch's own app.",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .65f)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Image(image, "Wallpaper preview", Modifier.size(220.dp).clip(RoundedCornerShape(24.dp)))
            }
            Text(
                WallpaperMaker.themeNames[theme] + if (theme == today) " · today" else "",
                fontSize = 12.sp, color = FitColors.Ink.copy(alpha = .6f),
                modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                WallpaperMaker.previewColors.forEachIndexed { i, col ->
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(col)
                            .border(if (i == theme) 3.dp else 0.dp, FitColors.Ink, CircleShape)
                            .clickable { theme = i }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WallButton("Save to gallery", FitColors.Blue, Color.White, Modifier.weight(1f)) {
                    val full = WallpaperMaker.render(theme, name, quote)
                    val uri = WallpaperMaker.save(context, full, "FitToFit_${WallpaperMaker.themeNames[theme]}_${java.time.LocalDate.now()}")
                    val msg = if (uri != null) "Saved in Pictures/FitToFit" else "Saving needs Android 10 or newer"
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
                WallButton("Share", FitColors.Cream, FitColors.Ink, Modifier.weight(1f)) {
                    val full = WallpaperMaker.render(theme, name, quote)
                    val uri = WallpaperMaker.save(context, full, "FitToFit_${WallpaperMaker.themeNames[theme]}_${java.time.LocalDate.now()}")
                    if (uri == null) {
                        Toast.makeText(context, "Sharing needs Android 10 or newer", Toast.LENGTH_LONG).show()
                    } else {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "image/png"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, "Share wallpaper"))
                    }
                }
            }
            Text(
                "Open your watch app (Mi Fitness, Zepp, Galaxy Wearable, Fitbit, Wear OS...) > Watch faces > Custom / Photo and pick this image. " +
                    "Android does not let one app change another brand's watch face directly, so this last step is done in the watch's own app.",
                fontSize = 11.sp, color = FitColors.Ink.copy(alpha = .55f)
            )
        }
    }
}

@Composable
private fun WallButton(text: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}
